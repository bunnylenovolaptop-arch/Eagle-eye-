# EAGLE EYE INDIA — Hardened Full-Stack Read-Only Build

Evidence-first Indian intraday intelligence with Angel One SmartAPI live feeds, staged technical analysis, catalyst/news verification, 100-point decision scoring, adversarial skepticism, paper trading, backtesting, privacy/security controls, and an Android wrapper project.

## Trust boundary

Android/PWA -> HTTPS/WSS -> Eagle Eye FastAPI -> Angel One SmartAPI + explicitly configured permitted data providers.

Angel One API keys, client code, password, TOTP secret, JWT and feed token are backend-only. The Android package contains no broker credentials. Broker order execution is disabled.

## Live-data rules

The Angel One WebSocket 2.0 adapter validates packet shape, price/OHLC relationships, timestamp skew, tick age, and sequence ordering. Index-feed sequence numbers are ignored because Angel One documents that index sequence numbers are not available. Heartbeats are checked and the connection reconnects on failure.

The client displays LIVE only after a validated fresh tick is received. Otherwise it displays STALE or UNAVAILABLE. REST/HTTP data is no-store.

Current NSE cash-session handling distinguishes regular continuous trading (09:15–15:20), CAS order entry (15:20–15:30), CAS matching (15:30–15:35), transition (15:35–15:50), closing session (15:50–16:00), and F&O through 15:40. NSE currently publishes these timings on its market-timings page.

## Features implemented

- Multi-timeframe analysis: 1m, 3m, 5m, 15m, 30m, 1H, 1D, 1W.
- EMA 9/20/50/200, SMA 20/50/200, RSI, MACD, ADX, ATR, Bollinger Bands, VWAP, OBV, relative volume and volume acceleration.
- HH/HL/LH/LL, trend transition, support/resistance, opening range, breakout/breakdown, failed breakouts/breakdowns, rejection, pin-bar, momentum, reversal and approximate volume profile.
- Relative strength vs NIFTY, sector, peer context when a permitted mapping is available.
- F&O contract discovery, futures basis, OI, OI change, PCR, buildup/unwinding, major call/put OI levels, option volume and IV when supplied by the quote provider.
- Liquidity, spread, circuit proximity and manipulation-risk gates.
- Catalyst taxonomy, primary-source-first news discovery, conservative clustering, source-independence counting and 3-source verification.
- Evidence confidence separate from setup score.
- Deterministic skeptic plus optional server-side AI skeptic.
- Hard no-force rule: no mandatory gate bypass.
- Paper lifecycle, fail-safe live-tick marking, gap-through-target skip handling, R metrics, drawdown, regime analytics and historical replay.
- Position-size calculator.
- Optional browser notifications; notifications are opt-in and do not require phone PII.
- Runtime coverage inventory for 100+ named parameters from the product specification.

## Data that is provider-dependent

Global US/Asia context, FII/DII, USD/INR, Brent, gold, current fundamentals, delivery percentage, full index membership lists, and expanded peer/sector maps are only accepted from an explicitly configured permitted provider or server-side dataset. The app never infers or fabricates these values.

For provider-dependent fields, the correct state is AVAILABLE or UNAVAILABLE. An unavailable field cannot silently become a made-up value.

### Optional server-side provider configuration

- `EAGLE_MACRO_PROVIDER_URL`: HTTPS JSON adapter for permitted macro context.
- `EAGLE_FUNDAMENTALS_JSON`: server-side current/approved fundamentals dataset.
- `EAGLE_DELIVERY_JSON`: server-side current/approved delivery dataset.
- `EAGLE_UNIVERSE_MAP_JSON`: permitted current index/cap-tier membership mapping.
- `EAGLE_CAP_TIER_MAP_JSON`: explicit cap-tier map; never inferred from stock price.
- `EAGLE_SECTOR_MAP_JSON`: explicit sector mapping.
- `NEWS_RSS_URLS`: optional permitted feeds; NSE/SEBI feeds are included by default.

## Angel One setup

Use `backend/.env.example` as the template. Configure the Angel One API credentials only on the backend. Never paste them into the chat or APK.

Automatic login needs:

- `ANGEL_API_KEY`
- `ANGEL_CLIENT_CODE`
- `ANGEL_PASSWORD`
- `ANGEL_TOTP_SECRET`

## Security/privacy

The native wrapper requests only `android.permission.INTERNET`. It disables cleartext remote traffic, file/content access and geolocation, rejects TLS certificate errors, restricts navigation to the configured backend origin, and uses Android Safe Browsing when available.

The web client does not call location, contacts, camera, microphone, device-motion, advertising-ID, analytics or telemetry APIs. App access tokens are held in session storage by the PWA, while broker secrets remain server-side.

Read `PRIVACY_SECURITY.md` and `HARDENING_REPORT.md` before deployment.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r backend/requirements.txt
cp backend/.env.example backend/.env
uvicorn run:app --host 0.0.0.0 --port 8000 --no-access-log
```

Open the service over HTTPS in production. Direct public exposure of the backend is not recommended; use an HTTPS reverse proxy or private network.

## Android APK

`android/` is a native WebView shell. It does not contain Angel One credentials and loads the PWA from a backend URL entered by the user.

A GitHub Actions workflow is included at `.github/workflows/android.yml`. It installs Java/Android SDK/Gradle on a hosted runner and outputs `app-debug.apk`.

The current execution environment used to produce this source package does not contain the Android SDK/Gradle toolchain, so a compiled APK cannot be truthfully attached from this environment. The source and CI workflow are included rather than a fabricated APK.

## Verification

Current local suite: 54 tests.

Run:

```bash
cd backend
pytest -q
```

and:

```bash
node --check frontend/app.js
python -m compileall -q backend
```

The system is intentionally read-only; it does not place broker orders.
