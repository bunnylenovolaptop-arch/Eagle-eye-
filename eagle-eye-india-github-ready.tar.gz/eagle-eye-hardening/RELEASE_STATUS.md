# Eagle Eye India — Release Status

## Current state

- Feature coverage: all 50 prompt sections represented in runtime code or explicit provider-gated states.
- Live market source: Angel One SmartAPI WebSocket 2.0 + REST adapter.
- Broker execution: disabled.
- Mobile permissions: INTERNET only.
- Secrets: backend-only.
- API/session security: enabled by default.
- Paper mode: validated Angel One ticks by default; manual revalue disabled.

## Verification

- Python test suite: 54/54 passing.
- Python compileall: PASS.
- Frontend JavaScript syntax: PASS.
- Android source/configuration: packaged and CI-buildable.

## APK status

A byte-for-byte compiled APK is **not included in this source release** because the current build environment does not contain the Android SDK/build-tools or Gradle distribution and has no external package-download access. The repository includes `.github/workflows/android.yml`, which provisions the Android SDK and Gradle on a GitHub-hosted runner and uploads `app-debug.apk`.

Do not interpret the source ZIP as a compiled APK.
