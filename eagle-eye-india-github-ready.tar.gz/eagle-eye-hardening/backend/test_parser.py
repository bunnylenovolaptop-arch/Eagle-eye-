import struct
from backend.main import parse_packet

def test_ltp_packet():
    b=bytearray(51)
    b[0]=1;b[1]=1;b[2:6]=b'3045'
    struct.pack_into('<q',b,27,123)
    struct.pack_into('<q',b,35,1700000000000)
    struct.pack_into('<q',b,43,123456)
    x=parse_packet(bytes(b))
    assert x['token']=='3045'
    assert x['ltp']==1234.56
    assert x['exchange_timestamp_ms']==1700000000000
