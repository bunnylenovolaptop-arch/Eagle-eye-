from __future__ import annotations
import json, os, math, time
import httpx

KEYS=('fii_activity','dii_activity','usd_inr','brent_crude','gold','us_context','asia_context')

def _finite(v):
    try:
        x=float(v); return x if math.isfinite(x) else None
    except Exception:
        return None

def local_context() -> dict:
    raw=os.getenv('EAGLE_MACRO_SNAPSHOT_JSON','').strip()
    if not raw: return {'status':'UNAVAILABLE','items':{},'source':'NONE','as_of_ms':None}
    try:
        obj=json.loads(raw)
        return {'status':'AVAILABLE','items':obj if isinstance(obj,dict) else {},'source':'SERVER_CONFIG','as_of_ms':int(time.time()*1000)}
    except Exception:
        return {'status':'UNAVAILABLE','items':{},'source':'INVALID_CONFIG','as_of_ms':None}

async def fetch_context() -> dict:
    url=os.getenv('EAGLE_MACRO_PROVIDER_URL','').strip()
    if not url:
        return local_context()
    if not url.lower().startswith('https://'):
        return {'status':'UNAVAILABLE','items':{},'source':'REJECTED_NON_HTTPS','as_of_ms':None}
    try:
        async with httpx.AsyncClient(timeout=8, follow_redirects=False) as client:
            r=await client.get(url,headers={'Accept':'application/json','User-Agent':'EagleEyeIndia/1.0'})
            r.raise_for_status(); obj=r.json()
        if not isinstance(obj,dict): raise ValueError('provider_not_object')
        # Preserve only known fields plus provider metadata; absence stays absent.
        items={k:obj.get(k) for k in KEYS if obj.get(k) is not None}
        return {'status':'AVAILABLE' if items else 'UNAVAILABLE','items':items,'source':'CONFIGURED_PROVIDER','as_of_ms':int(time.time()*1000),'provider_http_status':r.status_code}
    except Exception:
        return {'status':'UNAVAILABLE','items':{},'source':'PROVIDER_ERROR','as_of_ms':None}
