from backend.decision import score_setup, build_levels
from backend.derivatives import derivative_snapshot
from backend.liquidity import assess_liquidity
from backend.paper import init_db, log_trade, update_from_price, metrics, DB_PATH
from backend.skeptic import run_skeptic

def base_tech():
    return {'valid':True,'direction':'LONG','score_pct':80,'last_price':100,'relative_volume20':2.1,'rsi14':60,'relative_strength_vs_nifty':1.4,'vwap':98,'indicators':{'atr14':1.5}}

def base_evidence():
    return {'catalyst':{'strength':20},'verification':{'verification':'3/3 VERIFIED','evidence_confidence':'HIGH'},'freshness':{'status':'FRESH'},'contradictions':[]}

def base_sector(): return {'available':True,'change_pct':1.0,'relative_vs_nifty':0.4}
def base_liq(): return {'pass':True,'level':'HIGH','traded_value_inr':300_000_000}

def test_score_requires_all_gates():
    t=base_tech(); e=base_evidence(); tick={'ltp':100,'close':98,'received_timestamp_ms':1000,'data_status':'LIVE'}
    levels={'valid':True,'risk_reward':2.0,'trigger':101,'stop':99,'target1':104,'target2':106}
    d={'applicable':False,'available':False,'bias':'NEUTRAL'}
    s=score_setup(technical=t,evidence=e,tick=tick,regime={'regime':'MILD BULLISH'},levels=levels,sector=base_sector(),derivatives=d,liquidity=base_liq(),skeptic={'status':'PASS','thesis_survives':True})
    assert s['status']=='TRADE-READY' and s['all_mandatory_pass'] is True and s['score']==96

def test_score_blocks_missing_sector():
    t=base_tech(); e=base_evidence(); tick={'ltp':100,'close':98,'received_timestamp_ms':1000,'data_status':'LIVE'}
    levels={'valid':True,'risk_reward':2.0}
    s=score_setup(technical=t,evidence=e,tick=tick,regime={'regime':'MILD BULLISH'},levels=levels,sector={'available':False},derivatives={'applicable':False},liquidity=base_liq(),skeptic={'status':'PASS','thesis_survives':True})
    assert s['all_mandatory_pass'] is False
    assert s['status'] != 'TRADE-READY'

def test_liquidity_detects_wide_spread():
    t={'ltp':100,'volume_trade_for_day':1_000_000,'depth':{'buy':[{'price':99,'quantity':100}], 'sell':[{'price':101,'quantity':100}]}}
    assert assess_liquidity(t,50_000_000)['level']=='LOW'

def test_derivative_pcr():
    sel={'spot':100,'expiry':'2026-10-29'}
    qs=[{'symbolToken':'1','tradingSymbol':'XCE','optiontype':'CE','opnInterest':100},{'symbolToken':'2','tradingSymbol':'XPE','optiontype':'PE','opnInterest':200}]
    d=derivative_snapshot(sel,qs,{})
    assert d['available'] is True and d['pcr']==2.0 and d['bias']=='BULLISH'

def test_skeptic_invalidates_conflicting_regime():
    s=run_skeptic({'valid':True,'direction':'LONG','relative_volume20':2,'relative_strength_vs_nifty':1,'rsi14':60}, {'contradictions':[],'freshness':{'status':'FRESH'}},{'ltp':100},{'regime':'STRONG BEARISH'},{'valid':True,'stop':95},{'available':True},{'applicable':False},{'level':'HIGH'})
    assert s['status']=='WEAKENED' and s['thesis_survives'] is False

def test_paper_trade_lifecycle(tmp_path, monkeypatch):
    p=tmp_path/'paper.sqlite3'; monkeypatch.setattr('backend.paper.DB_PATH',p); init_db()
    x=log_trade({'symbol':'TEST','direction':'LONG','entry_trigger':100,'stop':98,'target1':103,'target2':105})
    assert x['status'] is True
    update_from_price('TEST',101,1000); update_from_price('TEST',105,2000)
    m=metrics(); assert m['trades']==1 and m['win_rate']==100.0 and m['avg_r']>0

import struct
from backend.main import parse_packet
from backend.sector import sector_for_symbol

def test_snapquote_parses_best_five_and_oi():
    b=bytearray(579)
    b[0]=3; b[1]=1; b[2:6]=b'3045'
    struct.pack_into('<q',b,27,1); struct.pack_into('<q',b,35,1700000000000); struct.pack_into('<i',b,43,123450)
    for off,val in [(51,10),(59,10000),(67,500000),(75,100000),(83,90000),(91,12000),(99,12100),(107,11800),(115,11900),(123,1700000000000),(131,250000)]: struct.pack_into('<q',b,off,val)
    struct.pack_into('<q',b,347,13000); struct.pack_into('<q',b,355,11000); struct.pack_into('<q',b,363,15000); struct.pack_into('<q',b,371,9000)
    struct.pack_into('<h',b,379,1); struct.pack_into('<q',b,381,500); struct.pack_into('<q',b,389,11950); struct.pack_into('<h',b,397,3)
    x=parse_packet(bytes(b))
    assert x['ltp']==1234.5 and x['open_interest']==250000 and x['depth']['buy'][0]['price']==119.5 and x['depth']['buy'][0]['orders']==3

def test_known_sector_map_is_conservative():
    assert sector_for_symbol('TATAMOTORS-EQ')=='AUTO'
    assert sector_for_symbol('UNKNOWNXYZ-EQ') is None
