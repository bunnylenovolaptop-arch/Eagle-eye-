from __future__ import annotations


def _market_compatibility(direction: str, regime: str) -> tuple[int, str]:
    if direction == 'LONG':
        if regime in ('STRONG BULLISH', 'MILD BULLISH'): return 10, 'Aligned with bullish market regime'
        if regime in ('STRONG BEARISH', 'MILD BEARISH'): return 2, 'Long direction conflicts with bearish market regime'
        if regime == 'HIGH VOLATILITY': return 4, 'Direction possible but volatility is elevated'
        if regime == 'NEUTRAL': return 6, 'Market regime is neutral'
    if direction == 'SHORT':
        if regime in ('STRONG BEARISH', 'MILD BEARISH'): return 10, 'Aligned with bearish market regime'
        if regime in ('STRONG BULLISH', 'MILD BULLISH'): return 2, 'Short direction conflicts with bullish market regime'
        if regime == 'HIGH VOLATILITY': return 4, 'Direction possible but volatility is elevated'
        if regime == 'NEUTRAL': return 6, 'Market regime is neutral'
    return 0, 'Market compatibility unavailable'


def build_levels(technical: dict, candles: list | None) -> dict:
    if not technical.get('valid') or not candles:
        return {'valid': False, 'reason': 'TECHNICAL_DATA_UNAVAILABLE'}
    price = float(technical.get('last_price') or 0)
    direction = technical.get('direction') or 'NEUTRAL'
    atr = ((technical.get('indicators') or {}).get('atr14'))
    if not price or direction not in ('LONG', 'SHORT') or atr in (None, 0):
        return {'valid': False, 'reason': 'NO_DIRECTION_OR_ATR'}
    recent = candles[-20:]
    highs = [float(x[2]) for x in recent if len(x) >= 6]
    lows = [float(x[3]) for x in recent if len(x) >= 6]
    if not highs or not lows:
        return {'valid': False, 'reason': 'NO_RECENT_LEVELS'}
    prior_high = max(highs[:-1] or highs)
    prior_low = min(lows[:-1] or lows)
    buffer = 0.10 * float(atr)
    if direction == 'LONG':
        trigger = max(price + buffer, prior_high + buffer)
        stop = max(0.01, min(price - atr, prior_low - 0.25 * atr))
        target1 = trigger + 1.5 * atr
        target2 = trigger + 2.5 * atr
    else:
        trigger = min(price - buffer, prior_low - buffer)
        stop = max(price + atr, prior_high + 0.25 * atr)
        target1 = trigger - 1.5 * atr
        target2 = trigger - 2.5 * atr
    risk = abs(trigger - stop)
    reward1 = abs(target1 - trigger)
    reward2 = abs(target2 - trigger)
    rr = reward1 / risk if risk else None
    valid_geometry = risk > 0 and ((direction == 'LONG' and stop < trigger < target1 < target2) or (direction == 'SHORT' and stop > trigger > target1 > target2))
    return {
        'valid': bool(valid_geometry), 'direction': direction, 'current_price': price,
        'trigger': round(trigger, 2), 'stop': round(stop, 2),
        'target1': round(target1, 2), 'target2': round(target2, 2),
        'risk_per_share': round(risk, 2), 'reward1_per_share': round(reward1, 2),
        'reward2_per_share': round(reward2, 2), 'risk_reward': round(rr, 2) if rr is not None else None,
        'invalidation': f'Break beyond the stop level ({stop:.2f}) invalidates the proposed {direction.lower()} setup.',
    }


def _risk_reward_points(rr: float | None) -> int:
    if rr is None: return 0
    if rr >= 2.5: return 10
    if rr >= 2.0: return 9
    if rr >= 1.5: return 8
    if rr >= 1.25: return 5
    return 0


def score_setup(*, technical: dict, evidence: dict, tick: dict, regime: dict, levels: dict,
                sector: dict, derivatives: dict, liquidity: dict, skeptic: dict, cap_context: dict|None=None) -> dict:
    direction = technical.get('direction') or 'NEUTRAL'
    catalyst_strength = int((evidence.get('catalyst') or {}).get('strength') or 0)
    verification = (evidence.get('verification') or {}).get('verification', 'UNVERIFIED')
    credibility = {'3/3 VERIFIED': 10, '2/3 VERIFIED': 6, '1/3 VERIFIED': 3}.get(verification, 0)

    technical_score = round(15 * float(technical.get('score_pct') or 0) / 100)
    relvol = float(technical.get('relative_volume20') or 0)
    volume = 10 if relvol >= 2.0 else 8 if relvol >= 1.5 else 4 if relvol >= 1.0 else 0
    rs = technical.get('relative_strength_vs_nifty')
    relative_strength = 10 if ((direction == 'LONG' and rs is not None and rs >= 1) or (direction == 'SHORT' and rs is not None and rs <= -1)) else 5 if rs is not None and abs(rs) >= 0.4 else 0

    if sector.get('available'):
        sec_rel = sector.get('relative_vs_nifty')
        if sec_rel is None:
            sector_points = 2
        elif (direction == 'LONG' and sec_rel >= 0) or (direction == 'SHORT' and sec_rel <= 0):
            sector_points = 5
        else:
            sector_points = 1
    else:
        sector_points = 0

    market_points, market_reason = _market_compatibility(direction, regime.get('regime', 'UNAVAILABLE'))
    liquidity_points = 5 if liquidity.get('level') == 'HIGH' else 3 if liquidity.get('level') == 'MEDIUM' else 0

    if not derivatives.get('applicable'):
        derivative_points = 5  # N/A is neutral in the fixed 100-point framework.
    elif derivatives.get('available'):
        bias = derivatives.get('bias', 'NEUTRAL')
        aligned = (direction == 'LONG' and bias in ('LONG', 'BULLISH', 'NEUTRAL')) or (direction == 'SHORT' and bias in ('SHORT', 'BEARISH', 'NEUTRAL'))
        derivative_points = 5 if aligned else 1
    else:
        derivative_points = 0

    rr = levels.get('risk_reward') if levels else None
    risk_reward = _risk_reward_points(rr)

    total = sum([catalyst_strength, credibility, technical_score, volume, relative_strength, sector_points, market_points, liquidity_points, derivative_points, risk_reward])

    cap_context = cap_context or {}
    tier_floor = cap_context.get('evidence_floor_pass', True)
    has_major_catalyst = catalyst_strength > 0
    verification_pass = (not has_major_catalyst and (evidence.get('freshness') or {}).get('status') not in ('STALE', 'NO_NEWS')) or verification == '3/3 VERIFIED'
    skeptic_ok = skeptic.get('status') == 'PASS' and skeptic.get('thesis_survives') is True
    mandatory = {
        'reliable_current_data': bool(tick) and tick.get('data_status', 'LIVE') not in ('STALE', 'UNAVAILABLE'),
        'valid_setup': direction in ('LONG', 'SHORT') and bool(technical.get('valid')) and bool(levels.get('valid')),
        'catalyst_or_meaningful_reason': has_major_catalyst or technical_score >= 10,
        'technical_confirmation': technical_score >= 9,
        'volume_confirmation': volume >= 7,
        'acceptable_liquidity': liquidity_points >= 3,
        'acceptable_risk_reward': risk_reward >= 8,
        'no_major_contradiction': not bool(evidence.get('contradictions')),
        'market_regime_compatibility': market_points >= 6,
        'skeptic_does_not_invalidate': skeptic_ok,
        'sector_confirmation': sector.get('available') is True,
        'catalyst_verification': verification_pass,
        'cap_tier_evidence_floor': bool(tier_floor),
    }
    if derivatives.get('applicable'):
        mandatory['derivatives_context'] = derivatives.get('available') is True

    gate_pass = all(mandatory.values())
    status = 'TRADE-READY' if gate_pass and total >= 75 else ('WAIT FOR TRIGGER' if total >= 55 else 'WATCHLIST')
    if not gate_pass and total >= 75:
        status = 'WAIT FOR TRIGGER'

    evidence_conf = (evidence.get('verification') or {}).get('evidence_confidence', 'LOW')
    if has_major_catalyst and evidence_conf != 'HIGH':
        # A major catalyst with less than 3/3 verification cannot be trade-ready.
        if status == 'TRADE-READY': status = 'WAIT FOR TRIGGER'

    return {
        'score': total, 'max_score': 100,
        'components': {
            'catalyst_strength': catalyst_strength,
            'catalyst_credibility': credibility,
            'technical_structure': technical_score,
            'volume': volume,
            'relative_strength': relative_strength,
            'sector_strength': sector_points,
            'market_compatibility': market_points,
            'liquidity': liquidity_points,
            'derivatives': derivative_points,
            'risk_reward': risk_reward,
        },
        'mandatory_gates': mandatory,
        'all_mandatory_pass': gate_pass,
        'status': status,
        'market_reason': market_reason,
        'evidence_confidence': evidence_conf,
        'risk_reward': rr,
    }
