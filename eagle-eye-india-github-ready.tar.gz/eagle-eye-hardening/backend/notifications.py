from __future__ import annotations
import time, hashlib

class NotificationRegistry:
    def __init__(self): self.events={}
    def key(self, kind:str, symbol:str, trigger:str=''):
        return hashlib.sha256(f'{kind}|{symbol}|{trigger}'.encode()).hexdigest()
    def emit_once(self, kind, symbol, title, body, trigger=''):
        k=self.key(kind,symbol,trigger)
        if k in self.events: return None
        ev={'id':k,'type':kind,'symbol':symbol,'title':title,'body':body,'created_at_ms':int(time.time()*1000)}
        self.events[k]=ev; return ev
    def recent(self, limit=50): return list(self.events.values())[-limit:]
