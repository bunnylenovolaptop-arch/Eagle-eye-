import os
import struct
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from backend import main
from backend.main import parse_packet, validate_tick
from backend.paper import DB_PATH, init_db, log_trade, update_from_price, metrics


def _auth_client(monkeypatch, tmp_path):
    monkeypatch.setattr(main, 'security_sessions', main.SessionStore(3600))
    monkeypatch.setattr(main, 'login_limiter', main.SlidingWindowLimiter())
    monkeypatch.setattr(main, 'request_limiter', main.SlidingWindowLimiter())
    monkeypatch.setattr(main.settings, 'EAGLE_REQUIRE_AUTH', True)
    monkeypatch.setattr(main.settings, 'EAGLE_ACCESS_TOKEN', 'test-access-token')
    monkeypatch.setattr(main.settings, 'EAGLE_COOKIE_SECURE', False)
    monkeypatch.setattr(main.settings, 'EAGLE_ALLOW_NON_BROWSER_API', False)
    monkeypatch.setattr(main, '_allowed_origins', [])
    monkeypatch.setattr(main, 'latest', {})
    monkeypatch.setattr(main, 'paper_open_symbols', set())
    monkeypatch.setattr('backend.paper.DB_PATH', tmp_path / 'paper.sqlite3')
    return TestClient(main.app)


def test_private_api_is_locked_and_login_sets_http_only_cookie(monkeypatch, tmp_path):
    with _auth_client(monkeypatch, tmp_path) as client:
        r = client.get('/api/healthz')
        assert r.status_code == 200
        r = client.get('/api/status')
        assert r.status_code == 401
        r = client.post('/api/auth/login', json={'access_token': 'wrong'})
        assert r.status_code == 401
        r = client.post('/api/auth/login', json={'access_token': 'test-access-token'}, headers={'Origin': 'http://testserver'})
        assert r.status_code == 200
        cookie = r.headers['set-cookie'].lower()
        assert 'httponly' in cookie and 'samesite=strict' in cookie
        assert 'test-access-token' not in cookie
        r = client.get('/api/status')
        assert r.status_code == 200


def test_state_changing_request_requires_origin(monkeypatch, tmp_path):
    with _auth_client(monkeypatch, tmp_path) as client:
        client.post('/api/auth/login', json={'access_token': 'test-access-token'}, headers={'Origin': 'http://testserver'})
        r = client.post('/api/paper/revalue', json={'symbol': 'TEST', 'price': 100})
        assert r.status_code == 403


def test_service_worker_never_caches_api():
    sw = Path('/mnt/data/eagle-eye-hardening/frontend/sw.js').read_text()
    assert "u.pathname.includes('/api/')" in sw
    assert "caches.open(CACHE).then(c=>c.put(event.request,copy))" in sw
    assert "/api/" in sw and "return;" in sw


def test_parser_uses_64bit_ltp_and_documented_depth_flags():
    b = bytearray(579)
    b[0] = 3
    b[1] = 1
    b[2:6] = b'3045'
    struct.pack_into('<q', b, 27, 10)
    struct.pack_into('<q', b, 35, 1760000000000)
    struct.pack_into('<q', b, 43, 123456)
    struct.pack_into('<q', b, 51, 10)
    struct.pack_into('<q', b, 59, 10000)
    struct.pack_into('<q', b, 67, 1000000)
    struct.pack_into('<d', b, 75, 250000.0)
    struct.pack_into('<d', b, 83, 150000.0)
    for off, val in [(91, 12000), (99, 12100), (107, 11800), (115, 11900), (123, 1760000000000), (131, 250000), (347, 13000), (355, 11000), (363, 15000), (371, 9000)]:
        struct.pack_into('<q', b, off, val)
    struct.pack_into('<h', b, 379, 1)
    struct.pack_into('<q', b, 381, 500)
    struct.pack_into('<q', b, 389, 11950)
    struct.pack_into('<h', b, 397, 3)
    x = parse_packet(bytes(b))
    assert x['ltp'] == 1234.56
    assert x['total_buy_quantity'] == 250000.0
    assert x['depth']['buy'][0]['price'] == 119.5


def test_validate_tick_rejects_old_and_out_of_order():
    now = main.now_ms()
    base = {'token': '1', 'exchange_type': 1, 'ltp': 100, 'exchange_timestamp_ms': now, 'received_timestamp_ms': now, 'sequence': 2}
    assert validate_tick(base, 1)[0] is True
    assert validate_tick({**base, 'sequence': 1}, 2) == (False, 'OUT_OF_ORDER_SEQUENCE')
    assert validate_tick({**base, 'exchange_timestamp_ms': now - 70_000}) == (False, 'EXCHANGE_TICK_TOO_OLD')


def test_paper_trade_rejects_bad_geometry(tmp_path, monkeypatch):
    monkeypatch.setattr('backend.paper.DB_PATH', tmp_path / 'paper.sqlite3')
    init_db()
    x = log_trade({'symbol': 'TEST', 'direction': 'LONG', 'entry_trigger': 100, 'stop': 101, 'target1': 103, 'target2': 105})
    assert x['status'] is False and x['errorcode'] == 'EE_PAPER_VALIDATION'


def test_paper_trade_live_tick_state_machine_and_ordering(tmp_path, monkeypatch):
    monkeypatch.setattr('backend.paper.DB_PATH', tmp_path / 'paper.sqlite3')
    init_db()
    x = log_trade({'symbol': 'TEST', 'direction': 'LONG', 'entry_trigger': 100, 'stop': 98, 'target1': 103, 'target2': 105})
    assert x['status'] is True
    r1 = update_from_price('TEST', 99, 1000, market_time_ms=1000)
    assert r1['closed_ids'] == []
    r2 = update_from_price('TEST', 101, 2000, market_time_ms=2000)
    assert r2['closed_ids'] == []
    # Older tick cannot rewrite the state.
    r3 = update_from_price('TEST', 99, 3000, market_time_ms=1500)
    assert r3['changed_ids'] == []
    r4 = update_from_price('TEST', 105, 4000, market_time_ms=4000)
    assert r4['closed_ids']
    m = metrics()
    assert m['trades'] == 1 and m['win_rate'] == 100.0


def test_manual_revalue_is_disabled_by_default(monkeypatch, tmp_path):
    with _auth_client(monkeypatch, tmp_path) as client:
        client.post('/api/auth/login', json={'access_token': 'test-access-token'}, headers={'Origin': 'http://testserver'})
        r = client.post('/api/paper/revalue', json={'symbol': 'TEST', 'price': 100}, headers={'Origin': 'http://testserver'})
        assert r.status_code == 200
        assert r.json()['errorcode'] == 'EE_MANUAL_REVALUE_DISABLED'


def test_paper_gap_through_target_is_skipped_not_counted_as_win(tmp_path, monkeypatch):
    monkeypatch.setattr('backend.paper.DB_PATH', tmp_path / 'paper.sqlite3')
    init_db()
    x = log_trade({'symbol': 'GAP', 'direction': 'LONG', 'entry_trigger': 100, 'stop': 98, 'target1': 103, 'target2': 105})
    assert x['status'] is True
    r = update_from_price('GAP', 110, 2000, market_time_ms=2000)
    assert r['closed_ids'] == [] and r['changed_ids']
    trades = __import__('backend.paper', fromlist=['list_trades']).list_trades()
    row = next(t for t in trades if t['id'] == x['id'])
    assert row['status'] == 'SKIPPED'
    assert row['outcome'] == 'SKIPPED'
    assert row['exit_reason'] == 'ENTRY_GAP_THROUGH_TARGET'
    assert metrics()['trades'] == 0


def test_session_models_current_cash_auction_window():
    from datetime import datetime
    from zoneinfo import ZoneInfo
    ist = ZoneInfo('Asia/Kolkata')
    s = __import__('backend.session', fromlist=['session_phase'])
    a = s.session_phase(datetime(2026, 10, 1, 15, 21, tzinfo=ist))
    b = s.session_phase(datetime(2026, 10, 1, 15, 34, tzinfo=ist))
    c = s.session_phase(datetime(2026, 10, 1, 15, 36, tzinfo=ist))
    assert a['phase'] == 'CAS ORDER ENTRY' and a['is_cas_window'] is True
    assert b['phase'] == 'CAS MATCHING' and b['is_cas_window'] is True
    assert c['phase'] == 'POST-CLOSING TRANSITION' and c['is_cash_market_open'] is False


def test_frontend_has_no_phone_collection_apis_and_no_persistent_token_storage():
    html = Path('/mnt/data/eagle-eye-hardening/frontend/index.html').read_text().lower()
    js = Path('/mnt/data/eagle-eye-hardening/frontend/app.js').read_text().lower()
    forbidden = ['navigator.geolocation', 'navigator.contacts', 'getusermedia', 'deviceorientation', 'accelerometer', 'localstorage', 'indexeddb']
    assert not any(x in html + js for x in forbidden)
    assert 'sessionstorage' in js
    assert 'credentials:\'include\'' in js
    assert 'api_access_token' not in js


def test_api_docs_disabled_by_default_and_security_endpoint_reports_read_only(monkeypatch, tmp_path):
    with _auth_client(monkeypatch, tmp_path) as client:
        assert client.get('/docs').status_code == 404
        client.post('/api/auth/login', json={'access_token': 'test-access-token'}, headers={'Origin': 'http://testserver'})
        r = client.get('/api/system/security')
        assert r.status_code == 200
        data = r.json()
        assert data['privacy']['location_access'] is False
        assert data['privacy']['device_identifier'] is False
        assert data['security']['api_keys_in_mobile'] is False
        assert data['security']['read_only_default'] is True
        assert data['security']['provider_raw_control_messages_forwarded'] is False


def test_subscribe_is_idempotent_and_does_not_double_count_capacity(monkeypatch, tmp_path):
    with _auth_client(monkeypatch, tmp_path) as client:
        client.post('/api/auth/login', json={'access_token': 'test-access-token'}, headers={'Origin': 'http://testserver'})
        monkeypatch.setattr(main.settings, 'ANGEL_FEED_TOKEN', 'feed')
        monkeypatch.setattr(main.settings, 'ANGEL_API_KEY', 'key')
        monkeypatch.setattr(main.settings, 'ANGEL_CLIENT_CODE', 'client')
        monkeypatch.setattr(main, 'extra_tokens', set())
        monkeypatch.setattr(main, 'extra_tokens_by_exchange', {})
        monkeypatch.setattr(main, 'stream_tasks', [])
        async def _noop_stream(*args, **kwargs):
            return None
        monkeypatch.setattr(main, 'angel_stream', _noop_stream)
        r1 = client.post('/api/subscribe', json={'tokens': ['123'], 'exchange_type': 1}, headers={'Origin': 'http://testserver'})
        assert r1.status_code == 200 and r1.json()['new_tokens'] == ['123']
        # No additional capacity consumed for the same token.
        r2 = client.post('/api/subscribe', json={'tokens': ['123'], 'exchange_type': 1}, headers={'Origin': 'http://testserver'})
        assert r2.status_code == 200 and r2.json()['new_tokens'] == []


def test_live_status_is_not_derived_from_socket_connection_only(monkeypatch, tmp_path):
    with _auth_client(monkeypatch, tmp_path) as client:
        client.post('/api/auth/login', json={'access_token': 'test-access-token'}, headers={'Origin': 'http://testserver'})
        monkeypatch.setattr(main, 'latest', {})
        r = client.get('/api/status')
        assert r.status_code == 200
        assert r.json()['data_status'] == 'UNAVAILABLE'


def test_parser_rejects_unknown_depth_flag():
    import struct
    b = bytearray(579)
    b[0] = 3
    b[1] = 1
    b[2:6] = b'3045'
    struct.pack_into('<q', b, 27, 10)
    struct.pack_into('<q', b, 35, 1760000000000)
    struct.pack_into('<q', b, 43, 123456)
    struct.pack_into('<h', b, 379, 2)
    struct.pack_into('<q', b, 381, 500)
    struct.pack_into('<q', b, 389, 11950)
    struct.pack_into('<h', b, 397, 3)
    with pytest.raises(ValueError, match='depth'):
        parse_packet(bytes(b))


def test_validate_tick_rejects_nonfinite_and_invalid_ohlc():
    now = main.now_ms()
    base = {'token': '1', 'exchange_type': 2, 'ltp': 100, 'exchange_timestamp_ms': now, 'received_timestamp_ms': now, 'sequence': 2}
    assert validate_tick({**base, 'ltp': float('nan')}) == (False, 'INVALID_LTP')
    assert validate_tick({**base, 'high': 110, 'low': 90, 'open': 120, 'close': 100}) == (False, 'INVALID_OPEN_RANGE')


def test_paper_rejects_market_event_time_drift(tmp_path, monkeypatch):
    monkeypatch.setattr('backend.paper.DB_PATH', tmp_path / 'paper.sqlite3')
    init_db()
    x = log_trade({'symbol': 'TIME', 'direction': 'LONG', 'entry_trigger': 100, 'stop': 98, 'target1': 103, 'target2': 105})
    assert x['status'] is True
    assert update_from_price('TIME', 101, 10_000, market_time_ms=20_000)['rejected'] == 'MARKET_TIMESTAMP_IN_FUTURE'
    assert update_from_price('TIME', 101, 80_000, market_time_ms=10_000)['rejected'] == 'MARKET_TIMESTAMP_TOO_OLD'


def test_snapquote_rejects_partial_best_five_extension():
    import struct
    from .main import parse_packet
    b=bytearray(400)
    b[0]=3; b[1]=1; b[2:6]=b'3045'
    struct.pack_into('<q',b,27,1)
    struct.pack_into('<q',b,35,1700000000000)
    struct.pack_into('<q',b,43,123456)
    # 400 bytes is neither 379-byte core nor full 579-byte best-five packet.
    try:
        parse_packet(bytes(b))
        assert False, 'expected partial best-five packet rejection'
    except ValueError as exc:
        assert 'invalid snapquote packet length' in str(exc)

def test_snapquote_core_length_379_is_accepted():
    import struct
    from .main import parse_packet
    b=bytearray(379)
    b[0]=3; b[1]=1; b[2:6]=b'3045'
    struct.pack_into('<q',b,27,1)
    struct.pack_into('<q',b,35,1760000000000)
    struct.pack_into('<q',b,43,123456)
    struct.pack_into('<q',b,131,1000)
    struct.pack_into('<q',b,347,12000)
    struct.pack_into('<q',b,355,8000)
    struct.pack_into('<q',b,363,20000)
    struct.pack_into('<q',b,371,5000)
    x=parse_packet(bytes(b))
    assert x['ltp']==1234.56 and x['open_interest']==1000
    assert x['depth']=={'buy':[],'sell':[]}
