from __future__ import annotations
import json, os

UNIVERSES = ('NIFTY50','NIFTY100','NIFTY200','NIFTY500','MIDCAP','SMALLCAP','MICRO','PENNY','SME','FNO')

def _load() -> dict[str,set[str]]:
    raw=os.getenv('EAGLE_UNIVERSE_MAP_JSON','').strip()
    if not raw: return {}
    try:
        obj=json.loads(raw)
        return {str(k).upper(): {str(v).upper() for v in vals} for k,vals in obj.items() if isinstance(vals,list)} if isinstance(obj,dict) else {}
    except Exception:
        return {}

def universe_membership(symbol: str, inst: dict|None=None) -> set[str]:
    s=str(symbol or '').upper().replace('-EQ','').replace('-BE','')
    out={k for k, vals in _load().items() if s in vals}
    inst=inst or {}
    if str(inst.get('exch_seg') or '').upper() in {'NFO','BFO'}:
        out.add('FNO')
    series=str(inst.get('series') or '').upper()
    if 'SME' in str(inst.get('symbol') or '').upper() or series in {'SM','ST'}:
        out.add('SME')
    return out

def passes_universe(symbol: str, inst: dict|None, requested: str) -> bool:
    u=str(requested or 'ALL').upper()
    if u in ('ALL','ALL LIVE',''):
        return True
    return u in universe_membership(symbol,inst)
