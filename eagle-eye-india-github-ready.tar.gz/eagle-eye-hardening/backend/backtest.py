from __future__ import annotations
import math
try:
    from .technical import analyze
    from .decision import build_levels
except ImportError:
    from technical import analyze
    from decision import build_levels

def _move_r(direction, entry, stop, price):
    risk=abs(entry-stop)
    if not risk: return None
    return ((price-entry)/risk) if direction=='LONG' else ((entry-price)/risk)

def replay(symbol: str, candles: list[list], max_bars: int = 5000) -> dict:
    rows=[c for c in (candles or []) if len(c)>=6][:max_bars]
    closed=[]; skipped=0
    for i in range(60,len(rows)-1):
        window=rows[:i+1]
        try: tech=analyze(window)
        except Exception: continue
        if not tech.get('valid'): continue
        levels=build_levels(tech,window)
        if not levels.get('valid'): continue
        direction=levels['direction']; trig=levels['trigger']; stop=levels['stop']; t1=levels['target1']; t2=levels['target2']
        nextbar=rows[i+1]
        high,low=float(nextbar[2]),float(nextbar[3])
        entry=None; outcome=None; exit_price=None
        if direction=='LONG':
            if low<=stop and high>=trig: # ambiguous same-bar path; fail closed.
                skipped+=1; continue
            if high>=trig: entry=trig
            if entry is None: continue
            if high>=t2: outcome='TARGET2'; exit_price=t2
            elif low<=stop: outcome='STOP'; exit_price=stop
            else: continue
        else:
            if high>=stop and low<=trig:
                skipped+=1; continue
            if low<=trig: entry=trig
            if entry is None: continue
            if low<=t2: outcome='TARGET2'; exit_price=t2
            elif high>=stop: outcome='STOP'; exit_price=stop
            else: continue
        r=_move_r(direction,entry,stop,exit_price)
        closed.append({'bar_index':i+1,'direction':direction,'entry':entry,'stop':stop,'target':t2,'exit':exit_price,'outcome':outcome,'r':round(r,4) if r is not None else None})
    rs=[x['r'] for x in closed if x['r'] is not None]
    wins=[r for r in rs if r>0]; losses=[r for r in rs if r<0]
    gross_win=sum(wins); gross_loss=abs(sum(losses)); equity=0; peak=0; dd=0
    for r in rs:
        equity+=r; peak=max(peak,equity); dd=min(dd,equity-peak)
    return {'status':True,'symbol':symbol,'trades':len(closed),'skipped_ambiguous':skipped,'win_rate_pct':round(len(wins)/len(rs)*100,2) if rs else None,'avg_r':round(sum(rs)/len(rs),4) if rs else None,'profit_factor':round(gross_win/gross_loss,4) if gross_loss else None,'max_drawdown_r':round(dd,4),'trades_detail':closed[-200:]}
