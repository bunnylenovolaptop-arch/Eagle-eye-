from __future__ import annotations
from datetime import datetime, time as dtime
from zoneinfo import ZoneInfo

IST = ZoneInfo('Asia/Kolkata')


def session_phase(now: datetime | None = None) -> dict:
    now = now or datetime.now(IST)
    t = now.timetz().replace(tzinfo=None)
    if t < dtime(9,0): phase='PRE-MARKET'
    elif t < dtime(9,10): phase='PRE-OPEN'
    elif t < dtime(9,15): phase='PRE-OPEN BUFFER'
    elif t < dtime(10,0): phase='OPENING DISCOVERY'
    elif t < dtime(12,0): phase='MORNING TREND'
    elif t < dtime(14,0): phase='MIDDAY LOW-VOLUME WINDOW'
    elif t < dtime(15,0): phase='CLOSING MOMENTUM'
    elif t < dtime(15,20): phase='FINAL CONTINUOUS WINDOW'
    elif t < dtime(15,30): phase='CAS ORDER ENTRY'
    elif t < dtime(15,35): phase='CAS MATCHING'
    elif t < dtime(15,50): phase='POST-CLOSING TRANSITION'
    elif t < dtime(16,0): phase='CLOSING SESSION'
    else: phase='AFTER-HOURS'
    is_cash_open=dtime(9,15)<=t<dtime(15,30)
    is_cash_continuous=dtime(9,15)<=t<dtime(15,20)
    is_closing_auction=dtime(15,20)<=t<dtime(15,35)
    is_fno_window=dtime(9,15)<=t<dtime(15,40)
    return {
        'phase':phase,'date_ist':now.strftime('%Y-%m-%d'),'time_ist':now.strftime('%H:%M:%S'),
        'is_cash_market_open':is_cash_open,'is_cash_continuous':is_cash_continuous,
        'is_closing_auction':is_closing_auction,'is_cas_window':is_closing_auction,
        'is_cash_post_close':t>=dtime(15,35),'is_fno_window':is_fno_window,
        'trade_analysis_window':is_cash_continuous or is_fno_window,
        'cash_normal_close':'15:30 IST','closing_auction_order_entry':'15:20-15:30 IST','fno_normal_close':'15:40 IST'
    }
