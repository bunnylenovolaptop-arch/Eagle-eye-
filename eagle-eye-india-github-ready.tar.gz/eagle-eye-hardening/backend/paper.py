from __future__ import annotations

import hashlib
import json
import math
import os
import sqlite3
import threading
import time
from pathlib import Path
from typing import Optional

DB_PATH = Path(os.getenv('EAGLE_PAPER_DB', Path(__file__).resolve().parent / 'eagle_eye_paper.sqlite3'))
_lock = threading.RLock()

ALLOWED_DIRECTIONS = {'LONG', 'SHORT'}
ALLOWED_VERIFICATION = {'3/3 VERIFIED', '2/3 VERIFIED', '1/3 VERIFIED', 'UNVERIFIED', '3-SOURCE VERIFICATION UNAVAILABLE'}
ALLOWED_EVIDENCE = {'HIGH', 'MEDIUM', 'LOW'}


def _conn():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DB_PATH, timeout=5.0)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('PRAGMA synchronous=FULL')
    c.execute('PRAGMA foreign_keys=ON')
    c.execute('PRAGMA busy_timeout=5000')
    return c


def _safe_chmod():
    try:
        os.chmod(DB_PATH, 0o600)
        for suffix in ('-wal', '-shm'):
            p = Path(str(DB_PATH) + suffix)
            if p.exists():
                os.chmod(p, 0o600)
    except OSError:
        pass


def init_db():
    with _lock, _conn() as c:
        c.execute('''CREATE TABLE IF NOT EXISTS paper_trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_ms INTEGER NOT NULL,
            updated_ms INTEGER NOT NULL,
            symbol TEXT NOT NULL,
            direction TEXT NOT NULL,
            entry_trigger REAL NOT NULL,
            stop REAL NOT NULL,
            target1 REAL NOT NULL,
            target2 REAL NOT NULL,
            setup_score REAL,
            market_regime TEXT,
            evidence_confidence TEXT,
            catalyst TEXT,
            verification TEXT,
            status TEXT NOT NULL DEFAULT 'PENDING',
            activated_ms INTEGER,
            entry_price REAL,
            target1_hit_ms INTEGER,
            target1_price REAL,
            exit_ms INTEGER,
            exit_price REAL,
            outcome TEXT,
            exit_reason TEXT,
            r_multiple REAL,
            max_favorable_r REAL DEFAULT 0,
            max_adverse_r REAL DEFAULT 0,
            last_market_time_ms INTEGER,
            last_price_source TEXT,
            note TEXT,
            setup_hash TEXT NOT NULL
        )''')
        # Minimal migration for DBs produced by older Eagle Eye versions.
        existing = {row[1] for row in c.execute('PRAGMA table_info(paper_trades)').fetchall()}
        migrations = {
            'target1_hit_ms': 'ALTER TABLE paper_trades ADD COLUMN target1_hit_ms INTEGER',
            'target1_price': 'ALTER TABLE paper_trades ADD COLUMN target1_price REAL',
            'exit_reason': 'ALTER TABLE paper_trades ADD COLUMN exit_reason TEXT',
            'max_favorable_r': 'ALTER TABLE paper_trades ADD COLUMN max_favorable_r REAL DEFAULT 0',
            'max_adverse_r': 'ALTER TABLE paper_trades ADD COLUMN max_adverse_r REAL DEFAULT 0',
            'last_market_time_ms': 'ALTER TABLE paper_trades ADD COLUMN last_market_time_ms INTEGER',
            'last_price_source': 'ALTER TABLE paper_trades ADD COLUMN last_price_source TEXT',
            'setup_hash': 'ALTER TABLE paper_trades ADD COLUMN setup_hash TEXT',
        }
        for name, ddl in migrations.items():
            if name not in existing:
                c.execute(ddl)
        c.commit()
    _safe_chmod()


def _norm_symbol(value: object) -> str:
    return ''.join(ch for ch in str(value or '').upper().strip() if ch.isalnum() or ch in '.-&')[:32]


def _finite(name: str, value: object, minimum: Optional[float] = None, maximum: Optional[float] = None) -> float:
    try:
        out = float(value)
    except (TypeError, ValueError):
        raise ValueError(f'{name} must be numeric.')
    if not math.isfinite(out):
        raise ValueError(f'{name} must be finite.')
    if minimum is not None and out < minimum:
        raise ValueError(f'{name} is below the allowed minimum.')
    if maximum is not None and out > maximum:
        raise ValueError(f'{name} is above the allowed maximum.')
    return out


def _setup_hash(payload: dict) -> str:
    stable = {
        'symbol': payload['symbol'],
        'direction': payload['direction'],
        'entry_trigger': payload['entry_trigger'],
        'stop': payload['stop'],
        'target1': payload['target1'],
        'target2': payload['target2'],
        'setup_score': payload.get('setup_score'),
        'market_regime': payload.get('market_regime'),
        'evidence_confidence': payload.get('evidence_confidence'),
        'verification': payload.get('verification'),
    }
    raw = json.dumps(stable, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()


def _validate_trade(data: dict) -> dict:
    symbol = _norm_symbol(data.get('symbol'))
    if not symbol:
        raise ValueError('A valid symbol is required.')
    direction = str(data.get('direction') or '').upper().strip()
    if direction not in ALLOWED_DIRECTIONS:
        raise ValueError('Direction must be LONG or SHORT.')
    trigger = _finite('entry_trigger', data.get('entry_trigger'), 0.01)
    stop = _finite('stop', data.get('stop'), 0.01)
    target1 = _finite('target1', data.get('target1'), 0.01)
    target2 = _finite('target2', data.get('target2'), 0.01)
    if direction == 'LONG' and not (stop < trigger < target1 <= target2):
        raise ValueError('LONG geometry must satisfy stop < trigger < target1 <= target2.')
    if direction == 'SHORT' and not (stop > trigger > target1 >= target2):
        raise ValueError('SHORT geometry must satisfy stop > trigger > target1 >= target2.')
    setup_score = data.get('setup_score')
    if setup_score is not None:
        setup_score = _finite('setup_score', setup_score, 0, 100)
    evidence = data.get('evidence_confidence')
    if evidence is not None:
        evidence = str(evidence).upper().strip()
        if evidence not in ALLOWED_EVIDENCE:
            raise ValueError('Invalid evidence confidence.')
    verification = data.get('verification')
    if verification is not None:
        verification = str(verification).upper().strip()
        if verification not in ALLOWED_VERIFICATION:
            raise ValueError('Invalid verification status.')
    note = str(data.get('note') or '')[:500]
    return {
        'symbol': symbol,
        'direction': direction,
        'entry_trigger': trigger,
        'stop': stop,
        'target1': target1,
        'target2': target2,
        'setup_score': setup_score,
        'market_regime': str(data.get('market_regime') or '')[:64],
        'evidence_confidence': evidence,
        'catalyst': str(data.get('catalyst') or '')[:64],
        'verification': verification,
        'note': note,
    }


def log_trade(data: dict) -> dict:
    try:
        payload = _validate_trade(data)
    except ValueError as exc:
        return {'status': False, 'message': str(exc), 'errorcode': 'EE_PAPER_VALIDATION'}
    now = int(time.time() * 1000)
    payload['setup_hash'] = _setup_hash(payload)
    with _lock, _conn() as c:
        # Never allow a duplicate identical paper setup to be inserted within one minute.
        recent = c.execute('SELECT id FROM paper_trades WHERE setup_hash=? AND created_ms>=?', (payload['setup_hash'], now-60_000)).fetchone()
        if recent:
            return {'status': False, 'message': 'Duplicate paper setup suppressed.', 'errorcode': 'EE_PAPER_DUPLICATE', 'id': recent['id']}
        cur = c.execute('''INSERT INTO paper_trades
            (created_ms,updated_ms,symbol,direction,entry_trigger,stop,target1,target2,setup_score,market_regime,evidence_confidence,catalyst,verification,status,note,setup_hash)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
            (now, now, payload['symbol'], payload['direction'], payload['entry_trigger'], payload['stop'], payload['target1'], payload['target2'],
             payload['setup_score'], payload['market_regime'], payload['evidence_confidence'], payload['catalyst'], payload['verification'], 'PENDING', payload['note'], payload['setup_hash']))
        c.commit()
    _safe_chmod()
    return {'status': True, 'id': cur.lastrowid, 'created_ms': now, 'read_only_broker': True}


def _rows(c):
    return [dict(x) for x in c.fetchall()]


def list_trades(limit=100):
    with _lock, _conn() as c:
        cur = c.execute('SELECT * FROM paper_trades ORDER BY id DESC LIMIT ?', (max(1, min(int(limit), 500)),))
        return [dict(x) for x in cur.fetchall()]


def open_symbols() -> set[str]:
    with _lock, _conn() as c:
        return {row['symbol'] for row in c.execute("SELECT DISTINCT symbol FROM paper_trades WHERE status IN ('PENDING','ACTIVE')").fetchall()}


def _r_multiple(direction: str, entry: float, stop: float, price: float) -> float:
    risk = abs(entry - stop)
    if risk <= 0:
        return 0.0
    return ((price - entry) / risk) if direction == 'LONG' else ((entry - price) / risk)


def update_from_price(symbol: str, price: float, now_ms: int | None = None, source: str = 'ANGEL_ONE_LIVE', market_time_ms: int | None = None):
    symbol = _norm_symbol(symbol)
    p = _finite('price', price, 0.01)
    now = now_ms or int(time.time()*1000)
    event_time = int(market_time_ms or now)
    if event_time > now + 5_000:
        return {'changed_ids': [], 'closed_ids': [], 'rejected': 'MARKET_TIMESTAMP_IN_FUTURE'}
    if now - event_time > 60_000:
        return {'changed_ids': [], 'closed_ids': [], 'rejected': 'MARKET_TIMESTAMP_TOO_OLD'}
    changed = []
    closed = []
    with _lock, _conn() as c:
        rows = [dict(x) for x in c.execute("SELECT * FROM paper_trades WHERE symbol=? AND status IN ('PENDING','ACTIVE') ORDER BY id", (symbol,)).fetchall()]
        for x in rows:
            d=x['direction']; status=x['status']; entry=x['entry_price']; activated=x['activated_ms']; target1_hit=x.get('target1_hit_ms')
            last_market_time = int(x.get('last_market_time_ms') or 0)
            if event_time <= last_market_time:
                continue
            exit_price=None; outcome=None; r=None; exit_reason=None
            risk=abs(float(x['entry_trigger'])-float(x['stop']))
            if risk <= 0:
                continue
            # Update excursion only after activation.
            if status == 'PENDING':
                crossed = (d == 'LONG' and p >= float(x['entry_trigger'])) or (d == 'SHORT' and p <= float(x['entry_trigger']))
                if crossed:
                    # Never create a synthetic fill when one tick gaps through the final target.
                    # Such a setup cannot be evaluated as a normal trigger/target paper trade.
                    gap_through_target = (d == 'LONG' and p > float(x['target2'])) or (d == 'SHORT' and p < float(x['target2']))
                    if gap_through_target:
                        c.execute('''UPDATE paper_trades SET updated_ms=?,status=?,exit_ms=?,exit_price=?,outcome=?,exit_reason=?,last_market_time_ms=?,last_price_source=? WHERE id=?''',
                                  (now,'SKIPPED',now,p,'SKIPPED','ENTRY_GAP_THROUGH_TARGET',event_time,source,x['id']))
                        changed.append(x['id'])
                        continue
                    status='ACTIVE'; entry=p; activated=now
                else:
                    c.execute('UPDATE paper_trades SET updated_ms=?,last_market_time_ms=?,last_price_source=? WHERE id=?', (now,event_time,source,x['id']))
                    changed.append(x['id'])
                    continue
            if status == 'ACTIVE':
                rr_now=_r_multiple(d, float(entry), float(x['stop']), p)
                mfe=max(float(x.get('max_favorable_r') or 0), rr_now)
                mae=min(float(x.get('max_adverse_r') or 0), rr_now)
                if target1_hit is None:
                    hit_t1=(d == 'LONG' and p >= float(x['target1'])) or (d == 'SHORT' and p <= float(x['target1']))
                    if hit_t1:
                        target1_hit=now
                        x['target1_price']=p
                hit_stop=(d == 'LONG' and p <= float(x['stop'])) or (d == 'SHORT' and p >= float(x['stop']))
                hit_t2=(d == 'LONG' and p >= float(x['target2'])) or (d == 'SHORT' and p <= float(x['target2']))
                if hit_stop or hit_t2:
                    # A single tick does not reveal the path between its previous
                    # price and the new price. If both stop and target2 are crossed
                    # by that same tick, the outcome is path-ambiguous and must not
                    # be arbitrarily classified as a win or loss.
                    if hit_stop and hit_t2:
                        status='SKIPPED'; exit_price=p; outcome='SKIPPED'; exit_reason='AMBIGUOUS_TICK_PATH'
                        r=None
                    else:
                        status='CLOSED'; exit_price=p; outcome='LOSS' if hit_stop else 'WIN'; exit_reason='STOP' if hit_stop else 'TARGET2'
                        r=_r_multiple(d, float(entry), float(x['stop']), p)
                        closed.append(x['id'])
                c.execute('''UPDATE paper_trades SET updated_ms=?,status=?,activated_ms=?,entry_price=?,target1_hit_ms=?,target1_price=?,exit_ms=?,exit_price=?,outcome=?,exit_reason=?,r_multiple=?,max_favorable_r=?,max_adverse_r=?,last_market_time_ms=?,last_price_source=? WHERE id=?''',
                          (now,status,activated,entry,target1_hit,x.get('target1_price'),now if exit_price is not None else x['exit_ms'],exit_price,outcome,exit_reason,r,mfe,mae,event_time,source,x['id']))
                changed.append(x['id'])
            elif status == 'PENDING' and status != x['status']:
                c.execute('UPDATE paper_trades SET updated_ms=?,status=?,activated_ms=?,entry_price=?,last_market_time_ms=?,last_price_source=? WHERE id=?', (now,status,activated,entry,event_time,source,x['id']))
                changed.append(x['id'])
        c.commit()
    _safe_chmod()
    return {'changed_ids': changed, 'closed_ids': closed}


def metrics():
    with _lock, _conn() as c:
        rows=[dict(x) for x in c.execute('SELECT * FROM paper_trades WHERE status="CLOSED" AND r_multiple IS NOT NULL ORDER BY id').fetchall()]
    if not rows:
        return {'trades':0,'wins':0,'losses':0,'win_rate':None,'avg_r':None,'profit_factor':None,'max_drawdown_r':None,'expectancy_r':None}
    rs=[float(x['r_multiple']) for x in rows]
    wins=[r for r in rs if r>0]; losses=[r for r in rs if r<0]
    equity=peak=dd=0.0
    for r in rs:
        equity += r; peak=max(peak,equity); dd=max(dd,peak-equity)
    return {
        'trades':len(rs), 'wins':len(wins), 'losses':len(losses),
        'win_rate': round(len(wins)/len(rs)*100,2),
        'avg_r': round(sum(rs)/len(rs),3),
        'profit_factor': round(sum(wins)/abs(sum(losses)),3) if losses else None,
        'max_drawdown_r': round(dd,3),
        'expectancy_r': round(sum(rs)/len(rs),3),
    }


def analytics(group_by: str = 'market_regime'):
    init_db()
    allowed={'market_regime','evidence_confidence','verification','outcome','symbol'}
    key=group_by if group_by in allowed else 'market_regime'
    with _lock, _conn() as c:
        rows=[dict(x) for x in c.execute('SELECT * FROM paper_trades WHERE status="CLOSED" AND r_multiple IS NOT NULL ORDER BY id').fetchall()]
    buckets={}
    for r in rows:
        k=str(r.get(key) or 'UNSPECIFIED')
        buckets.setdefault(k,[]).append(float(r['r_multiple']))
    out=[]
    for k, vals in sorted(buckets.items()):
        wins=[x for x in vals if x>0]; losses=[x for x in vals if x<0]
        equity=peak=dd=0.0
        for x in vals:
            equity += x; peak=max(peak,equity); dd=min(dd,equity-peak)
        out.append({'group':k,'trades':len(vals),'wins':len(wins),'losses':len(losses),'win_rate_pct':round(len(wins)/len(vals)*100,2) if vals else None,'avg_r':round(sum(vals)/len(vals),4) if vals else None,'profit_factor':round(sum(wins)/abs(sum(losses)),4) if losses else None,'max_drawdown_r':round(dd,4)})
    return {'group_by':key,'rows':out}
