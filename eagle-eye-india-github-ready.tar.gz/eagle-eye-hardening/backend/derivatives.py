from __future__ import annotations
from datetime import datetime, date
from typing import Iterable

NFO = 'NFO'


def _parse_expiry(value):
    if not value:
        return None
    s = str(value).strip().upper()
    for fmt in ('%d%b%Y', '%d-%b-%Y', '%Y-%m-%d'):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    return None


def _strike(x: dict):
    raw = x.get('strike') if x.get('strike') not in (None, '') else x.get('strikeprice')
    try:
        v = float(raw)
    except (TypeError, ValueError):
        return None
    # Angel One instrument-master strike is commonly stored scaled by 100.
    return v / 100.0 if abs(v) > 100000 else v


def _underlying_candidates(instruments: dict[str, dict], symbol: str, today: date):
    s = symbol.upper().replace('-EQ', '')
    out = []
    for inst in instruments.values():
        if (inst.get('exch_seg') or '').upper() != NFO:
            continue
        name = (inst.get('name') or '').upper()
        sym = (inst.get('symbol') or '').upper()
        if name != s and not sym.startswith(s):
            continue
        exp = _parse_expiry(inst.get('expiry'))
        if exp and exp >= today:
            out.append((exp, inst))
    return out


def select_contracts(instruments: dict[str, dict], symbol: str, spot: float, today: date | None = None, option_band: int = 3) -> dict:
    today = today or date.today()
    rows = _underlying_candidates(instruments, symbol, today)
    if not rows:
        return {'available': False, 'reason': 'NO_NFO_CONTRACTS_FOUND', 'futures': [], 'options': []}
    nearest = min(x[0] for x in rows)
    same = [x for x in rows if x[0] == nearest]
    futures = [i for _, i in same if str(i.get('instrumenttype') or '').upper() in ('FUTSTK', 'FUTIDX')]
    options = [i for _, i in same if str(i.get('instrumenttype') or '').upper() in ('OPTSTK', 'OPTIDX')]
    strikes = sorted(((_strike(i), i) for i in options if _strike(i) is not None), key=lambda z: z[0])
    chosen = []
    if strikes and spot:
        idx = min(range(len(strikes)), key=lambda i: abs(strikes[i][0] - spot))
        lo, hi = max(0, idx - option_band), min(len(strikes), idx + option_band + 1)
        chosen = [i for _, i in strikes[lo:hi]]
    return {
        'available': bool(futures or chosen),
        'expiry': nearest.isoformat(),
        'futures': futures[:3],
        'options': chosen[:14],
        'underlying': symbol.upper(),
    }


def parse_quotes(resp: dict) -> list[dict]:
    if not isinstance(resp, dict):
        return []
    data = resp.get('data') or {}
    fetched = data.get('fetched') if isinstance(data, dict) else None
    return fetched if isinstance(fetched, list) else []


def derivative_snapshot(selected: dict, quotes: list[dict], prior_oi: dict[str, float] | None = None, prior_futures_price: dict[str, float] | None = None) -> dict:
    prior_oi = prior_oi or {}
    prior_futures_price = prior_futures_price or {}
    fut = []
    calls = []
    puts = []
    for q in quotes:
        opt = str(q.get('optiontype') or '').upper()
        row = {
            'symboltoken': str(q.get('symbolToken') or q.get('symboltoken') or ''),
            'trading_symbol': q.get('tradingSymbol') or q.get('tradingsymbol') or '',
            'ltp': q.get('ltp'),
            'oi': q.get('opnInterest') if q.get('opnInterest') is not None else q.get('openInterest'),
            'change_oi': None,
            'strike': q.get('strikePrice') if q.get('strikePrice') is not None else q.get('strikeprice'),
            'option_type': opt,
            'expiry': q.get('expirydate') or q.get('expiryDate'),
            'volume': q.get('tradeVolume') if q.get('tradeVolume') is not None else q.get('volume'),
            'iv': q.get('impliedVolatility') if q.get('impliedVolatility') is not None else q.get('iv'),
        }
        token = row['symboltoken']
        if token in prior_futures_price and row.get('ltp') is not None:
            row['previous_ltp'] = prior_futures_price[token]
        try:
            oi = float(row['oi']) if row['oi'] is not None else None
            if oi is not None and token in prior_oi:
                row['change_oi'] = oi - float(prior_oi[token])
        except Exception:
            pass
        it = q.get('instrumenttype') or ''
        if opt in ('CE', 'PE'):
            (calls if opt == 'CE' else puts).append(row)
        elif 'FUT' in str(it).upper() or str(row['trading_symbol']).upper().endswith('FUT'):
            fut.append(row)
    call_oi = sum(float(x['oi']) for x in calls if x.get('oi') is not None)
    put_oi = sum(float(x['oi']) for x in puts if x.get('oi') is not None)
    pcr = put_oi / call_oi if call_oi else None
    max_call = max(calls, key=lambda x: float(x.get('oi') or 0), default=None)
    max_put = max(puts, key=lambda x: float(x.get('oi') or 0), default=None)
    fut_basis = None
    if fut and fut[0].get('ltp') is not None and selected.get('spot'):
        fut_basis = float(fut[0]['ltp']) - float(selected['spot'])
    derivative_bias = 'NEUTRAL'
    evidence = []
    futures_build = 'UNAVAILABLE'
    if fut:
        q=fut[0]
        tok=q.get('symboltoken'); oi_now=q.get('oi'); oi_prev=prior_oi.get(tok) if tok else None
        try:
            px=float(q.get('ltp')); prev_px=float(q.get('previous_ltp')) if q.get('previous_ltp') is not None else None
        except Exception:
            px=prev_px=None
        if oi_now is not None and oi_prev is not None and prev_px is not None:
            oi_delta=float(oi_now)-float(oi_prev); px_delta=px-prev_px if px is not None else 0
            if px_delta>0 and oi_delta>0: futures_build='LONG_BUILDUP'
            elif px_delta<0 and oi_delta>0: futures_build='SHORT_BUILDUP'
            elif px_delta>0 and oi_delta<0: futures_build='SHORT_COVERING'
            elif px_delta<0 and oi_delta<0: futures_build='LONG_UNWINDING'
    if pcr is not None:
        if pcr >= 1.25:
            derivative_bias = 'BULLISH'; evidence.append(f'Put/call OI ratio {pcr:.2f} is relatively put-heavy')
        elif pcr <= 0.75:
            derivative_bias = 'BEARISH'; evidence.append(f'Put/call OI ratio {pcr:.2f} is relatively call-heavy')
        else:
            evidence.append(f'Put/call OI ratio {pcr:.2f} is near balance')
    if fut_basis is not None:
        evidence.append(f'Nearest futures basis {fut_basis:+.2f}')
    oi_up = sum(1 for x in calls + puts if x.get('change_oi') is not None and x['change_oi'] > 0)
    oi_down = sum(1 for x in calls + puts if x.get('change_oi') is not None and x['change_oi'] < 0)
    option_volumes=[float(x['volume']) for x in calls+puts if x.get('volume') is not None]
    ivs=[float(x['iv']) for x in calls+puts if x.get('iv') is not None]
    oi_additions=[x for x in calls+puts if x.get('change_oi') is not None and x.get('change_oi')>0]
    return {
        'available': bool(calls or puts or fut),
        'expiry': selected.get('expiry'),
        'futures': fut,
        'calls': calls,
        'puts': puts,
        'pcr': round(pcr, 3) if pcr is not None else None,
        'futures_basis': round(fut_basis, 3) if fut_basis is not None else None,
        'oi_increases': oi_up,
        'oi_decreases': oi_down,
        'oi_additions': oi_additions[:20],
        'option_volume': round(sum(option_volumes), 2) if option_volumes else None,
        'iv': round(sum(ivs)/len(ivs), 3) if ivs else None,
        'long_buildup': futures_build == 'LONG_BUILDUP',
        'short_buildup': futures_build == 'SHORT_BUILDUP',
        'short_covering': futures_build == 'SHORT_COVERING',
        'long_unwinding': futures_build == 'LONG_UNWINDING',
        'futures_build': futures_build,
        'major_call_resistance': {'strike': max_call.get('strike'), 'oi': max_call.get('oi')} if max_call else None,
        'major_put_support': {'strike': max_put.get('strike'), 'oi': max_put.get('oi')} if max_put else None,
        'bias': derivative_bias,
        'evidence': evidence[:5],
    }
