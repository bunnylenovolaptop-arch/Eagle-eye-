from __future__ import annotations
import json
import os
from dataclasses import dataclass
from typing import Optional

SECTOR_INDEX_KEYS = {
    'IT': 'IT',
    'AUTO': 'AUTO',
    'METAL': 'METAL',
    'PHARMA': 'PHARMA',
    'ENERGY': 'ENERGY',
    'FMCG': 'FMCG',
    'REALTY': 'REALTY',
    'PSUBANK': 'PSUBANK',
}

# Conservative built-in map for common liquid names. Operators can extend this
# server-side through EAGLE_SECTOR_MAP_JSON. Unknown symbols remain UNAVAILABLE.
BUILTIN = {
    'RELIANCE': 'ENERGY', 'ONGC': 'ENERGY', 'NTPC': 'ENERGY', 'COALINDIA': 'ENERGY',
    'TATAPOWER': 'ENERGY', 'POWERGRID': 'ENERGY', 'BPCL': 'ENERGY', 'IOC': 'ENERGY',
    'INFY': 'IT', 'TCS': 'IT', 'HCLTECH': 'IT', 'WIPRO': 'IT', 'TECHM': 'IT',
    'LTIM': 'IT', 'MPHASIS': 'IT', 'COFORGE': 'IT',
    'MARUTI': 'AUTO', 'M&M': 'AUTO', 'TATAMOTORS': 'AUTO', 'EICHERMOT': 'AUTO',
    'HEROMOTOCO': 'AUTO', 'BAJAJ-AUTO': 'AUTO', 'TVSMOTOR': 'AUTO',
    'TATASTEEL': 'METAL', 'JSWSTEEL': 'METAL', 'HINDALCO': 'METAL', 'VEDL': 'METAL',
    'JINDALSTEL': 'METAL', 'SAIL': 'METAL', 'NMDC': 'METAL',
    'SUNPHARMA': 'PHARMA', 'DRREDDY': 'PHARMA', 'CIPLA': 'PHARMA', 'DIVISLAB': 'PHARMA',
    'AUROPHARMA': 'PHARMA', 'LUPIN': 'PHARMA',
    'ITC': 'FMCG', 'HINDUNILVR': 'FMCG', 'NESTLEIND': 'FMCG', 'BRITANNIA': 'FMCG',
    'TATACONSUM': 'FMCG', 'DABUR': 'FMCG', 'COLPAL': 'FMCG',
    'DLF': 'REALTY', 'GODREJPROP': 'REALTY', 'LODHA': 'REALTY', 'OBEROIRLTY': 'REALTY',
    'SBIN': 'PSUBANK', 'BANKBARODA': 'PSUBANK', 'CANBK': 'PSUBANK', 'PNB': 'PSUBANK',
    'BANKINDIA': 'PSUBANK', 'UNIONBANK': 'PSUBANK',
}


def _load_extra() -> dict[str, str]:
    raw = os.getenv('EAGLE_SECTOR_MAP_JSON', '').strip()
    if not raw:
        return {}
    try:
        obj = json.loads(raw)
        if not isinstance(obj, dict):
            return {}
        out = {}
        for k, v in obj.items():
            if isinstance(k, str) and isinstance(v, str):
                out[k.upper()] = v.upper()
        return out
    except Exception:
        return {}


def normalise_symbol(symbol: str) -> str:
    s = (symbol or '').upper().strip()
    for suffix in ('-EQ', '-BE', '-SM', '-ST'):
        if s.endswith(suffix):
            s = s[:-len(suffix)]
    return s


def sector_for_symbol(symbol: str, name: str = '') -> Optional[str]:
    s = normalise_symbol(symbol)
    return _load_extra().get(s) or BUILTIN.get(s)


def sector_snapshot(symbol: str, name: str, regime: dict) -> dict:
    sector = sector_for_symbol(symbol, name)
    if not sector:
        return {'available': False, 'sector': None, 'reason': 'SECTOR_MAPPING_UNAVAILABLE'}
    key = SECTOR_INDEX_KEYS.get(sector)
    rows = regime.get('sector_rotation') or []
    row = next((x for x in rows if x.get('key') == key), None)
    if not row:
        return {'available': False, 'sector': sector, 'reason': 'SECTOR_INDEX_DATA_UNAVAILABLE'}
    nifty = ((regime.get('indices') or {}).get('NIFTY 50') or {}).get('change_pct')
    change = row.get('change_pct')
    relative = (float(change) - float(nifty)) if nifty is not None and change is not None else None
    return {
        'available': True,
        'sector': sector,
        'index_key': key,
        'index_label': next((x.get('label') for x in rows if x.get('key') == key), sector),
        'change_pct': change,
        'relative_vs_nifty': round(relative, 3) if relative is not None else None,
        'aligned': relative is not None and relative >= 0 if change is not None else None,
    }
