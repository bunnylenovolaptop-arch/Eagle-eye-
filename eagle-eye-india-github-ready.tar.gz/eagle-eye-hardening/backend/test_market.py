from backend.market import market_regime, technical_quality, liquidity_gate, INDEX_CATALOG


def tick(token, ltp, close, volume=2000000, recv=1000000):
    return {
        'token': token,
        'ltp': ltp,
        'close': close,
        'volume_trade_for_day': volume,
        'received_timestamp_ms': recv,
        'exchange_timestamp_ms': recv,
    }


def test_market_regime_uses_index_tokens_and_breadth():
    ticks = {
        f"1:{INDEX_CATALOG['NIFTY']['token']}": tick(INDEX_CATALOG['NIFTY']['token'], 101, 100),
        f"1:{INDEX_CATALOG['BANKNIFTY']['token']}": tick(INDEX_CATALOG['BANKNIFTY']['token'], 102, 100),
        f"1:{INDEX_CATALOG['MIDCAP100']['token']}": tick(INDEX_CATALOG['MIDCAP100']['token'], 101, 100),
        f"1:{INDEX_CATALOG['SMALLCAP100']['token']}": tick(INDEX_CATALOG['SMALLCAP100']['token'], 101, 100),
        '1:111': tick('111', 105, 100),
        '1:112': tick('112', 104, 100),
        '1:113': tick('113', 99, 100),
    }
    out = market_regime(ticks, 1000000, 3000)
    assert out['regime'] in {'STRONG BULLISH', 'MILD BULLISH'}
    assert out['breadth']['advancers'] == 2
    assert out['breadth']['decliners'] == 1


def test_liquidity_gate():
    good = tick('1', 100, 99, volume=1000000)
    bad = tick('2', 100, 99, volume=100)
    assert liquidity_gate(good, 50_000_000)[0]
    assert not liquidity_gate(bad, 50_000_000)[0]


def test_technical_quality_needs_valid_analysis():
    out = technical_quality({'valid': False, 'reason': 'INSUFFICIENT_CANDLES'}, tick('1', 100, 99), 1.0)
    assert out['valid'] is False
    assert out['score'] == 0
