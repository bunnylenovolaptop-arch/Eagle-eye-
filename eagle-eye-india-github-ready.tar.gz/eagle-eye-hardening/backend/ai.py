from __future__ import annotations

import json
from typing import Any

import httpx


SYSTEM_PROMPT = """You are Eagle Eye India's evidence-first Indian equity research desk. You are not a fortune teller. Analyze only supplied evidence. Do not invent facts, prices, sources, dates, financial impacts, or verification. Separate observed facts from inference. Treat social/secondary information as unverified unless corroborated. Never claim a probability of profit. Your job is to produce concise, falsifiable analysis and explicitly identify what could make the thesis wrong."""

SKEPTIC_PROMPT = """You are the independent adversarial skeptic for Eagle Eye India. Your only job is to DISPROVE the candidate thesis using the supplied data. Search for contradictions, stale information, poor liquidity, failed breakouts, weak volume, market/sector conflict, already-priced news, and unsupported assumptions. Do not agree merely because the thesis sounds plausible. If the evidence is insufficient, say so."""

SCHEMA = {
    'type': 'object',
    'properties': {
        'thesis': {'type': 'string'},
        'strongest_evidence': {'type': 'array', 'items': {'type': 'string'}},
        'what_could_make_this_wrong': {'type': 'array', 'items': {'type': 'string'}},
        'news_already_priced': {'type': 'string'},
        'market_compatibility': {'type': 'string'},
        'data_limitations': {'type': 'array', 'items': {'type': 'string'}},
        'status': {'type': 'string'},
    },
    'required': ['thesis','strongest_evidence','what_could_make_this_wrong','news_already_priced','market_compatibility','data_limitations','status'],
    'additionalProperties': False,
}


def _extract_output(data: dict) -> str:
    if data.get('output_text'):
        return data['output_text']
    # Generic fallback for Responses API item shape.
    for item in data.get('output') or []:
        for c in item.get('content') or []:
            if c.get('type') == 'output_text' and c.get('text'):
                return c['text']
    return ''


async def run_openai(payload: dict, skeptic: bool = False) -> dict:
    api_key = payload.get('OPENAI_API_KEY', '')
    if not api_key:
        return {'status': False, 'message': 'AI provider is not configured.', 'errorcode': 'EE_NO_AI'}
    model = payload.get('OPENAI_MODEL', 'gpt-5.6-luna')
    evidence = payload.get('evidence') or {}
    system = SKEPTIC_PROMPT if skeptic else SYSTEM_PROMPT
    user = json.dumps(payload.get('context') or {}, ensure_ascii=False)
    body = {
        'model': model,
        'store': False,
        'input': [{'role': 'system', 'content': system}, {'role': 'user', 'content': user}],
        'text': {'format': {'type': 'json_schema', 'name': 'eagle_eye_analysis', 'strict': True, 'schema': SCHEMA}},
    }
    if payload.get('OPENAI_WEB_SEARCH', True):
        body['tools'] = [{'type': 'web_search'}]
    headers = {'Authorization': f'Bearer {api_key}', 'Content-Type': 'application/json'}
    async with httpx.AsyncClient(timeout=45) as client:
        r = await client.post('https://api.openai.com/v1/responses', headers=headers, json=body)
        if r.status_code >= 400:
            return {'status': False, 'message': f'AI provider HTTP {r.status_code}: {r.text[:400]}', 'errorcode': 'EE_AI_HTTP'}
        data = r.json()
    raw = _extract_output(data)
    try:
        parsed = json.loads(raw)
    except Exception:
        return {'status': False, 'message': 'AI output was not valid structured JSON.', 'errorcode': 'EE_AI_SCHEMA', 'raw': raw[:1000]}
    return {'status': True, 'model': model, 'analysis': parsed, 'response_id': data.get('id')}
