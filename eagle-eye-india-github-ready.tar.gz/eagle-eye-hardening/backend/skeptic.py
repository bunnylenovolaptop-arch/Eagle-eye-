from __future__ import annotations


def run_skeptic(technical: dict, evidence: dict, tick: dict, regime: dict, levels: dict, sector: dict, derivatives: dict, liquidity: dict) -> dict:
    risks = []
    invalidating = []
    major_conflict = False
    direction = technical.get('direction')
    price = float(tick.get('ltp') or technical.get('last_price') or 0)
    relvol = float(technical.get('relative_volume20') or 0)
    rsi = technical.get('rsi14')
    rs = technical.get('relative_strength_vs_nifty')
    regime_name = regime.get('regime', 'UNAVAILABLE')

    if evidence.get('contradictions'):
        risks.append('Adverse news/corporate clusters detected.')
    freshness = (evidence.get('freshness') or {}).get('status')
    if freshness in ('STALE', 'NO_NEWS'):
        risks.append('Evidence freshness is weak or news unavailable.')
    if direction == 'LONG' and regime_name in ('STRONG BEARISH', 'MILD BEARISH'):
        risks.append('Long thesis conflicts with market regime.')
        major_conflict = True
    if direction == 'SHORT' and regime_name in ('STRONG BULLISH', 'MILD BULLISH'):
        risks.append('Short thesis conflicts with market regime.')
        major_conflict = True
    if relvol < 1.5:
        risks.append('Volume confirmation is not strong enough.')
    if abs(rs or 0) < 0.4:
        risks.append('Relative strength versus NIFTY is weak/unclear.')
    if rsi is not None and ((direction == 'LONG' and rsi > 78) or (direction == 'SHORT' and rsi < 22)):
        risks.append('Momentum is at an extreme and could mean reversion risk.')
    if not sector.get('available'):
        risks.append('Sector context is unavailable.')
    if liquidity.get('level') in ('LOW', 'REJECT'):
        risks.append('Liquidity/spread quality is weak.')
    if derivatives.get('applicable') and not derivatives.get('available'):
        risks.append('F&O evidence is unavailable for an F&O-enabled stock.')
    if levels.get('valid') and price:
        stop = levels.get('stop')
        if direction == 'LONG' and stop and stop >= price:
            risks.append('Long stop level is not below the current price.')
            invalidating.append('Invalid risk geometry.')
        if direction == 'SHORT' and stop and stop <= price:
            risks.append('Short stop level is not above the current price.')
            invalidating.append('Invalid risk geometry.')
    status = 'INVALIDATED' if invalidating else ('WEAKENED' if major_conflict or len(risks) >= 3 else 'PASS')
    return {
        'status': status,
        'risk_count': len(risks),
        'risks': risks[:8],
        'invalidating_factors': invalidating[:5],
        'thesis_survives': status == 'PASS',
    }
