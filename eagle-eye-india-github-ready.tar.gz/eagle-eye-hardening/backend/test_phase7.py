from datetime import datetime
from zoneinfo import ZoneInfo
try:
    from .features import timeframe_set, cap_tier, tier_policy, macro_payload
    from .technical import analyze
    from .backtest import replay
    from .session import session_phase
except ImportError:
    from features import timeframe_set, cap_tier, tier_policy, macro_payload
    from technical import analyze
    from backtest import replay
    from session import session_phase

IST=ZoneInfo('Asia/Kolkata')

def candles(n=240):
    out=[]; price=100.0
    for i in range(n):
        price += 0.08
        out.append([i*60_000,price-0.05,price+0.15,price-0.18,price,1000+i*5])
    return out

def test_timeframe_expansion():
    one=candles(240); daily=candles(30)
    tf=timeframe_set(one,daily)
    assert len(tf['3m']) < len(tf['1m'])
    assert len(tf['30m']) < len(tf['5m'])
    assert len(tf['1w']) > 0

def test_cap_tier_never_uses_price():
    assert cap_tier('ABC', price=1.0) == 'UNKNOWN'
    assert tier_policy('PENNY')['min_evidence']=='HIGH'

def test_technical_parameter_expansion():
    a=analyze(candles())
    i=a['indicators']
    for k in ['ema9','ema20','ema50','ema200','sma20','sma50','sma200','rsi14','macd','atr14','bollinger20','adx14','vwap','relative_volume20','obv','candle_patterns','structure','opening_range_15m','gap_pct','day_range','distance_from_vwap_pct','volume_acceleration','breakout','breakdown']:
        assert k in i

def test_session_timing_uses_15_20_auction_boundary():
    x=session_phase(datetime(2026,10,1,15,25,tzinfo=IST))
    assert x['is_closing_auction'] is True
    assert x['is_cash_market_open'] is True
    assert x['is_cash_continuous'] is False
    assert x['cash_normal_close']=='15:30 IST'

def test_backtest_returns_fail_safe_metrics():
    r=replay('TEST',candles(240))
    assert r['status'] is True
    assert 'skipped_ambiguous' in r and r['skipped_ambiguous'] >= 0
