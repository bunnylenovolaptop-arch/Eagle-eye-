from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .news import classify_catalyst, verify_cluster

@dataclass
class EvidenceResult:
    catalyst: dict
    verification: dict
    materiality: dict
    contradictions: list[dict]
    freshness: dict
    status: str
    reasons: list[str]


def build_evidence(news_payload: dict, now_ms: int, technical: dict | None = None, regime: dict | None = None) -> EvidenceResult:
    clusters = news_payload.get('clusters') or []
    if not clusters:
        return EvidenceResult(
            catalyst={'type': 'Other', 'strength': 0, 'items': 0},
            verification={'verification': 'UNVERIFIED', 'evidence_confidence': 'LOW', 'three_source_status': '3-SOURCE VERIFICATION UNAVAILABLE'},
            materiality={'revenue_impact': 'UNQUANTIFIED', 'ebitda_impact': 'UNQUANTIFIED', 'pat_impact': 'UNQUANTIFIED', 'cash_flow_impact': 'UNQUANTIFIED', 'balance_sheet_impact': 'UNQUANTIFIED', 'valuation_impact': 'UNQUANTIFIED'},
            contradictions=[],
            freshness={'status': 'NO_NEWS', 'latest_news_age_ms': None},
            status='WATCHLIST',
            reasons=['NEWS VERIFICATION UNAVAILABLE'],
        )
    top = clusters[0]
    verification = verify_cluster(top)
    age = now_ms - int(top.get('latest_published_at_ms') or 0) if top.get('latest_published_at_ms') else None
    freshness_status = 'FRESH' if age is not None and age <= 2 * 60 * 60 * 1000 else ('RECENT' if age is not None and age <= 24 * 60 * 60 * 1000 else 'STALE')
    catalyst_strength = 0
    if top.get('article_count', 0) >= 1: catalyst_strength += 8
    if top.get('independent_domains', 0) >= 2: catalyst_strength += 6
    if top.get('primary_domains'): catalyst_strength += 6
    if top.get('materiality', {}).get('financial_quantification_present'): catalyst_strength += 2
    catalyst_strength = min(catalyst_strength, 20)
    reasons = []
    reasons.append(f"Catalyst: {top.get('catalyst') or classify_catalyst(' '.join(i.get('title','') for i in top.get('items',[])))}")
    reasons.append(f"Verification: {verification.get('verification')}")
    if verification.get('three_source_status') != 'AVAILABLE':
        reasons.append('3-SOURCE VERIFICATION UNAVAILABLE')
    if freshness_status == 'STALE': reasons.append('NEWS STALE')
    materiality = {
        'revenue_impact': 'UNQUANTIFIED',
        'ebitda_impact': 'UNQUANTIFIED',
        'pat_impact': 'UNQUANTIFIED',
        'cash_flow_impact': 'UNQUANTIFIED',
        'balance_sheet_impact': 'POSSIBLE' if top.get('materiality', {}).get('balance_sheet_signal') else 'UNQUANTIFIED',
        'valuation_impact': 'POSSIBLE' if top.get('materiality', {}).get('guidance_or_outlook') else 'UNQUANTIFIED',
    }
    contradictions = []
    for c in clusters[1:6]:
        cat = (c.get('catalyst') or '').lower()
        if any(w in cat for w in ('cancellation', 'regulatory action', 'legal development', 'corporate governance')):
            contradictions.append({'cluster_id': c.get('cluster_id'), 'catalyst': c.get('catalyst'), 'article_count': c.get('article_count'), 'reason': 'Potentially adverse cluster detected'})
    status = 'WAIT FOR TRIGGER' if verification.get('evidence_confidence') in ('HIGH', 'MEDIUM') and freshness_status in ('FRESH', 'RECENT') else 'WATCHLIST'
    return EvidenceResult(
        catalyst={'type': top.get('catalyst', 'Other'), 'strength': catalyst_strength, 'items': top.get('article_count', 0)},
        verification=verification,
        materiality=materiality,
        contradictions=contradictions,
        freshness={'status': freshness_status, 'latest_news_age_ms': age},
        status=status,
        reasons=reasons[:5],
    )
