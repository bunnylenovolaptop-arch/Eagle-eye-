from __future__ import annotations

import asyncio
import json
import math
import os
import struct
import time
from datetime import datetime, time as dtime
from typing import Dict, List, Optional, Callable, AsyncIterator
from zoneinfo import ZoneInfo

import httpx
try:
    import pyotp
except ModuleNotFoundError:  # optional until automatic login is used
    pyotp = None
import websockets
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
from pydantic_settings import BaseSettings, SettingsConfigDict

from .market import INDEX_CATALOG, INDEX_TOKENS, market_regime, liquidity_gate, pct_change, technical_quality
from .technical import analyze as technical_analyze
from .news import search_news
from .evidence import build_evidence
from .decision import build_levels, score_setup
from .ai import run_openai
from .sector import sector_snapshot, normalise_symbol, sector_for_symbol
from .derivatives import select_contracts, parse_quotes, derivative_snapshot
from .liquidity import assess_liquidity, manipulation_flags
from .skeptic import run_skeptic
from .paper import init_db, log_trade, list_trades, metrics as paper_metrics, analytics as paper_analytics, update_from_price, open_symbols
from .session import session_phase
from .features import macro_payload, fundamental_payload, delivery_payload, cap_tier, tier_policy, peer_relative_strength, timeframe_set
from .backtest import replay
from .notifications import NotificationRegistry
from .registry import coverage as feature_coverage
from .universe import passes_universe, universe_membership
from .context import fetch_context
from .security import SessionStore, SlidingWindowLimiter, constant_time_equals
from .ratelimit import AsyncTokenBucket

IST = ZoneInfo('Asia/Kolkata')
ANGEL_ROOT = 'https://apiconnect.angelone.in'
ANGEL_WS = 'wss://smartapisocket.angelone.in/smart-stream'
ANGEL_QUOTE = f'{ANGEL_ROOT}/rest/secure/angelbroking/market/v1/quote/'
ANGEL_CANDLE = f'{ANGEL_ROOT}/rest/secure/angelbroking/historical/v1/getCandleData'
ANGEL_LOGIN = f'{ANGEL_ROOT}/rest/auth/angelbroking/user/v1/loginByPassword'
ANGEL_REFRESH = f'{ANGEL_ROOT}/rest/auth/angelbroking/jwt/v1/generateTokens'
ANGEL_INSTRUMENTS = 'https://margincalculator.angelone.in/OpenAPI_File/files/OpenAPIScripMaster.json'


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', extra='ignore')
    ANGEL_API_KEY: str = ''
    ANGEL_CLIENT_CODE: str = ''
    ANGEL_JWT_TOKEN: str = ''
    ANGEL_FEED_TOKEN: str = ''
    ANGEL_REFRESH_TOKEN: str = ''
    ANGEL_PASSWORD: str = ''
    ANGEL_TOTP_SECRET: str = ''
    ANGEL_AUTO_LOGIN: bool = True
    EAGLE_TOKENS: str = ''
    EAGLE_MAX_STREAM_SESSIONS: int = 3
    EAGLE_AUTO_SUBSCRIBE_UNIVERSE: bool = False
    EAGLE_AUTO_SUBSCRIBE_LIMIT: int = 1800
    STALE_AFTER_MS: int = 3000
    MIN_TRADED_VALUE_INR: float = 50_000_000
    SCAN_TOP_CANDIDATES: int = 10
    INSTRUMENT_CACHE_MAX_AGE_SEC: int = 3600
    NEWS_CACHE_TTL_SEC: int = 120
    NEWS_RSS_URLS: str = ''
    OPENAI_API_KEY: str = ''
    OPENAI_MODEL: str = 'gpt-5.6-luna'
    OPENAI_WEB_SEARCH: bool = True
    EAGLE_REQUIRE_AUTH: bool = True
    EAGLE_ACCESS_TOKEN: str = ''
    EAGLE_SESSION_TTL_SEC: int = 21600
    EAGLE_COOKIE_SECURE: bool = True
    EAGLE_COOKIE_NAME: str = 'eagle_eye_session'
    EAGLE_ALLOWED_ORIGINS: str = ''
    EAGLE_ALLOW_NON_BROWSER_API: bool = False
    EAGLE_MAX_CLIENTS: int = 8
    EAGLE_MAX_BODY_BYTES: int = 262144
    EAGLE_MANUAL_REVALUE: bool = False
    EAGLE_ENABLE_BROKER_ORDERS: bool = False
    EAGLE_PRODUCTION_READY: bool = False
    EAGLE_EXPOSE_API_DOCS: bool = False
    EAGLE_REST_QUOTE_RPS: float = 9.0
    EAGLE_CANDLE_RPS: float = 2.5
    EAGLE_PAPER_UPDATE_RPS: float = 50.0
    EAGLE_REST_TIMEOUT_SEC: float = 10.0
    EAGLE_CLOCK_SKEW_MAX_MS: int = 5000
    EAGLE_TICK_MAX_AGE_MS: int = 60000
    EAGLE_ALLOW_PUSH_NOTIFICATIONS: bool = True
    EAGLE_CAP_TIER_MAP_JSON: str = ''
    EAGLE_PEER_MAP_JSON: str = ''
    EAGLE_FUNDAMENTALS_JSON: str = ''
    EAGLE_DELIVERY_JSON: str = ''
    EAGLE_MACRO_SNAPSHOT_JSON: str = ''
    EAGLE_BACKTEST_MAX_BARS: int = 5000


settings = Settings()
notification_registry = NotificationRegistry()

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    global paper_open_symbols
    init_db()
    paper_open_symbols = open_symbols()
    if not stream_configured() and settings.ANGEL_AUTO_LOGIN and credential_path_available():
        await angel_login()
    await auto_subscribe_universe()
    await start_streams()
    try:
        yield
    finally:
        for task in stream_tasks:
            task.cancel()

app = FastAPI(
    title='Eagle Eye India Backend',
    version='0.7.0',
    docs_url='/docs' if getattr(settings, 'EAGLE_EXPOSE_API_DOCS', False) else None,
    redoc_url=None,
    openapi_url='/openapi.json' if getattr(settings, 'EAGLE_EXPOSE_API_DOCS', False) else None,
    lifespan=lifespan,
)

_allowed_origins = [x.strip() for x in settings.EAGLE_ALLOWED_ORIGINS.split(',') if x.strip()]
if _allowed_origins:
    app.add_middleware(CORSMiddleware, allow_origins=_allowed_origins, allow_credentials=True, allow_methods=['GET','POST'], allow_headers=['Content-Type','X-Eagle-CSRF'])

clients: set[WebSocket] = set()
angel_sockets: set = set()
socket_exchange: dict = {}
socket_tokens: dict = {}
socket_desired_tokens: dict = {}
stream_tasks: List[asyncio.Task] = []
latest: Dict[str, dict] = {}
instruments: Dict[str, dict] = {}
instruments_loaded_at: float = 0.0
session: dict = {}
extra_tokens: set[str] = set()
extra_tokens_by_exchange: dict[int, set[str]] = {}
news_cache: dict[str, tuple[float, dict]] = {}
security_sessions = SessionStore(settings.EAGLE_SESSION_TTL_SEC)
request_limiter = SlidingWindowLimiter()
login_limiter = SlidingWindowLimiter()
provider_quote_limiter = AsyncTokenBucket(settings.EAGLE_REST_QUOTE_RPS, burst=3)
provider_candle_limiter = AsyncTokenBucket(settings.EAGLE_CANDLE_RPS, burst=2)
provider_auth_limiter = AsyncTokenBucket(1.0, burst=1)
paper_update_limiter = AsyncTokenBucket(settings.EAGLE_PAPER_UPDATE_RPS, burst=10)
refresh_lock = asyncio.Lock()
login_lock = asyncio.Lock()
paper_open_symbols: set[str] = set()
last_sequence: dict[str,int] = {}
last_stream_generation: dict[int,int] = {}
stream_generation = 0
last_provider_pong_ms = 0


def now_ms() -> int:
    return int(time.time() * 1000)


def normalise_jwt(value: str) -> str:
    return (value or '').removeprefix('Bearer ').strip()


def api_configured() -> bool:
    return bool(settings.ANGEL_API_KEY and settings.ANGEL_JWT_TOKEN)


def stream_configured() -> bool:
    return bool(settings.ANGEL_API_KEY and settings.ANGEL_CLIENT_CODE and settings.ANGEL_FEED_TOKEN)


def credential_path_available() -> bool:
    return bool(settings.ANGEL_API_KEY and settings.ANGEL_CLIENT_CODE and settings.ANGEL_PASSWORD and settings.ANGEL_TOTP_SECRET)


def headers(include_auth: bool = True) -> dict:
    out = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-PrivateKey': settings.ANGEL_API_KEY,
        'X-UserType': 'USER',
        'X-SourceID': 'WEB',
        'X-ClientLocalIP': '127.0.0.1',
        'X-ClientPublicIP': '0.0.0.0',
        'X-MACAddress': '00:00:00:00:00:00',
    }
    if include_auth and settings.ANGEL_JWT_TOKEN:
        out['Authorization'] = f'Bearer {normalise_jwt(settings.ANGEL_JWT_TOKEN)}'
        out['x-api-key'] = settings.ANGEL_API_KEY
        out['x-client-code'] = settings.ANGEL_CLIENT_CODE
        if settings.ANGEL_FEED_TOKEN:
            out['x-feed-token'] = settings.ANGEL_FEED_TOKEN
    return out



def _cookie_value_from_request(request: Request) -> str | None:
    return request.cookies.get(settings.EAGLE_COOKIE_NAME)


def _authorized_session(request: Request):
    if not settings.EAGLE_REQUIRE_AUTH:
        return True
    rec = security_sessions.validate(_cookie_value_from_request(request))
    return rec


def _origin_allowed(request: Request) -> bool:
    origin = request.headers.get('origin')
    if not origin:
        return settings.EAGLE_ALLOW_NON_BROWSER_API
    if _allowed_origins:
        return origin in _allowed_origins
    expected = f'{request.url.scheme}://{request.url.netloc}'
    return origin == expected


def _session_key(request: Request) -> str:
    raw = _cookie_value_from_request(request)
    if raw:
        import hashlib
        return hashlib.sha256(raw.encode()).hexdigest()
    return 'anonymous'


@app.middleware('http')
async def security_middleware(request: Request, call_next):
    path = request.url.path
    if path.startswith('/api/'):
        content_length = request.headers.get('content-length')
        if content_length:
            try:
                if int(content_length) > settings.EAGLE_MAX_BODY_BYTES:
                    return JSONResponse({'status': False, 'message': 'Request body too large.', 'errorcode': 'EE_BODY_LIMIT'}, status_code=413)
            except ValueError:
                return JSONResponse({'status': False, 'message': 'Invalid Content-Length.', 'errorcode': 'EE_BAD_REQUEST'}, status_code=400)

        public = path in {'/api/healthz', '/api/auth/status', '/api/auth/login'}
        if settings.EAGLE_REQUIRE_AUTH and not public:
            rec = _authorized_session(request)
            if not rec:
                return JSONResponse({'status': False, 'message': 'Authentication required.', 'errorcode': 'EE_AUTH_REQUIRED'}, status_code=401, headers={'Cache-Control':'no-store'})
            request.state.eagle_session = rec

        if request.method in {'POST', 'PUT', 'PATCH', 'DELETE'} and path not in {'/api/auth/login'} and not _origin_allowed(request):
            return JSONResponse({'status': False, 'message': 'Origin check failed.', 'errorcode': 'EE_ORIGIN_REJECTED'}, status_code=403, headers={'Cache-Control':'no-store'})

        key = _session_key(request)
        # Conservative app-level pacing; provider limits are enforced separately below.
        per_minute = 180 if path in {'/api/status','/api/ticks','/api/market/regime'} else 60
        if path == '/api/scan': per_minute = 8
        elif path in {'/api/candles','/api/quote'}: per_minute = 120
        elif path.startswith('/api/ai/'): per_minute = 30
        if not request_limiter.allow(key, per_minute, 60):
            return JSONResponse({'status': False, 'message': 'Rate limit exceeded.', 'errorcode': 'EE_RATE_LIMIT'}, status_code=429, headers={'Cache-Control':'no-store'})

    response = await call_next(request)
    response.headers['Cache-Control'] = 'no-store' if path.startswith('/api/') else response.headers.get('Cache-Control', 'no-cache')
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'no-referrer'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['Permissions-Policy'] = 'accelerometer=(), camera=(), geolocation=(), gyroscope=(), microphone=(), magnetometer=(), payment=(), usb=(), clipboard-read=(), clipboard-write=(self)'
    response.headers['Content-Security-Policy'] = "default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self' https: wss:"
    if settings.EAGLE_COOKIE_SECURE:
        response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    return response


@app.get('/api/healthz')
async def healthz():
    return {
        'status': True,
        'service': 'eagle-eye-india',
        'version': '0.7.0',
        'auth_required': settings.EAGLE_REQUIRE_AUTH,
        'provider': 'Angel One SmartAPI',
        'read_only': True,
        'server_time_ms': now_ms(),
    }


@app.get('/api/auth/status')
async def auth_status(request: Request):
    if not settings.EAGLE_REQUIRE_AUTH:
        return {'status': True, 'authenticated': True, 'auth_required': False}
    rec = _authorized_session(request)
    return {'status': True, 'authenticated': bool(rec), 'auth_required': True}


@app.post('/api/auth/login')
async def app_login(request: Request, body: dict):
    if not settings.EAGLE_ACCESS_TOKEN:
        return JSONResponse({'status': False, 'message': 'Server access token is not configured.', 'errorcode': 'EE_AUTH_SERVER_LOCKED'}, status_code=503)
    if not login_limiter.allow('login', 5, 300):
        return JSONResponse({'status': False, 'message': 'Too many login attempts. Try again later.', 'errorcode': 'EE_LOGIN_RATE_LIMIT'}, status_code=429)
    supplied = str(body.get('access_token') or '')
    if not constant_time_equals(supplied, settings.EAGLE_ACCESS_TOKEN):
        return JSONResponse({'status': False, 'message': 'Invalid access token.', 'errorcode': 'EE_AUTH_FAILED'}, status_code=401)
    raw, csrf, expires_at = security_sessions.create()
    secure = '; Secure' if settings.EAGLE_COOKIE_SECURE else ''
    cookie = f'{settings.EAGLE_COOKIE_NAME}={raw}; Path=/; HttpOnly; SameSite=Strict; Max-Age={settings.EAGLE_SESSION_TTL_SEC}{secure}'
    response = JSONResponse({'status': True, 'authenticated': True, 'expires_at_ms': expires_at*1000, 'csrf_required': False})
    response.headers['Set-Cookie'] = cookie
    return response


@app.post('/api/auth/logout')
async def app_logout(request: Request):
    security_sessions.revoke(_cookie_value_from_request(request))
    response = JSONResponse({'status': True, 'authenticated': False})
    secure = '; Secure' if settings.EAGLE_COOKIE_SECURE else ''
    response.headers['Set-Cookie'] = f'{settings.EAGLE_COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0{secure}'
    return response

async def angel_login(force: bool = False) -> dict:
    global session
    if not credential_path_available() or pyotp is None:
        msg = 'Automatic login needs API key, client code, password and TOTP secret.' if pyotp is not None else 'pyotp package is required for automatic login.'
        return {'status': False, 'message': msg, 'errorcode': 'EE_AUTH_CONFIG'}
    if settings.ANGEL_JWT_TOKEN and settings.ANGEL_FEED_TOKEN and not force:
        return {'status': True, 'message': 'Existing session tokens configured.'}
    async with login_lock:
        if settings.ANGEL_JWT_TOKEN and settings.ANGEL_FEED_TOKEN and not force:
            return {'status': True, 'message': 'Existing session tokens configured.'}
        try:
            await provider_auth_limiter.acquire()
            totp = pyotp.TOTP(settings.ANGEL_TOTP_SECRET).now()
            payload = {'clientcode': settings.ANGEL_CLIENT_CODE, 'password': settings.ANGEL_PASSWORD, 'totp': totp}
            async with httpx.AsyncClient(timeout=settings.EAGLE_REST_TIMEOUT_SEC) as client:
                r = await client.post(ANGEL_LOGIN, headers=headers(False), json=payload)
                data = r.json()
            if not data.get('status') or not data.get('data'):
                return {'status': False, 'message': 'Angel One login was rejected.', 'errorcode': data.get('errorcode', 'EE_AUTH_FAILED')}
            d = data['data']
            settings.ANGEL_JWT_TOKEN = d.get('jwtToken', '')
            settings.ANGEL_FEED_TOKEN = d.get('feedToken', '')
            settings.ANGEL_REFRESH_TOKEN = d.get('refreshToken', '')
            session = {'clientcode': d.get('clientcode', settings.ANGEL_CLIENT_CODE), 'logged_in_at_ms': now_ms()}
            return {'status': True, 'message': 'Angel One SmartAPI session created.', 'logged_in_at_ms': session['logged_in_at_ms']}
        except Exception:
            return {'status': False, 'message': 'Angel One authentication request failed.', 'errorcode': 'EE_AUTH_EXCEPTION'}


async def angel_refresh_session() -> dict:
    global session
    async with refresh_lock:
        return await _angel_refresh_session_locked()


async def _angel_refresh_session_locked() -> dict:
    global session
    if not (settings.ANGEL_REFRESH_TOKEN and settings.ANGEL_API_KEY):
        return {'status': False, 'message': 'Refresh token is not configured.', 'errorcode': 'EE_REFRESH_CONFIG'}
    try:
        await provider_auth_limiter.acquire()
        payload = {'refreshToken': settings.ANGEL_REFRESH_TOKEN}
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.post(ANGEL_REFRESH, headers=headers(False), json=payload)
            data = r.json()
        if not data.get('status') or not data.get('data'):
            return {'status': False, 'message': 'Angel One token refresh was rejected.', 'errorcode': data.get('errorcode', 'EE_REFRESH_FAILED')}
        d = data['data']
        settings.ANGEL_JWT_TOKEN = d.get('jwtToken', settings.ANGEL_JWT_TOKEN)
        settings.ANGEL_FEED_TOKEN = d.get('feedToken', settings.ANGEL_FEED_TOKEN)
        session = {'clientcode': settings.ANGEL_CLIENT_CODE, 'refreshed_at_ms': now_ms()}
        return {'status': True, 'message': 'Angel One tokens refreshed.', 'refreshed_at_ms': session['refreshed_at_ms']}
    except Exception:
        return {'status': False, 'message': 'Angel One token refresh request failed.', 'errorcode': 'EE_REFRESH_EXCEPTION'}


def parse_packet(buf: bytes) -> dict:
    if len(buf) < 51:
        raise ValueError(f'packet too short: {len(buf)}')
    mode = int(buf[0])
    exchange_type = int(buf[1])
    token = buf[2:27].decode('utf-8', errors='ignore').replace('\x00', '')
    seq = struct.unpack_from('<q', buf, 27)[0]
    exchange_ts = struct.unpack_from('<q', buf, 35)[0]
    # Angel One SmartAPI LTP is a signed 64-bit integer at bytes 43-50, scaled by 100.
    ltp_raw = struct.unpack_from('<q', buf, 43)[0]
    out = {
        'mode': mode, 'exchange_type': exchange_type, 'token': token,
        'sequence': seq, 'exchange_timestamp_ms': exchange_ts,
        'ltp': ltp_raw / 100.0, 'received_timestamp_ms': now_ms(),
    }
    if mode in (2, 3):
        if len(buf) < 131:
            raise ValueError(f'quote packet too short: {len(buf)}')
        def q(off): return struct.unpack_from('<q', buf, off)[0]
        out.update({
            'last_traded_quantity': q(51), 'average_traded_price': q(59) / 100.0,
            'volume_trade_for_day': q(67), 'total_buy_quantity': struct.unpack_from('<d', buf, 75)[0],
            'total_sell_quantity': struct.unpack_from('<d', buf, 83)[0], 'open': q(91) / 100.0,
            'high': q(99) / 100.0, 'low': q(107) / 100.0, 'close': q(115) / 100.0,
            'last_traded_timestamp': q(123),
        })
    if mode == 3:
        # Angel One SnapQuote has a fixed 379-byte core; when best-five depth is
        # present the documented extension is 10 x 20 bytes = 200 bytes.
        # Reject partially formed depth packets instead of silently accepting
        # truncated market depth.
        if len(buf) not in (379, 579):
            raise ValueError(f'invalid snapquote packet length: {len(buf)}')
        def q(off): return struct.unpack_from('<q', buf, off)[0]
        out.update({
            'open_interest': q(131), 'upper_circuit': q(347) / 100.0,
            'lower_circuit': q(355) / 100.0, 'week52_high': q(363) / 100.0,
            'week52_low': q(371) / 100.0,
        })
        # Ten best-five records follow at byte 379, 20 bytes each.
        depth_buy, depth_sell = [], []
        for i in range(10):
            off = 379 + i * 20
            if len(buf) < off + 20: break
            flag = struct.unpack_from('<h', buf, off)[0]
            qty = struct.unpack_from('<q', buf, off + 2)[0]
            price = struct.unpack_from('<q', buf, off + 10)[0] / 100.0
            orders = struct.unpack_from('<h', buf, off + 18)[0]
            if flag not in (0, 1) or qty < 0 or orders < 0 or (price and price < 0):
                raise ValueError('invalid best-five depth record')
            row = {'quantity': qty, 'price': price, 'orders': orders}
            # Angel One: best-five flag 1=buy, 0=sell.
            (depth_buy if flag == 1 else depth_sell).append(row)
        out['depth'] = {'buy': depth_buy, 'sell': depth_sell}
    return out


def validate_tick(tick: dict, previous_sequence: int | None = None) -> tuple[bool, str]:
    try:
        token = str(tick.get('token') or '')
        exchange_type = int(tick.get('exchange_type'))
        ltp = float(tick.get('ltp'))
        exchange_ts = int(tick.get('exchange_timestamp_ms'))
        received_ts = int(tick.get('received_timestamp_ms'))
    except (TypeError, ValueError):
        return False, 'MALFORMED_TICK'
    if not token or exchange_type not in {1,2,3,4,5,7,13} or ltp <= 0:
        return False, 'INVALID_TICK_FIELDS'
    if exchange_ts <= 0 or received_ts <= 0:
        return False, 'INVALID_TIMESTAMP'
    now = now_ms()
    if exchange_ts > now + settings.EAGLE_CLOCK_SKEW_MAX_MS:
        return False, 'EXCHANGE_TIMESTAMP_IN_FUTURE'
    if now - exchange_ts > settings.EAGLE_TICK_MAX_AGE_MS:
        return False, 'EXCHANGE_TICK_TOO_OLD'
    # Index feeds may not provide a meaningful sequence number according to Angel One's docs.
    if exchange_type != 1 or token not in INDEX_TOKENS:
        seq = int(tick.get('sequence') or 0)
        if previous_sequence is not None and seq and seq <= previous_sequence:
            return False, 'OUT_OF_ORDER_SEQUENCE'
    if not math.isfinite(ltp):
        return False, 'INVALID_LTP'
    if 'high' in tick and 'low' in tick:
        try:
            high, low = float(tick['high']), float(tick['low'])
            opn, close = float(tick.get('open') or 0), float(tick.get('close') or 0)
            if high < low or not (low <= ltp <= high):
                return False, 'INVALID_PRICE_RANGE'
            if opn > 0 and not (low <= opn <= high):
                return False, 'INVALID_OPEN_RANGE'
            if close > 0 and not (low <= close <= high):
                return False, 'INVALID_CLOSE_RANGE'
            for field in ('average_traded_price', 'total_buy_quantity', 'total_sell_quantity', 'volume_trade_for_day'):
                if field in tick and not math.isfinite(float(tick[field])):
                    return False, 'INVALID_NUMERIC_FIELD'
                if field in tick and float(tick[field]) < 0:
                    return False, 'NEGATIVE_NUMERIC_FIELD'
        except (TypeError, ValueError):
            return False, 'INVALID_PRICE_RANGE'
    return True, 'PASS'

def stream_key(exchange_type: int, token: str) -> str:
    return f'{exchange_type}:{token}'


def configured_tokens(exchange_type: int = 1) -> List[str]:
    if exchange_type != 1:
        return sorted(extra_tokens_by_exchange.get(exchange_type, set()))
    values = {meta['token'] for meta in INDEX_CATALOG.values()}
    for part in settings.EAGLE_TOKENS.split(','):
        if part.strip(): values.add(part.strip())
    values.update(extra_tokens_by_exchange.get(1, set()))
    values.update(extra_tokens)
    return sorted(values)

def sub_message(tokens: List[str], mode: int = 3, exchange_type: int = 1) -> dict:
    return {
        'correlationID': 'eagle-eye',
        'action': 1,
        'params': {'mode': mode, 'tokenList': [{'exchangeType': exchange_type, 'tokens': tokens}]},
    }


async def broadcast(item: dict):
    dead = []
    for ws in clients:
        try:
            await ws.send_json(item)
        except Exception:
            dead.append(ws)
    for ws in dead:
        clients.discard(ws)


async def angel_stream(tokens: List[str] | set[str], exchange_type: int = 1):
    global stream_generation, last_provider_pong_ms
    if not stream_configured() or not tokens:
        return
    desired_tokens = tokens if isinstance(tokens, set) else set(tokens)
    backoff = 1
    while True:
        try:
            current_tokens = sorted(desired_tokens)
            if not current_tokens:
                return
            stream_generation += 1
            generation = stream_generation
            provider_headers = {
                'Authorization': normalise_jwt(settings.ANGEL_JWT_TOKEN),
                'x-api-key': settings.ANGEL_API_KEY,
                'x-client-code': settings.ANGEL_CLIENT_CODE,
                'x-feed-token': settings.ANGEL_FEED_TOKEN,
            }
            async with websockets.connect(ANGEL_WS, additional_headers=provider_headers, ping_interval=None, close_timeout=5, max_size=2**20) as ws:
                angel_sockets.add(ws)
                socket_exchange[ws] = exchange_type
                socket_tokens[ws] = set(current_tokens)
                socket_desired_tokens[ws] = desired_tokens
                await ws.send(json.dumps(sub_message(current_tokens, 3, exchange_type)))
                await broadcast({'type': 'status', 'status': 'CONNECTED_WAITING_FOR_TICKS', 'subscription_count': len(current_tokens), 'at': now_ms(), 'generation': generation})
                backoff = 1
                local_last_pong_ms = 0
                for tok in current_tokens:
                    last_sequence.pop(stream_key(exchange_type, tok), None)

                async def heartbeat():
                    nonlocal ws, local_last_pong_ms
                    while True:
                        await asyncio.sleep(10)
                        await ws.send('ping')
                        if now_ms() - local_last_pong_ms > 45000:
                            await ws.close(code=1012, reason='provider heartbeat timeout')
                            return

                hb = asyncio.create_task(heartbeat())
                try:
                    async for msg in ws:
                        if isinstance(msg, bytes):
                            try:
                                tick = parse_packet(msg)
                                key = stream_key(tick['exchange_type'], tick['token'])
                                previous = last_sequence.get(key)
                                valid, reason = validate_tick(tick, previous)
                                if not valid:
                                    await broadcast({'type': 'error', 'source': 'angelone', 'message': f'Tick rejected: {reason}', 'at': now_ms()})
                                    continue
                                if tick.get('sequence') and (int(tick.get('exchange_type', 0)) != 1 or str(tick.get('token')) not in INDEX_TOKENS):
                                    last_sequence[key] = int(tick['sequence'])
                            except Exception as exc:
                                await broadcast({'type': 'error', 'source': 'angelone', 'message': 'Tick parsing/validation failed; rejected safely.', 'at': now_ms()})
                                continue
                            key = stream_key(tick['exchange_type'], tick['token'])
                            tick['instrument'] = instruments.get(key)
                            latest[key] = tick
                            if tick.get('exchange_type') == 1 and tick.get('instrument'):
                                symbol = normalise_symbol(str(tick['instrument'].get('symbol') or ''))
                                if symbol in paper_open_symbols and tick.get('ltp'):
                                    try:
                                        await paper_update_limiter.acquire()
                                        result = await asyncio.to_thread(update_from_price, symbol, float(tick['ltp']), now_ms(), 'ANGEL_ONE_LIVE', int(tick.get('exchange_timestamp_ms') or now_ms()))
                                        if isinstance(result, dict) and result.get('closed_ids'):
                                            paper_open_symbols.clear(); paper_open_symbols.update(open_symbols())
                                    except Exception as exc:
                                        await broadcast({'type': 'error', 'source': 'paper', 'message': 'Paper update failed safely; market tick retained but trade state was not advanced.', 'at': now_ms()})
                            await broadcast({'type': 'tick', 'data': tick})
                        elif msg == 'pong':
                            local_last_pong_ms = now_ms()
                            last_provider_pong_ms = max(last_provider_pong_ms, local_last_pong_ms)
                            await broadcast({'type': 'heartbeat', 'at': local_last_pong_ms})
                        else:
                            # Do not forward raw provider control/auth messages to clients.
                            try:
                                payload = json.loads(msg)
                                safe = {k: payload.get(k) for k in ('errorCode','errorMessage','correlationID') if k in payload}
                                if safe:
                                    await broadcast({'type': 'provider_message', 'data': safe})
                            except Exception:
                                pass
                finally:
                    hb.cancel()
                    angel_sockets.discard(ws)
                    socket_exchange.pop(ws, None)
                    socket_tokens.pop(ws, None)
                    socket_desired_tokens.pop(ws, None)
        except asyncio.CancelledError:
            return
        except Exception as exc:
            detail = str(exc)
            response = getattr(exc, 'response', None)
            provider_status = getattr(response, 'status_code', None) or getattr(exc, 'status_code', None)
            auth_error = provider_status in (401, 403) or any(x in detail.lower() for x in ('token', 'feed token', 'unauthorized', 'forbidden'))
            await broadcast({'type': 'status', 'status': 'DISCONNECTED', 'message': 'Angel One stream disconnected.', 'reason': 'AUTH_ERROR' if auth_error else 'NETWORK_OR_PROVIDER_ERROR', 'at': now_ms()})
            if auth_error and settings.ANGEL_REFRESH_TOKEN:
                refreshed = await angel_refresh_session()
                if not refreshed.get('status') and credential_path_available():
                    await angel_login(force=True)
            elif auth_error and credential_path_available():
                await angel_login(force=True)
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 30)


async def start_streams():
    global stream_tasks
    for task in stream_tasks:
        task.cancel()
    stream_tasks = []
    socket_desired_tokens.clear()
    socket_tokens.clear()
    if not stream_configured(): return
    groups = {1: configured_tokens(1), **{k: sorted(v) for k, v in extra_tokens_by_exchange.items() if k != 1 and v}}
    max_sessions = max(1, min(settings.EAGLE_MAX_STREAM_SESSIONS, 3))
    session_count = 0
    for ex_type, tokens in groups.items():
        if not tokens: continue
        for i in range(0, len(tokens), 1000):
            if session_count >= max_sessions: break
            chunk=tokens[i:i+1000]
            task = asyncio.create_task(angel_stream(set(chunk), ex_type))
            setattr(task, '_eagle_exchange_type', ex_type)
            stream_tasks.append(task)
            session_count += 1



async def ensure_instruments(force: bool = False) -> int:
    global instruments, instruments_loaded_at
    if instruments and not force and time.time() - instruments_loaded_at < settings.INSTRUMENT_CACHE_MAX_AGE_SEC:
        return len(instruments)
    async with httpx.AsyncClient(timeout=25) as client:
        r = await client.get(ANGEL_INSTRUMENTS)
        r.raise_for_status()
        raw = r.json()
    parsed: Dict[str, dict] = {}
    for x in raw:
        seg = str(x.get('exch_seg') or '').upper()
        if seg not in ('NSE', 'BSE', 'NFO', 'BFO', 'MCX', 'CDE'):
            continue
        token = str(x.get('token') or '')
        if not token:
            continue
        ex_type = {'NSE':1,'NFO':2,'BSE':3,'BFO':4,'MCX':5,'CDS':13,'CDE':13}.get(seg)
        if ex_type is None:
            continue
        parsed[stream_key(ex_type, token)] = {
            'token': token,
            'symbol': x.get('symbol') or x.get('tradingsymbol') or '',
            'name': x.get('name') or '',
            'exch_seg': x.get('exch_seg'),
            'instrumenttype': x.get('instrumenttype'),
            'expiry': x.get('expiry'),
            'lotsize': x.get('lotsize'),
            'tick_size': x.get('tick_size'),
        }
    instruments = parsed
    instruments_loaded_at = time.time()
    for key, tick in latest.items():
        tick['instrument'] = instruments.get(key)
    return len(instruments)


async def fetch_candles(body: dict) -> dict:
    if not api_configured():
        return {'status': False, 'message': 'Angel One API credentials are not configured.', 'errorcode': 'EE_NO_PROVIDER'}
    required = ['exchange', 'symboltoken', 'interval', 'fromdate', 'todate']
    if any(k not in body for k in required):
        return {'status': False, 'message': 'Missing candle parameters.', 'errorcode': 'EE_BAD_REQUEST'}
    await provider_candle_limiter.acquire()
    async with httpx.AsyncClient(timeout=settings.EAGLE_REST_TIMEOUT_SEC) as client:
        r = await client.post(ANGEL_CANDLE, headers=headers(), json=body)
        if r.status_code == 403 and settings.ANGEL_REFRESH_TOKEN:
            refreshed = await angel_refresh_session()
            if refreshed.get('status'):
                r = await client.post(ANGEL_CANDLE, headers=headers(), json=body)
        return r.json()



def rss_urls() -> list[str]:
    configured=[x.strip() for x in settings.NEWS_RSS_URLS.split(',') if x.strip()]
    defaults=[
        'https://nsearchives.nseindia.com/content/RSS/Online_announcements.xml',
        'https://nsearchives.nseindia.com/content/RSS/Corporate_action.xml',
        'https://nsearchives.nseindia.com/content/RSS/Circulars.xml',
        'https://www.sebi.gov.in/sebirss.xml',
    ]
    return list(dict.fromkeys(configured+defaults))


async def get_news(company: str, symbol: str, force: bool = False) -> dict:
    key = f'{symbol.upper()}::{company.upper()}'
    cached = news_cache.get(key)
    if cached and not force and time.time() - cached[0] <= settings.NEWS_CACHE_TTL_SEC:
        payload = dict(cached[1])
        payload['cached'] = True
        payload['cached_at_ms'] = int(cached[0] * 1000)
        return payload
    payload = await search_news(company, symbol, rss_urls())
    payload['cached'] = False
    news_cache[key] = (time.time(), payload)
    return payload


def analysis_timestamp_payload() -> dict:
    return {'analysis_time_ms': now_ms(), 'analysis_time_ist': datetime.now(IST).isoformat()}


async def auto_subscribe_universe():
    if not settings.EAGLE_AUTO_SUBSCRIBE_UNIVERSE or not stream_configured(): return {'status': False, 'reason': 'AUTO_SUBSCRIBE_DISABLED_OR_UNCONFIGURED'}
    try:
        # Keep the auto-universe conservative: NSE cash instruments only, no derivatives/ETFs by default.
        await ensure_instruments()
        rows=[]
        for k,inst in instruments.items():
            if inst.get('exch_seg') != 'NSE': continue
            typ=str(inst.get('instrumenttype') or '')
            sym=str(inst.get('symbol') or '')
            if not (typ == 'EQ' or sym.endswith('-EQ') or sym.endswith('-BE')): continue
            if sym in ('NIFTY','BANKNIFTY'): continue
            rows.append((k.split(':',1)[-1],inst))
        rows=rows[:max(1,min(settings.EAGLE_AUTO_SUBSCRIBE_LIMIT, 1800))]
        extra_tokens_by_exchange.setdefault(1,set()).update(t for t,_ in rows)
        extra_tokens.update(t for t,_ in rows)
        return {'status': True,'subscribed_candidate_count':len(rows)}
    except Exception:
        return {'status': False, 'reason': 'INSTRUMENT DATA UNAVAILABLE'}


@app.get('/api/system/security')
async def system_security():
    return {
        'status': True,
        'privacy': {
            'phone_permissions_requested': [],
            'location_access': False,
            'contacts_access': False,
            'camera_access': False,
            'microphone_access': False,
            'advertising_id': False,
            'device_identifier': False,
            'telemetry': False,
            'analytics': False,
            'third_party_tracking': False,
            'paper_trade_data_shared_with_third_parties': False,
        },
        'security': {
            'api_keys_in_mobile': False,
            'broker_orders_enabled': settings.EAGLE_ENABLE_BROKER_ORDERS,
            'read_only_default': True,
            'authentication_required': settings.EAGLE_REQUIRE_AUTH,
            'same_origin_by_default': not bool(_allowed_origins),
            'api_docs_exposed': settings.EAGLE_EXPOSE_API_DOCS,
            'api_response_cache': 'DISABLED',
            'provider_raw_control_messages_forwarded': False,
        },
        'live_data_guards': {
            'sequence_ordering': True,
            'timestamp_sanity': True,
            'ohlc_validation': True,
            'heartbeat_guard': True,
            'stale_tick_rejection': True,
            'provider_rate_pacing': True,
        },
        'server_time_ms': now_ms(),
    }

@app.get('/api/status')
async def status():
    now = now_ms()
    fresh, stale = [], []
    for key, tick in latest.items():
        age = now - int(tick.get('received_timestamp_ms', 0))
        (fresh if age <= settings.STALE_AFTER_MS else stale).append(key)
    critical_live = all(f'1:{INDEX_CATALOG[k]["token"]}' in fresh for k in ('NIFTY','BANKNIFTY'))
    heartbeat_age = (now - last_provider_pong_ms) if last_provider_pong_ms else None
    heartbeat_status = 'LIVE' if heartbeat_age is not None and heartbeat_age <= 45_000 else ('UNCONFIRMED' if stream_configured() else 'UNAVAILABLE')
    requested_tokens = len(configured_tokens(1)) + sum(len(v) for k,v in extra_tokens_by_exchange.items() if k != 1)
    active_stream_tokens = sum(len(v) for v in socket_tokens.values())
    return {
        'provider': 'Angel One SmartAPI',
        'configured': stream_configured(),
        'api_configured': api_configured(),
        'auto_login_available': credential_path_available(),
        'data_status': 'LIVE' if critical_live else ('STALE' if fresh or stale else 'UNAVAILABLE'),
        'critical_market_data_status': 'LIVE' if critical_live else 'DEGRADED',
        'provider_heartbeat_age_ms': heartbeat_age,
        'provider_heartbeat_status': heartbeat_status,
        'fresh_ticks': fresh,
        'stale_ticks': stale,
        'last_tick_ms': max((int(t.get('received_timestamp_ms', 0)) for t in latest.values()), default=None),
        'data_validation': {'sequence_ordering': True, 'timestamp_sanity': True, 'ohlc_validation': True, 'provider_heartbeat_guard': True},
        'paper_tracking': {'mode': 'LIVE_TICKS_ONLY', 'open_symbols': sorted(paper_open_symbols), 'manual_revalue_enabled': settings.EAGLE_MANUAL_REVALUE},
        'server_time_ms': now,
        'read_only': True,
        'subscription_capacity': 1000 * max(1, min(settings.EAGLE_MAX_STREAM_SESSIONS, 3)),
        'stale_after_ms': settings.STALE_AFTER_MS,
        'clock_skew_max_ms': settings.EAGLE_CLOCK_SKEW_MAX_MS,
        'subscribed_tokens': requested_tokens,
        'active_stream_tokens': active_stream_tokens,
        'unstreamed_requested_tokens': max(0, requested_tokens - active_stream_tokens),
        'active_provider_streams': len(angel_sockets),
        'configured_stream_tasks': len([t for t in stream_tasks if not t.done()]),
        'session_phase': session_phase(),
    }


@app.get('/api/ticks')
async def ticks():
    return {'data': list(latest.values()), 'server_time_ms': now_ms()}


@app.get('/api/market/regime')
async def market_regime_endpoint():
    return market_regime(latest, now_ms(), settings.STALE_AFTER_MS)


@app.post('/api/broker/login')
async def broker_login():
    result = await angel_login(force=True)
    if result.get('status'):
        await start_streams()
    return result


@app.post('/api/broker/refresh')
async def broker_refresh():
    result = await angel_refresh_session()
    if result.get('status'):
        await start_streams()
    return result


@app.post('/api/candles')
async def candles(body: dict):
    requested=dict(body or {})
    interval=str(requested.get('interval') or '').upper()
    if interval == 'ONE_WEEK':
        # Angel One's historical endpoint is safest here with daily data; weekly is a calendar-week resample.
        daily=dict(requested)
        daily['interval']='ONE_DAY'
        raw=await fetch_candles(daily)
        if not raw.get('status'):
            return raw
        rows=raw.get('data') or []
        weekly=timeframe_set([], rows).get('1w', [])
        return {**raw, 'data':weekly, 'requested_interval':'ONE_WEEK', 'source_interval':'ONE_DAY_RESAMPLED'}
    return await fetch_candles(requested)


@app.post('/api/technical/analyze')
async def technical_analyze_endpoint(body: dict):
    candle_rows = body.get('candles')
    result = technical_analyze(candle_rows)
    return {
        'status': bool(result.get('valid')),
        'data_status': 'VALID' if result.get('valid') else 'UNAVAILABLE',
        'analysis': result,
        'server_time_ms': now_ms(),
    }


@app.post('/api/subscribe')
async def subscribe(body: dict):
    if not stream_configured():
        return {'status': False, 'message': 'Angel One streaming is not configured.', 'errorcode': 'EE_NO_STREAM'}
    tokens = body.get('tokens') or []
    try:
        exchange_type = int(body.get('exchange_type', 1))
    except (TypeError, ValueError):
        return {'status': False, 'message': 'Invalid exchange type.', 'errorcode': 'EE_BAD_REQUEST'}
    valid_types = {1,2,3,4,5,7,13}
    if exchange_type not in valid_types or not isinstance(tokens, list) or not tokens:
        return {'status': False, 'message': 'Invalid exchange type or empty token list.', 'errorcode': 'EE_BAD_REQUEST'}
    clean = sorted({str(t).strip() for t in tokens if str(t).strip()})
    if len(clean) > 1000:
        return {'status': False, 'message': 'A single subscription request is limited to 1,000 tokens.', 'errorcode': 'EE_SUB_LIMIT'}
    existing_global = set(configured_tokens(exchange_type))
    new_tokens = [t for t in clean if t not in existing_global]
    capacity = 1000 * max(1, min(settings.EAGLE_MAX_STREAM_SESSIONS, 3))
    current_total = sum(len(configured_tokens(ex)) for ex in {1,2,3,4,5,7,13})
    if current_total + len(new_tokens) > capacity:
        return {'status': False, 'message': 'Subscription capacity exceeded.', 'errorcode': 'EE_SUB_LIMIT'}
    extra_tokens_by_exchange.setdefault(exchange_type, set()).update(new_tokens)
    if exchange_type == 1:
        extra_tokens.update(new_tokens)

    # Put each new token only on a socket that has room. Never push a 1,001st
    # token onto an already-full WebSocket session.
    pending = list(clean)
    sent = False
    for aws in list(angel_sockets):
        if socket_exchange.get(aws) != exchange_type:
            continue
        subscribed = socket_tokens.setdefault(aws, set())
        available = max(0, 1000 - len(subscribed))
        add = [t for t in pending if t not in subscribed][:available]
        if not add:
            continue
        try:
            await aws.send(json.dumps(sub_message(add, 3, exchange_type)))
            subscribed.update(add)
            socket_desired_tokens.setdefault(aws, set()).update(add)
            pending = [t for t in pending if t not in set(add)]
            sent = True
            if not pending:
                break
        except Exception:
            continue

    # If any tokens remain and a broker session slot exists, start a dedicated
    # stream for only those tokens. This keeps token allocation <= 1,000/session.
    if pending and len(stream_tasks) < max(1, min(settings.EAGLE_MAX_STREAM_SESSIONS, 3)):
        task = asyncio.create_task(angel_stream(set(pending), exchange_type))
        setattr(task, '_eagle_exchange_type', exchange_type)
        stream_tasks.append(task)
        sent = True

    return {
        'status': True,
        'subscribed': clean,
        'new_tokens': new_tokens,
        'exchange_type': exchange_type,
        'live_socket_updated': sent and not pending,
        'queued_for_new_socket': pending,
        'capacity': capacity,
    }


@app.post('/api/instruments/refresh')
async def instruments_refresh():
    count = await ensure_instruments(force=True)
    return {
        'status': True,
        'count': count,
        'data': list(instruments.values()),
        'loaded_at_ms': int(instruments_loaded_at * 1000),
    }


@app.get('/api/instruments/search')
async def instruments_search(q: str, limit: int = 30):
    await ensure_instruments()
    query = q.strip().upper()
    rows = [x for x in instruments.values() if query in str(x.get('symbol', '')).upper() or query in str(x.get('name', '')).upper()]
    rows = rows[:max(1, min(limit, 100))]
    return {'status': True, 'count': len(rows), 'data': rows}


@app.post('/api/quote')
async def quote(body: dict):
    if not api_configured():
        return {'status': False, 'message': 'Angel One API credentials are not configured.', 'errorcode': 'EE_NO_PROVIDER'}
    tokens = body.get('tokens') or []
    exchange = str(body.get('exchange') or 'NSE').upper()
    if not isinstance(tokens, list) or not tokens or len(tokens) > 50 or exchange not in ('NSE', 'BSE'):
        return {'status': False, 'message': 'Use 1-50 tokens and exchange NSE or BSE.', 'errorcode': 'EE_BAD_REQUEST'}
    payload = {'mode': str(body.get('mode') or 'FULL').upper(), 'exchangeTokens': {exchange: [str(t) for t in tokens]}}
    await provider_quote_limiter.acquire()
    async with httpx.AsyncClient(timeout=settings.EAGLE_REST_TIMEOUT_SEC) as client:
        r = await client.post(ANGEL_QUOTE, headers=headers(), json=payload)
        if r.status_code == 403 and settings.ANGEL_REFRESH_TOKEN:
            refreshed = await angel_refresh_session()
            if refreshed.get('status'):
                r = await client.post(ANGEL_QUOTE, headers=headers(), json=payload)
        return r.json()


@app.get('/api/news')
async def news(company: str = '', symbol: str = '', force: bool = False):
    if not (company or symbol):
        return {'status': False, 'message': 'Company or symbol is required.', 'errorcode': 'EE_BAD_REQUEST'}
    return await get_news(company, symbol, force=force)


@app.post('/api/evidence')
async def evidence_endpoint(body: dict):
    company = str(body.get('company') or '')
    symbol = str(body.get('symbol') or '')
    if not (company or symbol):
        return {'status': False, 'message': 'Company or symbol is required.', 'errorcode': 'EE_BAD_REQUEST'}
    news_payload = await get_news(company, symbol, force=bool(body.get('force')))
    result = build_evidence(news_payload, now_ms(), body.get('technical'), body.get('market_regime'))
    return {'status': True, **analysis_timestamp_payload(), 'news': news_payload, 'evidence': result.__dict__}


async def deep_ai_analysis(context: dict, skeptic: bool = False) -> dict:
    payload = {
        'OPENAI_API_KEY': settings.OPENAI_API_KEY,
        'OPENAI_MODEL': settings.OPENAI_MODEL,
        'OPENAI_WEB_SEARCH': settings.OPENAI_WEB_SEARCH,
        'context': context,
    }
    return await run_openai(payload, skeptic=skeptic)


@app.post('/api/ai/analyze')
async def ai_analyze(body: dict):
    context = body.get('context') or body
    return await deep_ai_analysis(context, skeptic=False)


@app.post('/api/ai/skeptic')
async def ai_skeptic(body: dict):
    context = body.get('context') or body
    return await deep_ai_analysis(context, skeptic=True)


prior_oi_store: dict[str,float] = {}
prior_futures_price_store: dict[str,float] = {}

def has_fo(symbol: str) -> bool:
    s=normalise_symbol(symbol)
    for inst in instruments.values():
        if str(inst.get('exch_seg') or '').upper()=='NFO' and str(inst.get('name') or '').upper()==s and str(inst.get('instrumenttype') or '').upper() in ('FUTSTK','OPTSTK'):
            return True
    return False

def minimal_result(symbol,name,tick,reason):
    return {'symbol':symbol,'name':name,'token':tick.get('token'),'price':tick.get('ltp'),'change_pct':None,'status':'WATCHLIST','setup_score':0,'mandatory_gates':{'reliable_current_data':True,'valid_setup':False},'evidence_confidence':'LOW','verification':'UNVERIFIED','three_source_status':'3-SOURCE VERIFICATION UNAVAILABLE','reasons':[reason],'main_risk':reason}

async def update_paper_marks():
    # Defensive compatibility helper. Paper trades are primarily driven by the live
    # stream. If this helper is ever called, only fresh validated ticks with their
    # original exchange timestamp may mutate the paper journal.
    now = now_ms()
    for t in latest.values():
        if int(t.get('exchange_type', 1)) != 1 or not t.get('ltp'):
            continue
        received = int(t.get('received_timestamp_ms') or 0)
        market_time = int(t.get('exchange_timestamp_ms') or 0)
        if not received or now - received > settings.STALE_AFTER_MS or not market_time:
            continue
        inst = t.get('instrument') or {}
        symbol = normalise_symbol(str(inst.get('symbol') or ''))
        if not symbol:
            continue
        update_from_price(symbol, float(t['ltp']), now, 'ANGEL_ONE_LIVE_RECHECK', market_time)


@app.post('/api/scan')
async def scan(body: dict | None = None):
    body=body or {}; scan_started=now_ms()
    try: await ensure_instruments()
    except Exception:
        return {'status':True,'status_code':'NO_QUALIFIED_SETUP','message':'INSTRUMENT DATA UNAVAILABLE','shortlist':[],'qualified_count':0,'candidate_count':0,'market_regime':market_regime(latest,scan_started,settings.STALE_AFTER_MS),'gate_state':{'decision':'NO_QUALIFIED_SETUP'}}
    regime=market_regime(latest,scan_started,settings.STALE_AFTER_MS)
    current_session = session_phase(datetime.now(IST))
    nifty_change=((regime.get('indices') or {}).get('NIFTY 50') or {}).get('change_pct')
    fresh=[]
    for key,t in latest.items():
        if int(t.get('exchange_type',1)) != 1 or t.get('token') in INDEX_TOKENS: continue
        if scan_started-int(t.get('received_timestamp_ms',0)) > settings.STALE_AFTER_MS: continue
        inst=instruments.get(key) or t.get('instrument') or {}
        if not inst or str(inst.get('instrumenttype') or '').upper() in ('AMXIDX','ETF'): continue
        if not t.get('close') or not t.get('ltp'): continue
        symbol_hint=str(inst.get('symbol') or '')
        requested_universe=str(body.get('universe') or 'ALL').upper()
        if requested_universe in {'LARGE','MID','SMALL','MICRO','PENNY'} and cap_tier(symbol_hint, float(t.get('ltp') or 0)) != requested_universe: continue
        if not passes_universe(symbol_hint, inst, requested_universe): continue
        if requested_universe == 'SECTOR' and str(body.get('sector') or '').strip(): pass
        req_sector=str(body.get('sector') or '').strip().upper()
        if req_sector and str(sector_for_symbol(symbol_hint, str(inst.get('name') or '')) or '').upper() != req_sector: continue
        if requested_universe == 'FNO' and not has_fo(symbol_hint): continue
        liq=assess_liquidity(t,float(body.get('min_traded_value_inr',settings.MIN_TRADED_VALUE_INR)))
        if not liq.get('pass'): continue
        fresh.append((key,t,inst,liq))
    # Stage 1: mathematical/technical pre-filter by price change, then candle analysis.
    fresh.sort(key=lambda r: abs(((r[1].get('ltp') or 0)-(r[1].get('close') or 0))/(r[1].get('close') or 1)), reverse=True)
    limit=max(1,min(int(body.get('candidate_limit',settings.SCAN_TOP_CANDIDATES)),15))
    candidates=fresh[:limit]
    if not candidates:
        return {'status':True,'status_code':'NO_QUALIFIED_SETUP','message':'NO QUALIFIED SETUP — no fresh liquid live candidates were available.','shortlist':[],'qualified_count':0,'candidate_count':0,'market_regime':regime,'session':current_session,'gate_state':{'data_freshness':'FAIL','technical':'NOT RUN','liquidity':'FAIL','catalyst':'NOT RUN','three_source_verification':'NOT RUN','skeptic':'NOT RUN','decision':'NO_QUALIFIED_SETUP'}}
    now_dt=datetime.now(IST)
    if not current_session.get('is_cash_continuous'):
        return {'status':True,'status_code':'NO_QUALIFIED_SETUP','message':'OUTSIDE CASH CONTINUOUS SESSION — intraday confirmation is not treated as current.','shortlist':[],'qualified_count':0,'candidate_count':len(candidates),'market_regime':regime,'session':current_session,'gate_state':{'data_freshness':'PASS','technical':'NOT RUN','liquidity':'PASS','catalyst':'NOT RUN','three_source_verification':'NOT RUN','skeptic':'NOT RUN','decision':'NO_QUALIFIED_SETUP'}}
    date_s=now_dt.strftime('%Y-%m-%d'); to_s=now_dt.strftime('%Y-%m-%d %H:%M'); from_s=f'{date_s} 09:15'
    sem=asyncio.Semaphore(3)

    async def one_candidate(row):
        key,tick,inst,liq=row; symbol=str(inst.get('symbol') or key.split(':',1)[-1]); name=str(inst.get('name') or symbol)
        async with sem:
            cr=await fetch_candles({'exchange':'NSE','symboltoken':str(tick['token']),'interval':'FIVE_MINUTE','fromdate':from_s,'todate':to_s})
        if not cr.get('status') or not isinstance(cr.get('data'),list) or len(cr.get('data'))<30:
            return minimal_result(symbol,name,tick,'TECHNICAL DATA STALE/UNAVAILABLE')
        candles=cr['data']; tech=technical_analyze(candles); tq=technical_quality(tech,tick,nifty_change)
        sector=sector_snapshot(symbol,name,regime)
        news_payload=await get_news(name,symbol,force=False)
        evidence=build_evidence(news_payload,scan_started,tq,regime).__dict__
        levels=build_levels(tq,candles)
        derivative={'applicable':has_fo(symbol),'available':False,'bias':'NEUTRAL'}
        if derivative['applicable'] and tq.get('score_pct',0)>=55:
            async with sem:
                try:
                    sel=select_contracts(instruments,normalise_symbol(symbol),float(tick.get('ltp') or 0))
                    derivative['selected']=sel
                    if sel.get('available') and api_configured():
                        toks=[str(x.get('token')) for x in (sel.get('futures') or [])+(sel.get('options') or []) if x.get('token')]
                        if toks: await subscribe({'tokens':toks,'exchange_type':2})
                        qr=await quote({'tokens':toks[:50],'exchange':'NFO','mode':'FULL'})
                        snap=derivative_snapshot({'spot':tick.get('ltp'),**sel},parse_quotes(qr),prior_oi_store,prior_futures_price_store)
                        derivative.update(snap)
                        for q in (snap.get('calls') or [])+(snap.get('puts') or [])+(snap.get('futures') or []):
                            if q.get('symboltoken') and q.get('oi') is not None: prior_oi_store[q['symboltoken']]=float(q['oi'])
                            if q.get('symboltoken') and q.get('ltp') is not None and q in (snap.get('futures') or []): prior_futures_price_store[q['symboltoken']]=float(q['ltp'])
                except Exception as exc:
                    derivative['error']=str(exc)
        manipulation=manipulation_flags(tick,tq,evidence,sector)
        liq2={**liq,'level':liq.get('level','LOW'),'manipulation_flags':manipulation}
        tier=cap_tier(symbol, float(tick.get('ltp') or 0))
        tierpol=tier_policy(tier)
        if float(tq.get('relative_volume20') or 0) < float(tierpol['min_relative_volume']):
            liq2['pass']=False; liq2['level']='LOW'; liq2['reason']='CAP_TIER_RELATIVE_VOLUME_FLOOR'
        skeptic=run_skeptic(tq,evidence,tick,regime,levels,sector,derivative,liq2)
        ai=None; ais=None
        if tq.get('score_pct',0)>=60 and settings.OPENAI_API_KEY:
            ctx={'company':name,'symbol':symbol,'tick':tick,'technical':tq,'raw_indicators':tech.get('indicators'),'market_regime':regime,'sector':sector,'derivatives':derivative,'liquidity':liq2,'evidence':evidence,'levels':levels,'deterministic_skeptic':skeptic}
            ai=await deep_ai_analysis(ctx,False)
            if ai.get('status'): ais=await deep_ai_analysis({**ctx,'candidate_ai_analysis':ai.get('analysis')},True)
        if ais and str((ais.get('analysis') or {}).get('status','')).upper() in ('INVALIDATED','REJECT'):
            skeptic={**skeptic,'status':'INVALIDATED','thesis_survives':False,'risks':skeptic.get('risks',[])+['AI adversarial skeptic rejected the thesis.']}
        cap_ctx={**tierpol, 'evidence_floor_pass': (tierpol.get('min_evidence') == 'LOW' or (evidence.get('verification') or {}).get('evidence_confidence') in ('HIGH','MEDIUM')) and len(manipulation)==0}
        score=score_setup(technical=tq,evidence=evidence,tick={**tick,'data_status':'LIVE'},regime=regime,levels=levels,sector=sector,derivatives=derivative,liquidity=liq2,skeptic=skeptic,cap_context=cap_ctx)
        status=score['status']
        reasons=(evidence.get('reasons',[])[:2]+tq.get('reasons',[])[:3])[:5]
        main_risk=(skeptic.get('risks') or ['No additional deterministic skeptic risk detected.'])[0]
        return {'symbol':symbol,'name':name,'token':tick['token'],'price':tick.get('ltp'),'change_pct':round(((float(tick['ltp'])-float(tick['close']))/float(tick['close'])*100),3),'traded_value_inr':liq2.get('traded_value_inr'),'relative_volume20':tq.get('relative_volume20'),'rsi14':tq.get('rsi14'),'adx14':tq.get('adx14'),'vwap':tq.get('vwap'),'technical_score_pct':tq.get('score_pct'),'direction':tq.get('direction'),'relative_strength_vs_nifty':tq.get('relative_strength_vs_nifty'),'sector':sector,'cap_tier':tier,'cap_policy':tierpol,'peer_strength':peer_relative_strength(symbol,{normalise_symbol(str((v.get('instrument') or {}).get('symbol',''))):v for v in latest.values() if v.get('instrument')}),'derivatives':derivative,'liquidity':liq2,'manipulation_flags':manipulation,'catalyst':evidence.get('catalyst'),'verification':evidence.get('verification',{}).get('verification'),'three_source_status':evidence.get('verification',{}).get('three_source_status'),'evidence_confidence':evidence.get('verification',{}).get('evidence_confidence'),'evidence_reasons':evidence.get('reasons',[]),'contradictions':evidence.get('contradictions',[]),'levels':levels,'setup_score':score.get('score'),'score_components':score.get('components'),'mandatory_gates':score.get('mandatory_gates'),'all_mandatory_pass':score.get('all_mandatory_pass'),'status':status,'reasons':reasons,'main_risk':main_risk,'skeptic':skeptic,'ai_analysis':(ai or {}).get('analysis'),'ai_skeptic':(ais or {}).get('analysis'),'news':news_payload.get('data',[])[:8],'timestamps':{'analysis_time_ms':scan_started,'market_data_received_ms':tick.get('received_timestamp_ms'),'market_exchange_time_ms':tick.get('exchange_timestamp_ms')}}

    results=await asyncio.gather(*(one_candidate(c) for c in candidates))
    min_score=float(body.get('min_score',55) or 55)
    if math.isfinite(min_score):
        results=[x for x in results if float(x.get('setup_score') or 0) >= max(0,min(100,min_score)) or x.get('status')=='TRADE-READY']
    results.sort(key=lambda x:(1 if x.get('status')=='TRADE-READY' else 0,x.get('setup_score') or 0,1 if x.get('evidence_confidence')=='HIGH' else 0),reverse=True)
    qualified=[x for x in results if x.get('status')=='TRADE-READY']
    if settings.EAGLE_ALLOW_PUSH_NOTIFICATIONS:
        for q in qualified[:5]:
            ev=notification_registry.emit_once('NEW_SETUP',q.get('symbol',''),'Potential setup detected',f"{q.get('symbol','')} passed current mandatory gates.",str(q.get('setup_score') or ''))
            if ev: await broadcast({'type':'notification','data':ev})
    return {'status':True,'status_code':'QUALIFIED_SETUP' if qualified else 'NO_QUALIFIED_SETUP','message':'Qualified setup(s) passed all mandatory gates.' if qualified else 'NO QUALIFIED SETUP — no candidate passed every mandatory condition.','shortlist':results,'qualified_count':len(qualified),'candidate_count':len(results),'market_regime':regime,'session':session_phase(),'scan_time_ms':scan_started,'analysis_time':analysis_timestamp_payload(),'gate_state':{'data_freshness':'PASS','technical':'PASS','liquidity':'PASS','catalyst':'RUN','three_source_verification':'RUN','skeptic':'RUN','decision':'QUALIFIED_SETUP' if qualified else 'NO_QUALIFIED_SETUP'}}


@app.get('/api/market/context')
async def market_context():
    market = market_regime(latest, now_ms(), settings.STALE_AFTER_MS)
    market['macro'] = await fetch_context()
    return {'market': market, 'session': session_phase(), 'as_of': analysis_timestamp_payload()}

@app.get('/api/spec/coverage')
async def spec_coverage():
    runtime={
        'nifty_direction': ((market_regime(latest,now_ms(),settings.STALE_AFTER_MS).get('indices') or {}).get('NIFTY 50') or {}).get('change_pct'),
        'banknifty_direction': ((market_regime(latest,now_ms(),settings.STALE_AFTER_MS).get('indices') or {}).get('BANK NIFTY') or {}).get('change_pct'),
        'india_vix': ((market_regime(latest,now_ms(),settings.STALE_AFTER_MS).get('indices') or {}).get('INDIA VIX') or {}).get('ltp'),
        'data_freshness': now_ms(),
        'risk_reward': 'engine', 'invalidation': 'engine', 'catalyst_strength':'engine', 'three_source_verification':'engine', 'skeptic_status':'engine'
    }
    return {'status':True,'prompt_parameters':feature_coverage(runtime)}

@app.get('/api/features/context')
async def features_context(symbol: str = ''):
    symbol = normalise_symbol(symbol)
    t = next((v for k,v in latest.items() if str(v.get('exchange_type','1'))=='1' and normalise_symbol(str((v.get('instrument') or {}).get('symbol',''))) == symbol), None)
    tier = cap_tier(symbol, (t or {}).get('ltp'))
    peers = peer_relative_strength(symbol, {normalise_symbol(str((v.get('instrument') or {}).get('symbol',''))):v for v in latest.values() if v.get('instrument')}) if symbol else {'available':False,'reason':'SYMBOL_REQUIRED','peers':[]}
    return {'status':True,'symbol':symbol,'cap_tier':tier,'cap_policy':tier_policy(tier),'peer_strength':peers,'macro':macro_payload(),'fundamentals':fundamental_payload(symbol) if symbol else {'available':False},'delivery':delivery_payload(symbol) if symbol else {'available':False}}

@app.post('/api/timeframes')
async def timeframes_endpoint(body: dict):
    candles = body.get('one_minute') or []
    daily = body.get('daily') or []
    if not isinstance(candles,list): return {'status':False,'message':'one_minute must be a candle list.','errorcode':'EE_BAD_REQUEST'}
    tfs=timeframe_set(candles,daily)
    return {'status':True,'timeframes':tfs,'counts':{k:len(v) for k,v in tfs.items()}}

@app.get('/api/fundamentals')
async def fundamentals(symbol: str):
    return {'status':True, **fundamental_payload(normalise_symbol(symbol))}

@app.get('/api/delivery')
async def delivery(symbol: str):
    return {'status':True, **delivery_payload(normalise_symbol(symbol))}

@app.post('/api/backtest')
async def backtest_endpoint(body: dict):
    symbol=normalise_symbol(str(body.get('symbol') or ''))
    candles=body.get('candles') or []
    if not symbol or not isinstance(candles,list) or len(candles)<80:
        return {'status':False,'message':'At least 80 valid candles are required for the replay engine.','errorcode':'EE_BACKTEST_DATA'}
    return replay(symbol,candles,min(int(body.get('max_bars',settings.EAGLE_BACKTEST_MAX_BARS)),settings.EAGLE_BACKTEST_MAX_BARS))

@app.post('/api/position-size')
async def position_size(body: dict):
    try:
        capital=float(body.get('capital_inr')); risk_pct=float(body.get('risk_pct')); entry=float(body.get('entry')); stop=float(body.get('stop'))
        if not all(math.isfinite(x) for x in (capital,risk_pct,entry,stop)) or capital<=0 or risk_pct<=0 or entry<=0 or stop<=0:
            raise ValueError
        risk_amount=capital*risk_pct/100; risk_per_share=abs(entry-stop)
        qty=int(risk_amount//risk_per_share) if risk_per_share>0 else 0
        return {'status':True,'risk_amount_inr':round(risk_amount,2),'risk_per_share':round(risk_per_share,4),'max_quantity':max(0,qty),'notional_inr':round(max(0,qty)*entry,2)}
    except Exception:
        return {'status':False,'message':'Invalid position-size inputs.','errorcode':'EE_POSITION_SIZE'}

@app.get('/api/notifications')
async def notifications():
    return {'status':True,'enabled':settings.EAGLE_ALLOW_PUSH_NOTIFICATIONS,'data':notification_registry.recent()}


@app.post('/api/derivatives')
async def derivatives_endpoint(body: dict):
    company=str(body.get('company') or '')
    symbol=normalise_symbol(str(body.get('symbol') or company))
    try: await ensure_instruments()
    except Exception: return {'status':False,'message':'INSTRUMENT DATA UNAVAILABLE','errorcode':'EE_INSTRUMENTS'}
    spot=0.0
    key=None
    for k,t in latest.items():
        if int(t.get('exchange_type',1)) == 1 and (t.get('instrument') or {}).get('symbol','').upper().replace('-EQ','') == symbol:
            key=k; spot=float(t.get('ltp') or 0); break
    selected=select_contracts(instruments,symbol,spot)
    if not selected.get('available'):
        return {'status':False,'available':False,'symbol':symbol,'selected':selected,'message':selected.get('reason','F&O UNAVAILABLE')}
    quote_tokens=[str(x.get('token')) for x in (selected.get('futures') or []) + (selected.get('options') or []) if x.get('token')]
    # Use live WebSocket where available, with FULL quote as a validation snapshot.
    if quote_tokens and stream_configured():
        await subscribe({'tokens':quote_tokens,'exchange_type':2})
    if not api_configured():
        return {'status':True,'available':False,'applicable':True,'selected':selected,'message':'F&O contracts identified but authenticated quote data is unavailable.'}
    qr=await quote({'tokens':quote_tokens,'exchange':'NFO','mode':'FULL'})
    qs=parse_quotes(qr)
    snap=derivative_snapshot({'spot':spot,**selected},qs,{})
    snap['selected']=selected
    return {'status':True,'available':snap.get('available',False),'applicable':True,'symbol':symbol,'snapshot':snap,'quote_timestamp_ms':now_ms()}


@app.post('/api/decision')
async def decision_endpoint(body: dict):
    symbol=normalise_symbol(str(body.get('symbol') or ''))
    row=next((x for x in (body.get('scan_results') or []) if normalise_symbol(str(x.get('symbol') or ''))==symbol),None)
    if not row: return {'status':False,'message':'Run a fresh market scan first.'}
    return {'status':True,'decision':row,'timestamp':analysis_timestamp_payload()}


@app.post('/api/paper/trade')
async def paper_trade(body: dict):
    global paper_open_symbols
    result = await asyncio.to_thread(log_trade, body)
    if result.get('status') and body.get('symbol'):
        paper_open_symbols.add(normalise_symbol(str(body.get('symbol'))))
    return result


@app.get('/api/paper/trades')
async def paper_trades(limit:int=100):
    return {'status':True,'data':list_trades(limit)}


@app.get('/api/paper/metrics')
async def paper_stats():
    return {'status':True,'metrics':paper_metrics()}

@app.get('/api/paper/analytics')
async def paper_analytics_endpoint(group_by: str = 'market_regime'):
    return {'status':True, **paper_analytics(group_by)}


@app.post('/api/paper/revalue')
async def paper_revalue(body: dict):
    if not settings.EAGLE_MANUAL_REVALUE:
        return {'status':False,'message':'Manual paper revalue is disabled. Live Angel One ticks drive paper tracking.', 'errorcode':'EE_MANUAL_REVALUE_DISABLED'}
    symbol=normalise_symbol(str(body.get('symbol') or ''))
    try:
        price=float(body.get('price') or 0)
    except (TypeError,ValueError):
        price=0
    if not symbol or price <= 0: return {'status':False,'message':'Valid symbol and price are required.'}
    return {'status':True,'updated_ids':update_from_price(symbol,price,source='MANUAL_TEST',market_time_ms=now_ms())}


@app.websocket('/ws')
async def ws_endpoint(ws: WebSocket):
    if settings.EAGLE_REQUIRE_AUTH:
        rec = security_sessions.validate(ws.cookies.get(settings.EAGLE_COOKIE_NAME))
        if not rec:
            await ws.close(code=1008, reason='authentication required')
            return
    origin = ws.headers.get('origin')
    if origin:
        if _allowed_origins:
            origin_ok = origin in _allowed_origins
        else:
            origin_ok = origin == f'{ws.url.scheme}://{ws.url.netloc}'
        if not origin_ok:
            await ws.close(code=1008, reason='origin rejected')
            return
    if len(clients) >= settings.EAGLE_MAX_CLIENTS:
        await ws.close(code=1013, reason='too many clients')
        return
    await ws.accept()
    clients.add(ws)
    try:
        await ws.send_json({'type': 'status', 'status': 'LIVE' if latest else ('CONFIGURED' if stream_configured() else 'UNAVAILABLE'), 'at': now_ms(), 'read_only': True})
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        clients.discard(ws)
    except Exception:
        clients.discard(ws)
