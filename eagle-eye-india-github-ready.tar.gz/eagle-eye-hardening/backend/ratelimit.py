from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass


@dataclass
class Bucket:
    tokens: float
    updated: float


class AsyncTokenBucket:
    """Single-process token bucket for provider/API pacing."""

    def __init__(self, rate_per_sec: float, burst: int):
        self.rate = max(0.01, float(rate_per_sec))
        self.burst = max(1, int(burst))
        self._bucket = Bucket(float(self.burst), time.monotonic())
        self._lock = asyncio.Lock()

    async def acquire(self) -> None:
        while True:
            async with self._lock:
                now = time.monotonic()
                elapsed = max(0.0, now - self._bucket.updated)
                self._bucket.tokens = min(self.burst, self._bucket.tokens + elapsed * self.rate)
                self._bucket.updated = now
                if self._bucket.tokens >= 1.0:
                    self._bucket.tokens -= 1.0
                    return
                wait_for = (1.0 - self._bucket.tokens) / self.rate
            await asyncio.sleep(wait_for)
