from __future__ import annotations
import json, os, math
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
try:
    from zoneinfo import ZoneInfo
except Exception:
    ZoneInfo = None
from typing import Iterable

# Feature adapters intentionally return UNAVAILABLE when their configured provider is absent.
# Eagle Eye never turns a missing provider into an invented value.

CAP_ORDER = {"LARGE": 1, "MID": 2, "SMALL": 3, "MICRO": 4, "PENNY": 5, "SME": 6, "UNKNOWN": 99}

def safe_num(x):
    try:
        v=float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None

def _load_obj_env(env_name: str):
    raw=os.getenv(env_name,'').strip()
    if not raw: return {}
    try:
        return json.loads(raw)
    except Exception:
        return {}

def _mapping(env_name: str) -> dict:
    obj=_load_obj_env(env_name)
    if not isinstance(obj,dict): return {}
    return {str(k).upper(): str(v).upper() for k,v in obj.items()}

def cap_tier(symbol: str, price: float|None=None, metadata: dict|None=None) -> str:
    sym=(symbol or '').upper().replace('-EQ','')
    m={str(k).upper(): str(v).upper() for k,v in (metadata or {}).items()}
    raw=m.get(sym) or _mapping('EAGLE_CAP_TIER_MAP_JSON').get(sym)
    if raw in CAP_ORDER: return raw
    # Never infer capitalization from price. Unknown remains unknown.
    return 'UNKNOWN'

def tier_policy(tier: str) -> dict:
    t=(tier or 'UNKNOWN').upper()
    policies={
        'LARGE': {'min_traded_value': 50_000_000, 'min_relative_volume': 1.0, 'max_spread_pct': 0.35, 'min_evidence': 'MEDIUM'},
        'MID': {'min_traded_value': 40_000_000, 'min_relative_volume': 1.1, 'max_spread_pct': 0.45, 'min_evidence': 'MEDIUM'},
        'SMALL': {'min_traded_value': 30_000_000, 'min_relative_volume': 1.3, 'max_spread_pct': 0.60, 'min_evidence': 'HIGH'},
        'MICRO': {'min_traded_value': 20_000_000, 'min_relative_volume': 1.5, 'max_spread_pct': 0.75, 'min_evidence': 'HIGH'},
        'PENNY': {'min_traded_value': 15_000_000, 'min_relative_volume': 1.8, 'max_spread_pct': 0.80, 'min_evidence': 'HIGH'},
        'SME': {'min_traded_value': 20_000_000, 'min_relative_volume': 1.8, 'max_spread_pct': 0.80, 'min_evidence': 'HIGH'},
        'UNKNOWN': {'min_traded_value': 50_000_000, 'min_relative_volume': 1.5, 'max_spread_pct': 0.50, 'min_evidence': 'HIGH'},
    }
    return policies.get(t, policies['UNKNOWN'])

def peer_map(symbol: str) -> list[str]:
    data=_mapping('EAGLE_PEER_MAP_JSON')
    raw=data.get((symbol or '').upper())
    return [x.strip().upper() for x in raw.split('|') if x.strip()] if raw else []

def peer_relative_strength(symbol: str, tick_by_symbol: dict[str,dict]) -> dict:
    peers=peer_map(symbol)
    if not peers: return {'available':False,'reason':'PEER_MAP_UNAVAILABLE','peers':[]}
    base=tick_by_symbol.get(symbol.upper())
    if not base: return {'available':False,'reason':'STOCK_TICK_UNAVAILABLE','peers':peers}
    bc=safe_num(base.get('close')); bp=safe_num(base.get('ltp'))
    if not bc or bp is None: return {'available':False,'reason':'BASE_PRICE_UNAVAILABLE','peers':peers}
    bm=(bp-bc)/bc*100
    rows=[]
    for p in peers:
        t=tick_by_symbol.get(p)
        if not t: continue
        c=safe_num(t.get('close')); l=safe_num(t.get('ltp'))
        if not c or l is None: continue
        rows.append({'symbol':p,'change_pct':(l-c)/c*100})
    if not rows: return {'available':False,'reason':'PEER_TICKS_UNAVAILABLE','peers':peers}
    avg=sum(x['change_pct'] for x in rows)/len(rows)
    return {'available':True,'stock_change_pct':round(bm,3),'peer_avg_change_pct':round(avg,3),'relative_strength_vs_peers':round(bm-avg,3),'peers':rows}

def resample_candles(candles: list[list], minutes: int) -> list[list]:
    if not candles or minutes <= 1: return candles
    good=[]
    for c in candles:
        if len(c)<6: continue
        try:
            ts=int(float(c[0])); vals=[float(c[i]) for i in range(1,6)]
            if not all(math.isfinite(v) for v in vals): continue
            good.append([ts,*vals])
        except Exception: continue
    good.sort(key=lambda x:x[0])
    # Infer timestamp unit from the observed candle spacing; this also supports test fixtures that start at 0 ms.
    unit='ms'
    if len(good)>=3:
        diffs=[good[i][0]-good[i-1][0] for i in range(1,min(len(good),20)) if good[i][0]>good[i-1][0]]
        if diffs and sum(diffs)/len(diffs)<1000: unit='s'
    buckets={}
    for c in good:
        ts=c[0]*(1000 if unit=='s' else 1)
        bucket=(ts//(minutes*60_000))*(minutes*60_000)
        o,h,l,cl,v=c[1:6]
        if bucket not in buckets: buckets[bucket]=[bucket,o,h,l,cl,v]
        else:
            b=buckets[bucket]; b[2]=max(b[2],h); b[3]=min(b[3],l); b[4]=cl; b[5]+=v
    return [buckets[k] for k in sorted(buckets)]

def _to_ms(ts: int) -> int:
    return ts * 1000 if abs(ts) < 10_000_000_000 else ts

def weekly_from_daily(candles: list[list]) -> list[list]:
    """Calendar-week OHLCV aggregation, Monday-start, rather than a fixed 5-day epoch bucket."""
    good=[]
    for c in candles or []:
        if len(c) < 6: continue
        try:
            ts=_to_ms(int(float(c[0])))
            vals=[float(c[i]) for i in range(1,6)]
            if not all(math.isfinite(v) for v in vals): continue
            good.append([ts,*vals])
        except Exception:
            continue
    good.sort(key=lambda x:x[0])
    if not good: return []
    tz=ZoneInfo('Asia/Kolkata') if ZoneInfo else timezone.utc
    buckets={}
    for c in good:
        dt=datetime.fromtimestamp(c[0]/1000, tz=tz)
        monday=(dt - timedelta(days=dt.weekday())).date()
        key=monday.isoformat()
        o,h,l,cl,v=c[1:6]
        if key not in buckets: buckets[key]=[c[0],o,h,l,cl,v]
        else:
            b=buckets[key]; b[2]=max(b[2],h); b[3]=min(b[3],l); b[4]=cl; b[5]+=v
    return [buckets[k] for k in sorted(buckets)]

def opening_range(candles: list[list], minutes: int = 15) -> dict:
    """Use the observed candle spacing to avoid accidentally taking 15 *bars* instead of 15 minutes."""
    good=[]
    for c in candles or []:
        if len(c)>=6:
            try: good.append([_to_ms(int(float(c[0]))), *[float(c[i]) for i in range(1,6)]])
            except Exception: pass
    good.sort(key=lambda x:x[0])
    if not good: return {'available':False,'reason':'NO_CANDLES'}
    deltas=[good[i][0]-good[i-1][0] for i in range(1,min(len(good),20)) if good[i][0]>good[i-1][0]]
    delta=max(1, int(sum(deltas)/len(deltas))) if deltas else 60_000
    bars=max(1, int(math.ceil(minutes*60_000/delta)))
    rows=good[:bars]
    return {'available':bool(rows),'minutes':minutes,'bars_used':len(rows),'high':max(r[2] for r in rows),'low':min(r[3] for r in rows),'from_timestamp_ms':rows[0][0],'to_timestamp_ms':rows[-1][0]}

def timeframe_set(one_minute: list[list], daily: list[list]|None=None) -> dict[str,list[list]]:
    daily = daily or []
    return {'1m':one_minute,'3m':resample_candles(one_minute,3),'5m':resample_candles(one_minute,5),'15m':resample_candles(one_minute,15),'30m':resample_candles(one_minute,30),'1h':resample_candles(one_minute,60),'1d':daily,'1w':weekly_from_daily(daily) if daily else []}

def macro_payload() -> dict:
    # Optional JSON snapshot endpoint. Server fetch is intentionally controlled/configured.
    # Values absent from provider remain unavailable.
    raw=os.getenv('EAGLE_MACRO_SNAPSHOT_JSON','').strip()
    if not raw: return {'available':False,'status':'UNAVAILABLE','items':{}}
    try:
        obj=json.loads(raw)
        return {'available':True,'status':'AVAILABLE','items':obj if isinstance(obj,dict) else {}}
    except Exception:
        return {'available':False,'status':'UNAVAILABLE','items':{},'reason':'INVALID_MACRO_CONFIG'}

def fundamental_payload(symbol: str) -> dict:
    obj=_load_obj_env('EAGLE_FUNDAMENTALS_JSON')
    sym=(symbol or '').upper()
    fields=obj.get(sym) if isinstance(obj,dict) else None
    return {'available':isinstance(fields,dict),'status':'AVAILABLE' if isinstance(fields,dict) else 'UNAVAILABLE','symbol':symbol,'fields':fields if isinstance(fields,dict) else {},'reason':None if isinstance(fields,dict) else 'FUNDAMENTALS_PROVIDER_NOT_CONFIGURED'}

def delivery_payload(symbol: str) -> dict:
    obj=_load_obj_env('EAGLE_DELIVERY_JSON')
    sym=(symbol or '').upper()
    value=obj.get(sym) if isinstance(obj,dict) else None
    v=safe_num(value)
    return {'available':v is not None,'status':'AVAILABLE' if v is not None else 'UNAVAILABLE','symbol':symbol,'delivery_pct':v,'reason':None if v is not None else 'DELIVERY_PROVIDER_NOT_CONFIGURED'}

def evidence_adjustment_for_tier(tier: str, evidence_confidence: str, manipulation_flags: list[str]) -> dict:
    p=tier_policy(tier); conf=(evidence_confidence or 'LOW').upper()
    required=p['min_evidence']
    rank={'LOW':0,'MEDIUM':1,'HIGH':2}
    passes=rank.get(conf,0)>=rank.get(required,2) and len(manipulation_flags)==0
    return {'policy':p,'evidence_floor_pass':passes,'reason':None if passes else 'CAP_TIER_EVIDENCE_FLOOR_NOT_MET'}
