from __future__ import annotations

# Traceable implementation inventory. A parameter is "AVAILABLE" when an input
# exists; "UNAVAILABLE" is a valid safe state when no permitted provider supplies it.
PARAMETERS = [
 'nifty_direction','banknifty_direction','midcap_direction','smallcap_direction','india_vix','advancers','decliners','fii_activity','dii_activity','usd_inr','brent_crude','gold','us_context','asia_context',
 'open','previous_close','current_price','high','low','gap_pct','day_range','vwap','distance_from_vwap','previous_day_high','previous_day_low','opening_range',
 'higher_highs','higher_lows','lower_highs','lower_lows','trend_transition','consolidation','breakout','breakdown','failed_breakout','failed_breakdown',
 'doji','hammer','shooting_star','engulfing','pin_bar','rejection','momentum_candle','opening_candle','reversal_structure',
 'ema_9','ema_20','ema_50','ema_200','sma_20','sma_50','sma_200','rsi','macd','adx','atr','bollinger_bands','obv','relative_volume','volume_acceleration','breakout_volume','pullback_volume','rejection_volume','delivery_pct','traded_value','volume_profile',
 'relative_strength_nifty','relative_strength_sector','relative_strength_peers','sector_momentum','sector_news','commodity_sensitivity','government_regulatory_exposure',
 'futures_price','futures_basis','open_interest','change_in_oi','call_oi','put_oi','oi_additions','short_covering','long_buildup','long_unwinding','short_buildup','major_option_strikes','iv','option_volume',
 'bid_ask_spread','free_float','current_volume','circuit_limits','exit_liquidity','trading_frequency','sudden_price_spike','price_news_mismatch','social_promo_risk','operator_risk',
 'revenue_growth','ebitda_growth','pat_growth','margins','eps','pe','ev_ebitda','debt','cash','roe','roce','promoter_holding','promoter_pledge','institutional_ownership','recent_dilution',
 'catalyst_strength','catalyst_credibility','catalyst_materiality','source_quality','three_source_verification','news_price_relationship','data_freshness','contradiction_level','skeptic_status','risk_reward','invalidation','paper_trade_outcome'
]

def coverage(runtime: dict|None=None) -> dict:
    runtime=runtime or {}
    rows=[]
    for p in PARAMETERS:
        val=runtime.get(p)
        rows.append({'parameter':p,'status':'AVAILABLE' if val is not None else 'UNAVAILABLE','value_present':val is not None})
    return {'total':len(rows),'available':sum(x['value_present'] for x in rows),'rows':rows}
