from __future__ import annotations

import asyncio
import hashlib
import re
import time
import xml.etree.ElementTree as ET
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import Iterable
from urllib.parse import quote_plus, urlparse

import httpx

GDELT_DOC = 'https://api.gdeltproject.org/api/v2/doc/doc'
DEFAULT_HEADERS = {'User-Agent': 'EagleEyeIndia/0.4 (+https://localhost)'}

PRIMARY_HOSTS = {
    'nseindia.com', 'bseindia.com', 'sebi.gov.in', 'rbi.org.in', 'mca.gov.in',
    'pib.gov.in', 'finmin.gov.in', 'dea.gov.in', 'meity.gov.in', 'gov.in'
}
WIRE_AGENCIES = ('reuters', 'press trust of india', 'pti', 'ani', 'associated press', 'dow jones', 'bloomberg')
CATALYST_RULES = [
    ('Earnings', ('results', 'earnings', 'quarterly', 'profit', 'loss', 'revenue', 'ebitda', 'eps', 'guidance')),
    ('Order win', ('order win', 'order book', 'awarded contract', 'contract worth', 'purchase order', 'receives order', 'received order')),
    ('Order cancellation', ('order cancelled', 'contract cancelled', 'termination of contract', 'cancelled order')),
    ('Acquisition', ('acquire', 'acquisition', 'acquires', 'takeover')),
    ('Merger', ('merger', 'amalgamation', 'scheme of arrangement')),
    ('Fundraising', ('fund raise', 'fundraising', 'qualified institutional placement', 'qip', 'preferential issue', 'rights issue')),
    ('Debt reduction', ('debt reduction', 'debt repayment', 'deleveraging', 'loan repayment')),
    ('Buyback', ('buyback', 'buy back', 'repurchase')),
    ('Dividend', ('dividend', 'interim dividend', 'final dividend')),
    ('Promoter transaction', ('promoter buy', 'promoter sell', 'promoter holding', 'promoter stake')),
    ('Regulatory approval', ('approval', 'approved', 'clearance', 'regulatory nod', 'authorised')),
    ('Regulatory action', ('show cause', 'penalty', 'fine', 'order against', 'ban', 'suspension', 'sebi action', 'rbi action')),
    ('Government contract', ('government contract', 'government order', 'ministry order', 'defence contract')),
    ('Product launch', ('launches', 'launch', 'new product', 'rolls out', 'unveils')),
    ('Capacity expansion', ('capacity expansion', 'new plant', 'capacity addition', 'capex', 'commissioning')),
    ('Management change', ('appoints', 'resigns', 'resignation', 'chief executive', 'md and ceo', 'cfo')),
    ('Legal development', ('court', 'tribunal', 'lawsuit', 'litigation', 'legal dispute', 'nclt')),
    ('Corporate governance', ('related party', 'auditor resignation', 'governance', 'whistleblower', 'fraud')),
    ('Rumour', ('rumour', 'rumor', 'speculation', 'unconfirmed')),
]


def _host(url: str) -> str:
    try:
        return (urlparse(url).hostname or '').lower().removeprefix('www.')
    except Exception:
        return ''


def source_type(url: str) -> str:
    host = _host(url)
    if any(host == h or host.endswith('.' + h) for h in PRIMARY_HOSTS):
        return 'PRIMARY'
    return 'SECONDARY'


def origin_agency(text: str) -> str | None:
    low = (text or '').lower()
    for agency in WIRE_AGENCIES:
        if agency in low:
            return agency.upper()
    return None


def _parse_dt(value: str | None) -> int | None:
    if not value:
        return None
    try:
        dt = parsedate_to_datetime(value)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return int(dt.timestamp() * 1000)
    except Exception:
        pass
    try:
        raw = value.strip()
        if re.fullmatch(r'\d{8}T\d{6}Z', raw):
            dt = datetime.strptime(raw, '%Y%m%dT%H%M%SZ').replace(tzinfo=timezone.utc)
            return int(dt.timestamp() * 1000)
        s = raw.replace('Z', '+00:00')
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return int(dt.timestamp() * 1000)
    except Exception:
        return None


def _clean_text(text: str) -> str:
    text = re.sub(r'<[^>]+>', ' ', text or '')
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def _title_key(title: str) -> str:
    s = (title or '').lower()
    s = re.sub(r'\[[^\]]+\]', ' ', s)
    s = re.sub(r'\b(reuters|pti|ani|bloomberg|press trust of india)\b', ' ', s)
    s = re.sub(r'[^a-z0-9 ]+', ' ', s)
    stop = {'the', 'a', 'an', 'and', 'to', 'of', 'in', 'on', 'for', 'with', 'from', 'by', 'is', 'as', 'at'}
    return ' '.join(x for x in s.split() if x not in stop)[:180]


def _jaccard(a: str, b: str) -> float:
    sa, sb = set(a.split()), set(b.split())
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


@dataclass
class NewsItem:
    title: str
    url: str
    domain: str
    source_name: str
    source_type: str
    published_at_ms: int | None
    snippet: str = ''
    origin_agency: str | None = None
    provider: str = ''
    cluster_id: str = ''

    def asdict(self):
        return asdict(self)


def classify_catalyst(text: str) -> str:
    low = (text or '').lower()
    for label, terms in CATALYST_RULES:
        if any(t in low for t in terms):
            return label
    return 'Other'


def materiality_flags(text: str) -> dict:
    low = (text or '').lower()
    return {
        'financial_quantification_present': bool(re.search(r'(₹|rs\.?|inr|crore|cr\b|million|billion|%)', low)),
        'guidance_or_outlook': any(x in low for x in ('guidance', 'outlook', 'forecast', 'expects', 'target')),
        'balance_sheet_signal': any(x in low for x in ('debt', 'cash', 'fundraise', 'dilution', 'equity issue')),
        'governance_signal': any(x in low for x in ('fraud', 'auditor', 'whistleblower', 'related party', 'governance')),
        'regulatory_signal': any(x in low for x in ('sebi', 'rbi', 'regulatory', 'approval', 'penalty', 'ban')),
        'price_implication_unquantified': True,
    }


def _cluster(items: list[NewsItem]) -> list[NewsItem]:
    # Cluster by wire-origin or strong title similarity. This deliberately errs toward under-counting independence.
    clusters: list[list[NewsItem]] = []
    for item in sorted(items, key=lambda x: x.published_at_ms or 0, reverse=True):
        ikey = _title_key(item.title)
        placed = False
        for group in clusters:
            head = group[0]
            if item.origin_agency and head.origin_agency and item.origin_agency == head.origin_agency:
                group.append(item); placed = True; break
            if _jaccard(ikey, _title_key(head.title)) >= 0.72:
                group.append(item); placed = True; break
        if not placed:
            clusters.append([item])
    for group in clusters:
        seed = '|'.join(sorted({x.domain for x in group})) + '|' + _title_key(group[0].title)
        cid = hashlib.sha1(seed.encode('utf-8')).hexdigest()[:12]
        for x in group:
            x.cluster_id = cid
    return items


async def fetch_gdelt(query: str, maxrecords: int = 30, timespan: str = '24h') -> list[NewsItem]:
    params = {'query': query, 'mode': 'ArtList', 'maxrecords': max(1, min(maxrecords, 100)), 'format': 'json', 'sort': 'DateDesc', 'timespan': timespan}
    async with httpx.AsyncClient(timeout=15, headers=DEFAULT_HEADERS, follow_redirects=True) as client:
        r = await client.get(GDELT_DOC, params=params)
        r.raise_for_status()
        data = r.json()
    out: list[NewsItem] = []
    for a in data.get('articles') or []:
        url = a.get('url') or a.get('url_mobile') or ''
        if not url:
            continue
        title = _clean_text(a.get('title') or '')
        snippet = _clean_text(a.get('seendate') or '')
        domain = (a.get('domain') or _host(url)).lower()
        text = title + ' ' + snippet
        out.append(NewsItem(title, url, domain, domain, source_type(url), _parse_dt(a.get('seendate')), snippet, origin_agency(text), 'GDELT'))
    return _cluster(out)


async def fetch_rss(url: str, maxitems: int = 30) -> list[NewsItem]:
    async with httpx.AsyncClient(timeout=15, headers=DEFAULT_HEADERS, follow_redirects=True) as client:
        r = await client.get(url)
        r.raise_for_status()
        raw = r.content
    root = ET.fromstring(raw)
    out: list[NewsItem] = []
    # RSS 2.0 and common Atom variants.
    for node in list(root.findall('.//item'))[:maxitems]:
        title = _clean_text(node.findtext('title') or '')
        link = _clean_text(node.findtext('link') or '')
        pub = node.findtext('pubDate') or node.findtext('{http://purl.org/dc/elements/1.1/}date')
        desc = _clean_text(node.findtext('description') or '')
        if not link:
            guid = node.findtext('guid') or ''
            link = guid if guid.startswith('http') else ''
        if title and link:
            domain = _host(link)
            out.append(NewsItem(title, link, domain, domain, source_type(link), _parse_dt(pub), desc[:500], origin_agency(title + ' ' + desc), 'RSS'))
    if not out:
        ns = {'a': 'http://www.w3.org/2005/Atom'}
        for node in root.findall('.//a:entry', ns)[:maxitems]:
            title = _clean_text(node.findtext('a:title', default='', namespaces=ns))
            link_el = node.find('a:link', ns)
            link = (link_el.attrib.get('href') if link_el is not None else '') or ''
            pub = node.findtext('a:published', default='', namespaces=ns) or node.findtext('a:updated', default='', namespaces=ns)
            desc = _clean_text(node.findtext('a:summary', default='', namespaces=ns))
            if title and link:
                domain = _host(link)
                out.append(NewsItem(title, link, domain, domain, source_type(link), _parse_dt(pub), desc[:500], origin_agency(title + ' ' + desc), 'RSS'))
    return _cluster(out)


async def search_news(company: str, symbol: str, rss_urls: Iterable[str] = (), maxrecords: int = 25) -> dict:
    # Two GDELT passes keep broad discovery inexpensive; RSS is optional and configured server-side.
    query = f'"{company}" OR {symbol}' if company and symbol else (f'"{company}"' if company else symbol)
    queries = [query]
    tasks = [fetch_gdelt(q, maxrecords=maxrecords, timespan='24h') for q in queries]
    for url in rss_urls:
        if url.strip():
            tasks.append(fetch_rss(url.strip(), maxitems=maxrecords))
    results = await asyncio.gather(*tasks, return_exceptions=True)
    items: list[NewsItem] = []
    errors: list[str] = []
    for r in results:
        if isinstance(r, Exception):
            errors.append(str(r))
        else:
            items.extend(r)
    # Stable de-duplication by URL, then conservative clustering.
    seen_urls: set[str] = set()
    uniq: list[NewsItem] = []
    for x in sorted(items, key=lambda z: z.published_at_ms or 0, reverse=True):
        u = x.url.rstrip('/').lower()
        if u in seen_urls:
            continue
        seen_urls.add(u); uniq.append(x)
    uniq = _cluster(uniq)
    clusters: dict[str, list[NewsItem]] = {}
    for x in uniq:
        clusters.setdefault(x.cluster_id, []).append(x)
    scored_clusters = []
    for cid, group in clusters.items():
        domains = sorted({x.domain for x in group if x.domain})
        primaries = sorted({x.domain for x in group if x.source_type == 'PRIMARY'})
        freshness = max((x.published_at_ms or 0 for x in group), default=0)
        scored_clusters.append({
            'cluster_id': cid,
            'catalyst': classify_catalyst(' '.join(x.title for x in group)),
            'article_count': len(group),
            'independent_domains': len(domains),
            'primary_domains': len(primaries),
            'latest_published_at_ms': freshness,
            'items': [x.asdict() for x in group[:8]],
            'materiality': materiality_flags(' '.join(x.title + ' ' + x.snippet for x in group)),
        })
    scored_clusters.sort(key=lambda x: (x['independent_domains'], x['latest_published_at_ms']), reverse=True)
    return {'status': True if uniq or not errors else False, 'data': [x.asdict() for x in uniq[:maxrecords]], 'clusters': scored_clusters[:10], 'errors': errors, 'provider': 'GDELT + configured RSS'}


def verify_cluster(cluster: dict) -> dict:
    items = cluster.get('items') or []
    domains = {x.get('domain') for x in items if x.get('domain')}
    primaries = {x.get('domain') for x in items if x.get('source_type') == 'PRIMARY'}
    agencies = {x.get('origin_agency') for x in items if x.get('origin_agency')}
    # Independent check count: publisher domains, but copied wire reports collapse when the same origin agency is explicit.
    effective_sources = len(domains)
    if agencies and len(agencies) == 1:
        non_wire_domains = {x.get('domain') for x in items if not x.get('origin_agency') and x.get('domain')}
        effective_sources = len(non_wire_domains) + 1
    verified = min(effective_sources, 3)
    if verified >= 3 and primaries:
        status = '3/3 VERIFIED'; confidence = 'HIGH'
    elif verified >= 2:
        status = '2/3 VERIFIED'; confidence = 'MEDIUM'
    elif verified == 1:
        status = '1/3 VERIFIED'; confidence = 'LOW'
    else:
        status = 'UNVERIFIED'; confidence = 'LOW'
    if verified < 3 or not primaries:
        availability = '3-SOURCE VERIFICATION UNAVAILABLE'
    else:
        availability = 'AVAILABLE'
    return {
        'verification': status,
        'evidence_confidence': confidence,
        'effective_independent_sources': effective_sources,
        'primary_source_present': bool(primaries),
        'primary_domains': sorted(primaries),
        'source_domains': sorted(domains),
        'three_source_status': availability,
    }
