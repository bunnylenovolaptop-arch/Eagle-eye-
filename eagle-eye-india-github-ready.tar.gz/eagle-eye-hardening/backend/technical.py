from __future__ import annotations
from math import sqrt
from typing import Sequence


def _vals(candles, idx):
    return [float(c[idx]) for c in candles]


def sma(values: Sequence[float], n: int):
    if len(values) < n: return None
    return sum(values[-n:]) / n


def ema(values: Sequence[float], n: int):
    if len(values) < n: return None
    k = 2 / (n + 1)
    e = sum(values[:n]) / n
    for x in values[n:]: e = x * k + e * (1 - k)
    return e


def rsi(values: Sequence[float], n: int = 14):
    if len(values) < n + 1: return None
    deltas = [values[i] - values[i-1] for i in range(1, len(values))]
    gains = [max(d, 0.0) for d in deltas]
    losses = [max(-d, 0.0) for d in deltas]
    avg_gain = sum(gains[:n]) / n
    avg_loss = sum(losses[:n]) / n
    for i in range(n, len(deltas)):
        avg_gain = ((avg_gain * (n - 1)) + gains[i]) / n
        avg_loss = ((avg_loss * (n - 1)) + losses[i]) / n
    if avg_loss == 0: return 100.0
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))


def atr(candles, n=14):
    if len(candles) < n + 1: return None
    trs=[]
    for i in range(1,len(candles)):
        h,l,pc=float(candles[i][2]),float(candles[i][3]),float(candles[i-1][4])
        trs.append(max(h-l,abs(h-pc),abs(l-pc)))
    if len(trs) < n: return None
    value=sum(trs[:n])/n
    for tr in trs[n:]: value=((value*(n-1))+tr)/n
    return value


def _ema_series(values: Sequence[float], n: int):
    if len(values) < n: return []
    k=2/(n+1); e=sum(values[:n])/n; out=[e]
    for x in values[n:]:
        e=x*k+e*(1-k); out.append(e)
    return out


def macd(values, fast=12, slow=26, signal=9):
    if len(values) < slow + signal: return None
    ef=_ema_series(values,fast); es=_ema_series(values,slow)
    # Align both EMA series by their absolute observation index.
    offset=slow-fast
    fast_aligned=ef[offset:]
    macd_series=[a-b for a,b in zip(fast_aligned,es)]
    if len(macd_series) < signal: return None
    sig_series=_ema_series(macd_series, signal)
    sig=sig_series[-1]
    return {'macd':macd_series[-1], 'signal':sig, 'histogram':macd_series[-1]-sig}


def bollinger(values,n=20,k=2):
    if len(values)<n: return None
    x=values[-n:]; m=sum(x)/n; sd=sqrt(sum((v-m)**2 for v in x)/n)
    return {'middle':m,'upper':m+k*sd,'lower':m-k*sd}


def adx(candles,n=14):
    if len(candles)<2*n+1: return None
    trs=[]; plus_dm=[]; minus_dm=[]
    for i in range(1,len(candles)):
        h,l,ph,pl,pc=float(candles[i][2]),float(candles[i][3]),float(candles[i-1][2]),float(candles[i-1][3]),float(candles[i-1][4])
        trs.append(max(h-l,abs(h-pc),abs(l-pc)))
        up=h-ph; dn=pl-l
        plus_dm.append(up if up>dn and up>0 else 0.0)
        minus_dm.append(dn if dn>up and dn>0 else 0.0)
    if len(trs)<n: return None
    tr=sum(trs[:n])/n; plus=sum(plus_dm[:n])/n; minus=sum(minus_dm[:n])/n
    dxs=[]; last_pdi=last_mdi=0.0
    for i in range(n, len(trs)):
        tr=((tr*(n-1))+trs[i])/n
        plus=((plus*(n-1))+plus_dm[i])/n
        minus=((minus*(n-1))+minus_dm[i])/n
        if tr==0: continue
        pdi=100*plus/tr; mdi=100*minus/tr
        dx=100*abs(pdi-mdi)/max(pdi+mdi,1e-12)
        dxs.append(dx); last_pdi=pdi; last_mdi=mdi
    if len(dxs)<n: return None
    adx_value=sum(dxs[:n])/n
    for dx in dxs[n:]: adx_value=((adx_value*(n-1))+dx)/n
    return {'adx':adx_value,'plus_di':last_pdi,'minus_di':last_mdi}


def session_vwap(candles):
    pv=vol=0.0
    for c in candles:
        h,l,cl,v=map(float,(c[2],c[3],c[4],c[5]))
        typical=(h+l+cl)/3
        pv += typical*v; vol += v
    return pv/vol if vol else None


def relative_volume(candles,n=20):
    if len(candles)<n+1:return None
    vols=[float(c[5]) for c in candles]
    base=sum(vols[-n-1:-1])/n
    return vols[-1]/base if base else None



def obv(candles):
    if len(candles)<2: return None
    value=0.0
    for i in range(1,len(candles)):
        pc=float(candles[i-1][4]); c=float(candles[i][4]); v=float(candles[i][5])
        if c>pc: value+=v
        elif c<pc: value-=v
    return value

def candle_patterns(candles):
    if not candles: return []
    c=candles[-1]
    o,h,l,cl=map(float,c[1:5]); rng=max(h-l,1e-12); body=abs(cl-o); upper=h-max(o,cl); lower=min(o,cl)-l
    out=[]
    if body/rng <= 0.1: out.append('DOJI')
    if lower >= 2*max(body,1e-12) and upper <= max(body,1e-12) and cl>=o: out.append('HAMMER')
    if upper >= 2*max(body,1e-12) and lower <= max(body,1e-12) and cl<=o: out.append('SHOOTING_STAR')
    if len(candles)>=2:
        p=candles[-2]; po,pc=map(float,(p[1],p[4]))
        if cl>o and pc<po and o<=pc and cl>=po: out.append('BULLISH_ENGULFING')
        if cl<o and pc>po and o>=pc and cl<=po: out.append('BEARISH_ENGULFING')
    return out

def structure(candles):
    if len(candles)<6: return {'higher_highs':None,'higher_lows':None,'lower_highs':None,'lower_lows':None,'trend_transition':'UNKNOWN','support':None,'resistance':None}
    recent=candles[-6:]
    highs=[float(c[2]) for c in recent]; lows=[float(c[3]) for c in recent]
    hh=highs[-1]>highs[-2]; hl=lows[-1]>lows[-2]; lh=highs[-1]<highs[-2]; ll=lows[-1]<lows[-2]
    trend_transition='BULLISH' if hh and hl else 'BEARISH' if lh and ll else 'MIXED'
    body=candles[-1]
    return {'higher_highs':hh,'higher_lows':hl,'lower_highs':lh,'lower_lows':ll,'trend_transition':trend_transition,'support':min(lows[:-1]),'resistance':max(highs[:-1])}

def _timestamp_ms(ts):
    try:
        v=float(ts)
        return int(v*1000) if abs(v)<10_000_000_000 else int(v)
    except Exception:
        return None

def opening_range(candles, minutes=15):
    if not candles: return None
    raw=[]
    for c in candles[:20]:
        try: raw.append(int(float(c[0])))
        except Exception: pass
    deltas=[raw[i]-raw[i-1] for i in range(1,len(raw)) if raw[i]>raw[i-1]]
    raw_delta=max(1,int(sum(deltas)/len(deltas))) if deltas else 60_000
    # Infer units from spacing, so synthetic fixtures and real Unix timestamps both work.
    delta_ms=raw_delta*1000 if raw_delta<1000 else raw_delta
    take=max(1,min(len(candles),int((minutes*60_000 + delta_ms-1)//delta_ms)))
    rows=candles[:take]
    return {'high':max(float(c[2]) for c in rows),'low':min(float(c[3]) for c in rows),'range':max(float(c[2]) for c in rows)-min(float(c[3]) for c in rows),'minutes':minutes,'bars_used':take}

def validate_candles(candles):
    if not isinstance(candles, list) or len(candles) < 30:
        return False, 'INSUFFICIENT_CANDLES'
    for row in candles[-min(len(candles), 50):]:
        if not isinstance(row, (list, tuple)) or len(row) < 6:
            return False, 'MALFORMED_CANDLE'
        try:
            ts, o, h, l, c, v = row[:6]
            vals=[float(o),float(h),float(l),float(c),float(v)]
            if not all(x == x and abs(x) < 1e100 for x in vals) or min(vals[1:4]) <= 0 or vals[4] < 0:
                return False, 'INVALID_CANDLE_VALUE'
            if float(h) < max(float(o), float(c), float(l)) or float(l) > min(float(o), float(c), float(h)):
                return False, 'INVALID_OHLC_RELATION'
        except (TypeError,ValueError):
            return False, 'INVALID_CANDLE_VALUE'
    return True, 'PASS'


def analyze(candles):
    ok, reason = validate_candles(candles)
    if not ok:
        return {'valid':False,'reason':reason,'required':30,'received':len(candles) if isinstance(candles,list) else 0}
    close=_vals(candles,4); last=candles[-1]
    ind_b=bollinger(close,20); vwap=session_vwap(candles); relvol=relative_volume(candles,20)
    obv_val=obv(candles); pats=candle_patterns(candles); st=structure(candles); op=opening_range(candles,15)
    prev_close=float(candles[-2][4]) if len(candles)>=2 else None
    day_high=max(float(c[2]) for c in candles[-min(75,len(candles)):]); day_low=min(float(c[3]) for c in candles[-min(75,len(candles)):])
    volume_accel=None
    if len(candles)>=3 and float(candles[-2][5])!=0: volume_accel=float(candles[-1][5])/float(candles[-2][5])
    prev_high=max(float(c[2]) for c in candles[-min(20,len(candles)):-1]) if len(candles)>1 else None
    prev_low=min(float(c[3]) for c in candles[-min(20,len(candles)):-1]) if len(candles)>1 else None
    last_close=float(last[4]); high=float(last[2]); low=float(last[3]); opn=float(last[1])
    rng=max(high-low,1e-12); body=abs(last_close-opn)
    failed_breakout=bool(prev_high is not None and high>prev_high and last_close<prev_high)
    failed_breakdown=bool(prev_low is not None and low<prev_low and last_close>prev_low)
    pin_bar=bool((min(last_close,opn)-low)>=2*max(body,1e-12) or (high-max(last_close,opn))>=2*max(body,1e-12))
    rejection=bool((last_close<prev_high if prev_high is not None else False) and high>prev_high) or bool((last_close>prev_low if prev_low is not None else False) and low<prev_low)
    momentum_candle=bool(body/rng>=0.65)
    opening_candle=bool(len(candles)<=6)
    reversal_structure=bool(failed_breakout or failed_breakdown or ('BULLISH_ENGULFING' in pats) or ('BEARISH_ENGULFING' in pats))
    # Simple volume-profile approximation from typical price bins; it is explicitly approximate, not L2/order-book data.
    vp=None
    try:
        prices=[(float(c[2])+float(c[3])+float(c[4]))/3 for c in candles]
        volumes=[float(c[5]) for c in candles]
        lo=min(prices); hi=max(prices)
        if hi>lo:
            bins=20; step=(hi-lo)/bins
            hist=[0.0]*bins
            for pr,vol in zip(prices,volumes):
                idx=min(bins-1,max(0,int((pr-lo)/step))); hist[idx]+=max(0.0,vol)
            imax=max(range(bins),key=lambda i:hist[i]); vp={'available':True,'poc_price':lo+(imax+0.5)*step,'bins':bins}
    except Exception:
        vp=None
    indicators={
      'ema9':ema(close,9),'ema20':ema(close,20),'ema50':ema(close,50),'ema200':ema(close,200),
      'sma20':sma(close,20),'sma50':sma(close,50),'sma200':sma(close,200),
      'rsi14':rsi(close,14),'macd':macd(close),'atr14':atr(candles,14),
      'bollinger20':ind_b,'adx14':adx(candles,14),'vwap':vwap,
      'relative_volume20':relvol,'obv':obv_val,'candle_patterns':pats,'structure':st,'opening_range_15m':op,
      'gap_pct':((float(last[1])-prev_close)/prev_close*100) if prev_close else None,
      'day_range':day_high-day_low,'distance_from_vwap_pct':((float(last[4])-vwap)/vwap*100) if vwap else None,
      'volume_acceleration':volume_accel,
      'breakout': bool(st.get('resistance') is not None and last_close>float(st['resistance'])),
      'breakdown': bool(st.get('support') is not None and last_close<float(st['support'])),
      'failed_breakout': failed_breakout,
      'failed_breakdown': failed_breakdown,
      'pin_bar': pin_bar,
      'rejection': rejection,
      'momentum_candle': momentum_candle,
      'opening_candle': opening_candle,
      'reversal_structure': reversal_structure,
      'breakout_volume': bool(float(last[5]) > (sum(float(c[5]) for c in candles[-min(20,len(candles)):-1])/max(1,min(19,len(candles)-1))) * 1.5) if len(candles)>1 else False,
      'pullback_volume': bool(len(candles)>=3 and float(candles[-1][5]) < float(candles[-2][5]) and float(candles[-2][4]) >= float(candles[-3][4])),
      'rejection_volume': bool(rejection and float(last[5]) > (sum(float(c[5]) for c in candles[-min(20,len(candles)):-1])/max(1,min(19,len(candles)-1))) if len(candles)>1 else False),
      'volume_profile': vp or {'available':False,'reason':'INSUFFICIENT_PRICE_RANGE'},
      'previous_day_high': day_high,
      'previous_day_low': day_low,
    }
    price=last_close
    trend='NEUTRAL'
    e20,e50=indicators['ema20'],indicators['ema50']
    if e20 is not None and e50 is not None: trend='BULLISH' if price>e20>e50 else ('BEARISH' if price<e20<e50 else 'MIXED')
    momentum='NEUTRAL'
    r=indicators['rsi14']
    if r is not None: momentum='STRONG' if r>=60 or r<=40 else 'NEUTRAL'
    return {'valid':True,'last_price':price,'trend':trend,'momentum':momentum,'indicators':indicators,'candle_patterns':pats,'structure':st}
