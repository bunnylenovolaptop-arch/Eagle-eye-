from __future__ import annotations

import hashlib
import hmac
import secrets
import time
from dataclasses import dataclass
from threading import Lock
from typing import Dict, Optional


@dataclass(frozen=True)
class SessionRecord:
    token_hash: str
    created_at: float
    expires_at: float
    csrf: str


class SessionStore:
    """In-memory auth sessions. Raw session tokens are never persisted."""

    def __init__(self, ttl_seconds: int = 8 * 60 * 60):
        self.ttl_seconds = max(300, int(ttl_seconds))
        self._records: Dict[str, SessionRecord] = {}
        self._lock = Lock()

    @staticmethod
    def _digest(value: str) -> str:
        return hashlib.sha256(value.encode("utf-8")).hexdigest()

    def create(self) -> tuple[str, str, int]:
        raw = secrets.token_urlsafe(48)
        csrf = secrets.token_urlsafe(32)
        now = time.time()
        rec = SessionRecord(
            token_hash=self._digest(raw),
            created_at=now,
            expires_at=now + self.ttl_seconds,
            csrf=csrf,
        )
        with self._lock:
            self._records[rec.token_hash] = rec
            self._prune_locked(now)
        return raw, csrf, int(rec.expires_at)

    def validate(self, raw: str | None) -> Optional[SessionRecord]:
        if not raw:
            return None
        digest = self._digest(raw)
        now = time.time()
        with self._lock:
            rec = self._records.get(digest)
            if rec is None or rec.expires_at <= now:
                self._records.pop(digest, None)
                return None
            return rec

    def revoke(self, raw: str | None) -> None:
        if not raw:
            return
        with self._lock:
            self._records.pop(self._digest(raw), None)

    def _prune_locked(self, now: float) -> None:
        stale = [k for k, v in self._records.items() if v.expires_at <= now]
        for k in stale:
            self._records.pop(k, None)


class SlidingWindowLimiter:
    """Simple in-memory limiter; keys are session hashes, never device/IP identifiers."""

    def __init__(self):
        self._events: Dict[str, list[float]] = {}
        self._lock = Lock()

    def allow(self, key: str, limit: int, window_seconds: float) -> bool:
        now = time.monotonic()
        cutoff = now - window_seconds
        with self._lock:
            arr = self._events.setdefault(key, [])
            while arr and arr[0] < cutoff:
                arr.pop(0)
            if len(arr) >= limit:
                return False
            arr.append(now)
            if len(self._events) > 1000:
                stale_keys = [k for k, values in self._events.items() if not values or values[-1] < cutoff]
                for k in stale_keys[:500]:
                    self._events.pop(k, None)
            return True


def constant_time_equals(left: str | None, right: str | None) -> bool:
    if left is None or right is None:
        return False
    return hmac.compare_digest(left.encode(), right.encode())
