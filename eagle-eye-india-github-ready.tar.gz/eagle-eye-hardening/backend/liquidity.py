from __future__ import annotations


def assess_liquidity(tick: dict, min_traded_value: float) -> dict:
    try:
        ltp = float(tick.get('ltp') or 0)
        volume = float(tick.get('volume_trade_for_day') or 0)
        traded_value = ltp * volume
    except Exception:
        return {'pass': False, 'level': 'REJECT', 'reason': 'INVALID_PRICE_VOLUME', 'traded_value_inr': None}
    if ltp <= 0 or volume <= 0:
        return {'pass': False, 'level': 'REJECT', 'reason': 'NO_LIQUIDITY_DATA', 'traded_value_inr': traded_value}

    spread_pct = None
    depth = tick.get('depth') or {}
    buy = depth.get('buy') or []
    sell = depth.get('sell') or []
    if buy and sell:
        try:
            best_bid = float(buy[0]['price']); best_ask = float(sell[0]['price'])
            if best_ask >= best_bid > 0:
                spread_pct = (best_ask - best_bid) / ((best_ask + best_bid) / 2) * 100
        except Exception:
            pass

    if traded_value < min_traded_value:
        return {'pass': False, 'level': 'LOW', 'reason': 'LOW_TRADED_VALUE', 'traded_value_inr': round(traded_value), 'spread_pct': spread_pct}
    if spread_pct is not None and spread_pct > 0.75:
        return {'pass': False, 'level': 'LOW', 'reason': 'WIDE_SPREAD', 'traded_value_inr': round(traded_value), 'spread_pct': round(spread_pct,4)}
    if float(tick.get('upper_circuit') or 0) and float(tick.get('lower_circuit') or 0):
        upper = float(tick['upper_circuit']); lower = float(tick['lower_circuit'])
        if ltp > 0:
            circuit_room = min(abs(upper-ltp)/ltp, abs(ltp-lower)/ltp)*100
            if circuit_room < 0.5:
                return {'pass': False, 'level': 'LOW', 'reason': 'CIRCUIT_PROXIMITY', 'traded_value_inr': round(traded_value), 'spread_pct': spread_pct, 'circuit_room_pct': round(circuit_room,3)}
    if traded_value >= max(min_traded_value * 5, 250_000_000) and (spread_pct is None or spread_pct <= 0.25):
        level='HIGH'
    else:
        level='MEDIUM'
    return {'pass': True, 'level': level, 'reason': 'PASS', 'traded_value_inr': round(traded_value), 'spread_pct': round(spread_pct,4) if spread_pct is not None else None}


def manipulation_flags(tick: dict, technical: dict, evidence: dict, sector: dict) -> list[str]:
    flags=[]
    pct=tick.get('close')
    ltp=tick.get('ltp')
    try: move=abs((float(ltp)-float(pct))/float(pct)*100) if pct not in (None,0) else None
    except Exception: move=None
    vol=technical.get('relative_volume20')
    if move is not None and move >= 8 and (vol is None or vol < 1.5):
        flags.append('LARGE_PRICE_MOVE_WITHOUT_VOLUME_CONFIRMATION')
    if technical.get('direction') in ('LONG','SHORT') and sector.get('available') and sector.get('change_pct') is not None:
        try:
            if abs(float(sector['change_pct'])) < 0.15 and abs(move or 0) >= 5:
                flags.append('STOCK_MOVE_DECOUPLED_FROM_SECTOR')
        except Exception: pass
    for c in evidence.get('contradictions') or []:
        if str(c.get('catalyst','')).lower() in ('rumour','corporate governance','regulatory action'):
            flags.append('ADVERSE_CATALYST_OR_RUMOUR')
    if tick.get('total_buy_quantity') is not None and tick.get('total_sell_quantity') is not None:
        b=float(tick.get('total_buy_quantity') or 0); s=float(tick.get('total_sell_quantity') or 0)
        if b+s and abs(b-s)/(b+s) > .98 and float(tick.get('volume_trade_for_day') or 0) < 100000:
            flags.append('EXTREME_ORDER_IMBALANCE')
    return flags
