from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Dict, Iterable, Optional

IST = __import__('zoneinfo').ZoneInfo('Asia/Kolkata')

INDEX_CATALOG = {
    'NIFTY': {'token': '99926000', 'label': 'NIFTY 50', 'kind': 'broad'},
    'BANKNIFTY': {'token': '99926009', 'label': 'BANK NIFTY', 'kind': 'broad'},
    'MIDCAP100': {'token': '99926011', 'label': 'NIFTY MIDCAP 100', 'kind': 'broad'},
    'SMALLCAP100': {'token': '99926032', 'label': 'NIFTY SMLCAP 100', 'kind': 'broad'},
    'VIX': {'token': '99926017', 'label': 'INDIA VIX', 'kind': 'volatility'},
    'IT': {'token': '99926008', 'label': 'NIFTY IT', 'kind': 'sector'},
    'AUTO': {'token': '99926029', 'label': 'NIFTY AUTO', 'kind': 'sector'},
    'METAL': {'token': '99926030', 'label': 'NIFTY METAL', 'kind': 'sector'},
    'PHARMA': {'token': '99926023', 'label': 'NIFTY PHARMA', 'kind': 'sector'},
    'ENERGY': {'token': '99926020', 'label': 'NIFTY ENERGY', 'kind': 'sector'},
    'FMCG': {'token': '99926021', 'label': 'NIFTY FMCG', 'kind': 'sector'},
    'REALTY': {'token': '99926018', 'label': 'NIFTY REALTY', 'kind': 'sector'},
    'PSUBANK': {'token': '99926025', 'label': 'NIFTY PSU BANK', 'kind': 'sector'},
}
INDEX_TOKENS = {v['token'] for v in INDEX_CATALOG.values()}
INDEX_BY_TOKEN = {v['token']: {**v, 'key': k} for k, v in INDEX_CATALOG.items()}


def pct_change(item: Optional[dict]) -> Optional[float]:
    if not item:
        return None
    close = item.get('close')
    ltp = item.get('ltp')
    if close in (None, 0) or ltp is None:
        return None
    return (float(ltp) - float(close)) / float(close) * 100.0


def freshness(item: Optional[dict], now_ms: int, stale_after_ms: int) -> str:
    if not item:
        return 'UNAVAILABLE'
    received = item.get('received_timestamp_ms')
    if not received:
        return 'UNAVAILABLE'
    return 'LIVE' if now_ms - int(received) <= stale_after_ms else 'STALE'


def market_regime(ticks: Dict[str, dict], now_ms: int, stale_after_ms: int) -> dict:
    live = {}
    for key, meta in INDEX_CATALOG.items():
        t = ticks.get(f"1:{meta['token']}")
        if freshness(t, now_ms, stale_after_ms) == 'LIVE':
            live[key] = t

    nifty_move = pct_change(live.get('NIFTY'))
    bank_move = pct_change(live.get('BANKNIFTY'))
    mid_move = pct_change(live.get('MIDCAP100'))
    small_move = pct_change(live.get('SMALLCAP100'))
    vix_move = pct_change(live.get('VIX'))

    broad = [x for x in (nifty_move, bank_move, mid_move, small_move) if x is not None]
    if not broad:
        regime = 'UNAVAILABLE'
    else:
        avg = sum(broad) / len(broad)
        breadth_items = []
        for key, t in ticks.items():
            try:
                ex_type, token = key.split(':', 1)
            except ValueError:
                ex_type, token = '1', str(key)
            if ex_type == '1' and token in INDEX_TOKENS:
                continue
            if freshness(t, now_ms, stale_after_ms) != 'LIVE':
                continue
            r = pct_change(t)
            if r is not None:
                breadth_items.append(r)
        breadth_total = len(breadth_items)
        adv = sum(1 for r in breadth_items if r > 0)
        dec = sum(1 for r in breadth_items if r < 0)
        breadth_pct = (adv / breadth_total * 100.0) if breadth_total else None

        if vix_move is not None and vix_move >= 8 and abs(avg) >= 0.7:
            regime = 'HIGH VOLATILITY'
        elif avg >= 1.0 and (breadth_pct is None or breadth_pct >= 60):
            regime = 'STRONG BULLISH'
        elif avg >= 0.25 and (breadth_pct is None or breadth_pct >= 52):
            regime = 'MILD BULLISH'
        elif avg <= -1.0 and (breadth_pct is None or breadth_pct <= 40):
            regime = 'STRONG BEARISH'
        elif avg <= -0.25 and (breadth_pct is None or breadth_pct <= 48):
            regime = 'MILD BEARISH'
        else:
            regime = 'NEUTRAL'

    # Keep breadth variables defined even when no equity ticks are available.
    if 'adv' not in locals():
        adv = dec = breadth_total = 0
        breadth_pct = None

    sectors = []
    for key, meta in INDEX_CATALOG.items():
        if meta['kind'] != 'sector':
            continue
        t = live.get(key)
        move = pct_change(t)
        if move is not None:
            sectors.append({'key': key, 'label': meta['label'], 'change_pct': round(move, 3)})
    sectors.sort(key=lambda x: x['change_pct'], reverse=True)

    breadth = {
        'advancers': adv if 'adv' in locals() else None,
        'decliners': dec if 'dec' in locals() else None,
        'unchanged': (breadth_total - adv - dec) if 'breadth_total' in locals() else None,
        'sample_size': breadth_total if 'breadth_total' in locals() else 0,
        'advancing_pct': round(breadth_pct, 2) if breadth_pct is not None else None,
    }

    return {
        'regime': regime,
        'as_of_ms': now_ms,
        'market_data_status': 'LIVE' if live else 'UNAVAILABLE',
        'indices': {
            meta['label']: {
                'token': meta['token'],
                'ltp': t.get('ltp'),
                'change_pct': round(pct_change(t), 3) if pct_change(t) is not None else None,
                'data_status': freshness(t, now_ms, stale_after_ms),
                'exchange_timestamp_ms': t.get('exchange_timestamp_ms'),
                'received_timestamp_ms': t.get('received_timestamp_ms'),
            }
            for key, meta in INDEX_CATALOG.items()
            for t in [live.get(key)]
            if t is not None
        },
        'breadth': breadth,
        'sector_rotation': sectors,
        'notes': (
            'Breadth is computed only from subscribed live equity ticks. '
            'FII/DII, USD/INR, Brent, gold and global-market inputs are not inferred when unavailable.'
        ),
    }


def liquidity_gate(tick: dict, min_traded_value: float) -> tuple[bool, str]:
    ltp = float(tick.get('ltp') or 0)
    volume = float(tick.get('volume_trade_for_day') or 0)
    traded_value = ltp * volume
    if traded_value < min_traded_value:
        return False, 'LOW_TRADED_VALUE'
    spread_proxy = None
    buy = tick.get('total_buy_quantity')
    sell = tick.get('total_sell_quantity')
    if buy is not None and sell is not None and (buy + sell) > 0:
        spread_proxy = abs(float(buy) - float(sell)) / (float(buy) + float(sell))
    if spread_proxy is not None and spread_proxy > 0.98 and volume < 100000:
        return False, 'EXTREME_ORDER_IMBALANCE'
    return True, 'PASS'


def technical_quality(analysis: dict, tick: dict, nifty_change: Optional[float]) -> dict:
    if not analysis.get('valid'):
        return {'valid': False, 'score': 0, 'direction': 'UNAVAILABLE', 'reasons': [analysis.get('reason', 'TECHNICAL_DATA_UNAVAILABLE')]}
    i = analysis.get('indicators', {})
    price = float(analysis.get('last_price') or tick.get('ltp') or 0)
    vwap = i.get('vwap')
    ema20 = i.get('ema20')
    ema50 = i.get('ema50')
    rsi14 = i.get('rsi14')
    adx14 = i.get('adx14') or {}
    relvol = i.get('relative_volume20')

    direction = 'NEUTRAL'
    if ema20 is not None and ema50 is not None:
        if price > ema20 > ema50:
            direction = 'LONG'
        elif price < ema20 < ema50:
            direction = 'SHORT'

    score = 0
    reasons = []
    max_score = 0

    # Trend structure
    max_score += 20
    if direction in ('LONG', 'SHORT'):
        score += 20
        reasons.append(f'{direction} trend structure: price/EMA20/EMA50 aligned')
    elif analysis.get('trend') == 'MIXED':
        score += 8
        reasons.append('Mixed moving-average structure')

    # VWAP
    max_score += 15
    if vwap is not None:
        if direction == 'LONG' and price > vwap:
            score += 15; reasons.append('Price above session VWAP')
        elif direction == 'SHORT' and price < vwap:
            score += 15; reasons.append('Price below session VWAP')

    # RSI regime, avoid overbought/oversold certainty
    max_score += 15
    if rsi14 is not None:
        if direction == 'LONG' and 52 <= rsi14 <= 72:
            score += 15; reasons.append(f'RSI {rsi14:.1f} supports momentum without extreme overbought reading')
        elif direction == 'SHORT' and 28 <= rsi14 <= 48:
            score += 15; reasons.append(f'RSI {rsi14:.1f} supports downside momentum without extreme oversold reading')
        elif 45 <= rsi14 <= 55:
            score += 6; reasons.append(f'RSI {rsi14:.1f} is near balance')

    # ADX
    max_score += 15
    adx_value = adx14.get('adx') if isinstance(adx14, dict) else None
    if adx_value is not None:
        if adx_value >= 25:
            score += 15; reasons.append(f'ADX {adx_value:.1f} indicates established directional strength')
        elif adx_value >= 18:
            score += 9; reasons.append(f'ADX {adx_value:.1f} shows developing directional strength')

    # Relative volume
    max_score += 15
    if relvol is not None:
        if relvol >= 2.0:
            score += 15; reasons.append(f'Relative volume {relvol:.2f}×')
        elif relvol >= 1.5:
            score += 10; reasons.append(f'Relative volume {relvol:.2f}×')
        elif relvol >= 1.0:
            score += 5

    # Relative strength vs Nifty
    max_score += 20
    stock_move = pct_change(tick)
    if nifty_change is not None and stock_move is not None:
        rs = stock_move - nifty_change
        if direction == 'LONG' and rs >= 1.0:
            score += 20; reasons.append(f'Outperforming NIFTY by {rs:.2f} percentage points')
        elif direction == 'LONG' and rs >= 0.4:
            score += 10; reasons.append(f'Outperforming NIFTY by {rs:.2f} percentage points')
        elif direction == 'SHORT' and rs <= -1.0:
            score += 20; reasons.append(f'Underperforming NIFTY by {abs(rs):.2f} percentage points')
        elif direction == 'SHORT' and rs <= -0.4:
            score += 10; reasons.append(f'Underperforming NIFTY by {abs(rs):.2f} percentage points')

    return {
        'valid': True,
        'direction': direction,
        'score': score,
        'max_score': max_score,
        'score_pct': round(score / max_score * 100, 1) if max_score else 0,
        'reasons': reasons[:5],
        'rsi14': rsi14,
        'adx14': adx_value,
        'relative_volume20': relvol,
        'vwap': vwap,
        'relative_strength_vs_nifty': (stock_move - nifty_change) if (stock_move is not None and nifty_change is not None) else None,
    }
