from backend.news import NewsItem, verify_cluster, classify_catalyst, _parse_dt
from backend.evidence import build_evidence


def item(domain, title, primary=False, agency=None):
    return {
        'title': title,
        'url': f'https://{domain}/story',
        'domain': domain,
        'source_name': domain,
        'source_type': 'PRIMARY' if primary else 'SECONDARY',
        'published_at_ms': 1790865000000,
        'snippet': title,
        'origin_agency': agency,
        'provider': 'test',
        'cluster_id': 'abc',
    }


def test_parse_gdelt_date():
    assert _parse_dt('20261001T100000Z') is not None


def test_three_source_verification_requires_primary():
    cluster={'items':[item('a.com','Company wins major order'),item('b.com','Company wins major order'),item('nseindia.com','Company wins major order',primary=True)]}
    x=verify_cluster(cluster)
    assert x['verification']=='3/3 VERIFIED'
    assert x['evidence_confidence']=='HIGH'


def test_wire_copies_do_not_count_as_three_independent_sources():
    cluster={'items':[item('a.com','Company wins major order Reuters',agency='REUTERS'),item('b.com','Company wins major order Reuters',agency='REUTERS'),item('c.com','Company wins major order Reuters',agency='REUTERS')]}
    x=verify_cluster(cluster)
    assert x['effective_independent_sources']==1
    assert x['verification']=='1/3 VERIFIED'


def test_catalyst_classification():
    assert classify_catalyst('Company receives order worth Rs 500 crore')=='Order win'


def test_no_news_is_watchlist():
    x=build_evidence({'clusters':[],'data':[]}, 1790865000000)
    assert x.status=='WATCHLIST'
    assert 'NEWS VERIFICATION UNAVAILABLE' in x.reasons
