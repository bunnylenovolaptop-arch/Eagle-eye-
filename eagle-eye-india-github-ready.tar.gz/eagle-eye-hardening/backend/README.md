# Eagle Eye India backend — Phase 5

FastAPI backend for the Eagle Eye India mobile/PWA terminal.

## Live Angel One feed

The backend authenticates with Angel One SmartAPI server-side and maintains SmartAPI WebSocket 2.0 connections. It sends heartbeat `ping` messages and decodes LTP/Quote/SnapQuote packets. It can subscribe NSE cash, NFO, BSE cash, BFO, MCX and supported additional exchange types.

Credentials must stay in `.env` and must never be shipped in the app.

## Endpoints

- `/api/status` — provider/data health
- `/api/market/regime` — market regime and breadth
- `/api/instruments/search` — instrument master search
- `/api/candles` — Angel One historical candles
- `/api/technical/analyze` — technical indicators
- `/api/news` — news discovery
- `/api/evidence` — source verification/materiality/contradictions
- `/api/derivatives` — NFO contract/OI/PCR/futures-basis context
- `/api/scan` — staged scan and 100-point decision engine
- `/api/paper/trade` — create a paper setup
- `/api/paper/trades` — paper journal
- `/api/paper/metrics` — observed performance metrics

## Fail-closed rules

- No live tick -> no live setup.
- Missing/stale candles -> no technical conclusion.
- Major catalyst without 3/3 independent verification -> not trade-ready.
- Missing sector context -> not trade-ready.
- Required F&O context missing for an F&O-enabled stock -> not trade-ready.
- Skeptic rejection -> not trade-ready.
- `NO QUALIFIED SETUP` is valid output.

The backend is read-only. It never places broker orders.
