from pathlib import Path
import re

from .features import timeframe_set
from .technical import analyze
from .derivatives import derivative_snapshot
from .paper import analytics


def _daily(n=15):
    return [[i*86400000, 100+i, 103+i, 99+i, 102+i, 1000+i*10] for i in range(n)]

def _one(n=60):
    return [[i*300000, 100+i*0.1, 100+i*0.15, 100+i*0.05, 100+i*0.1, 1000+i] for i in range(n)]

def test_weekly_is_calendar_based():
    tf=timeframe_set(_one(60), _daily(15))
    assert len(tf['1w']) >= 3
    assert all(len(x) >= 6 for x in tf['1w'])

def test_opening_range_respects_five_minute_bar_size():
    a=analyze(_one(60))
    assert a['indicators']['opening_range_15m']['bars_used'] == 3

def test_fno_build_classification_and_aggregates():
    selected={'spot':100,'expiry':'2026-10-29'}
    quotes=[{'symbolToken':'1','tradingSymbol':'ABC26OCTFUT','instrumenttype':'FUTSTK','ltp':101,'opnInterest':1200,'optiontype':''},
            {'symbolToken':'2','tradingSymbol':'ABC26OCT100CE','ltp':4,'opnInterest':800,'optiontype':'CE','volume':200,'iv':22,'strikePrice':100},
            {'symbolToken':'3','tradingSymbol':'ABC26OCT100PE','ltp':5,'opnInterest':1000,'optiontype':'PE','volume':300,'iv':24,'strikePrice':100}]
    x=derivative_snapshot(selected, quotes, prior_oi={'1':1000,'2':700,'3':900}, prior_futures_price={'1':100})
    assert x['futures_build']=='LONG_BUILDUP' and x['oi_additions']
    assert x['option_volume']==500 and x['iv']==23

def test_paper_analytics_schema():
    x=analytics('market_regime')
    assert x['group_by']=='market_regime' and isinstance(x['rows'], list)

def test_android_manifest_only_requests_internet():
    m=Path(__file__).resolve().parents[1]/'android/app/src/main/AndroidManifest.xml'
    text=m.read_text().lower()
    perms=re.findall(r'<uses-permission[^>]+android:name="([^"]+)"', text)
    assert perms == ['android.permission.internet']
    assert 'usescleartexttraffic="false"' in text
    assert 'allowbackup="false"' in text

def test_android_wrapper_restricts_remote_navigation_to_configured_origin():
    p=Path(__file__).resolve().parents[1]/'android/app/src/main/java/in/eagleeye/india/MainActivity.java'
    text=p.read_text()
    assert 'backendOrigin.equalsIgnoreCase(originOf(u))' in text
    assert 'onReceivedSslError' in text and 'handler.cancel()' in text


def test_security_contract_has_hardening_headers_in_source():
    m=(Path(__file__).resolve().parents[1]/'backend/main.py').read_text()
    for h in ['X-Content-Type-Options','X-Frame-Options','Referrer-Policy','Permissions-Policy','Strict-Transport-Security']:
        assert h in m

def test_scan_filter_helpers_are_enforced_in_source():
    m=(Path(__file__).resolve().parents[1]/'backend/main.py').read_text()
    assert 'passes_universe(symbol_hint, inst, requested_universe)' in m
    assert 'min_score' in m and 'req_sector' in m

def test_position_size_formula_rounds_down():
    cap=100000.0; risk_pct=1.0; entry=100.0; stop=95.0
    risk_amount=cap*risk_pct/100; qty=int(risk_amount/abs(entry-stop))
    assert risk_amount==1000 and qty==200

def test_registry_tracks_more_than_forty_prompt_parameters():
    from .registry import PARAMETERS
    assert len(PARAMETERS) >= 100


def test_android_wrapper_blocks_cross_origin_resource_requests():
    p=Path(__file__).resolve().parents[1]/'android/app/src/main/java/in/eagleeye/india/MainActivity.java'
    text=p.read_text()
    assert 'shouldInterceptRequest' in text
    assert 'sameBackendOrigin' in text
    assert 'Blocked by Eagle Eye' in text
