from backend.technical import analyze, ema, rsi

def candles(n=80):
    out=[]
    p=100.0
    for i in range(n):
        o=p; c=p+0.5; h=c+0.2; l=o-0.2; v=1000+i*10
        out.append([f'2026-10-01 09:{15+i:02d}',o,h,l,c,v,0]); p=c
    return out

def test_ema_and_rsi():
    assert round(ema([1,2,3,4,5],3),6)==4.0
    assert rsi(list(range(1,30)),14)==100.0

def test_analysis():
    x=analyze(candles())
    assert x['valid'] is True
    assert x['trend']=='BULLISH'
    assert x['indicators']['ema20'] is not None
    assert x['indicators']['relative_volume20'] is not None
