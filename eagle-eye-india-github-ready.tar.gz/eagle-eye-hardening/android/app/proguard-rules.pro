# Eagle Eye wrapper intentionally has no network secret literals.
