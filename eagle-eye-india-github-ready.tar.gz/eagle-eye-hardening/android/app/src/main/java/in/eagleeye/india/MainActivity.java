package in.eagleeye.india;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.CookieManager;
import android.net.http.SslError;
import java.io.ByteArrayInputStream;
import java.util.HashMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String PREFS = "eagle_eye_private";
    private static final String KEY_BACKEND = "backend_url";
    private WebView web;
    private String backendOrigin;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String saved = prefs.getString(KEY_BACKEND, "");
        if (saved.isEmpty()) showSetup(); else openBackend(saved);
    }

    private void showSetup() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(32,48,32,32); root.setBackgroundColor(Color.rgb(7,16,22));
        TextView title = new TextView(this); title.setText("🦅 EAGLE EYE INDIA"); title.setTextColor(Color.WHITE); title.setTextSize(26); root.addView(title);
        TextView info = new TextView(this); info.setText("Secure Android shell. The APK contains no Angel One credentials and requests only Internet access. Enter the HTTPS Eagle Eye backend URL."); info.setTextColor(Color.LTGRAY); info.setPadding(0,20,0,20); root.addView(info);
        EditText url = new EditText(this); url.setHint("https://your-eagle-eye-backend.example"); url.setSingleLine(true); url.setTextColor(Color.WHITE); url.setHintTextColor(Color.GRAY); root.addView(url);
        Button open = new Button(this); open.setText("OPEN EAGLE EYE"); root.addView(open);
        open.setOnClickListener(v -> { String value=url.getText().toString().trim(); if(!valid(value)){Toast.makeText(this,"Use HTTPS for remote backends.",Toast.LENGTH_LONG).show(); return;} prefs.edit().putString(KEY_BACKEND, value.replaceAll("/$","")).apply(); openBackend(value); });
        TextView note = new TextView(this); note.setText("No location • no contacts • no camera • no microphone • no advertising ID • no device telemetry"); note.setTextColor(Color.GRAY); note.setPadding(0,24,0,0); root.addView(note);
        setContentView(root);
    }

    private boolean valid(String value){
        try { Uri u=Uri.parse(value); if(!"https".equalsIgnoreCase(u.getScheme())) return false; return u.getHost()!=null; }
        catch(Exception e){ return false; }
    }

    private void openBackend(String url){
        try { Uri base=Uri.parse(url); backendOrigin=base.getScheme()+"://"+base.getHost()+(base.getPort()>0?":"+base.getPort():""); } catch(Exception e){ backendOrigin=null; }
        web = new WebView(this); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(false); s.setSafeBrowsingEnabled(true); s.setSavePassword(false); s.setSaveFormData(false); s.setAutofillEnabled(false); s.setJavaScriptCanOpenWindowsAutomatically(false); s.setSupportMultipleWindows(false); s.setMediaPlaybackRequiresUserGesture(true); s.setAllowFileAccess(false); s.setAllowContentAccess(false); s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW); s.setGeolocationEnabled(false); s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(web, false);
        web.setWebViewClient(new WebViewClient(){
            private String originOf(Uri u){ return u.getScheme()+"://"+u.getHost()+(u.getPort()>0?":"+u.getPort():""); }
            private boolean sameBackendOrigin(Uri u){ return u!=null && "https".equalsIgnoreCase(u.getScheme()) && backendOrigin!=null && backendOrigin.equalsIgnoreCase(originOf(u)); }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){ Uri u=request.getUrl(); return !sameBackendOrigin(u); }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request){
                Uri u=request.getUrl();
                // Defense in depth: the native shell blocks cross-origin network resources too,
                // so a compromised/modified page cannot exfiltrate application data directly.
                if(!sameBackendOrigin(u)){
                    return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked by Eagle Eye", new HashMap<>(), new ByteArrayInputStream(new byte[0]));
                }
                return super.shouldInterceptRequest(view, request);
            }
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error){ handler.cancel(); }
        });
        web.setBackgroundColor(Color.rgb(7,16,22)); setContentView(web); web.loadUrl(url);
    }
    @Override public void onBackPressed(){ if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
