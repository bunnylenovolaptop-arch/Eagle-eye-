# Eagle Eye India Android shell

This is a minimal native Android WebView shell around the Eagle Eye India backend/PWA.

Security properties:
- `INTERNET` is the only Android permission.
- Remote HTTP is blocked; use HTTPS.
- Cross-origin navigation and resource requests are blocked.
- Third-party cookies, geolocation, file/content access, form/autofill persistence and mixed content are disabled.
- Angel One/API secrets are never packaged in the APK.

## Build

With Android SDK 35 and a compatible Gradle installation:

```bash
../build-apk.sh
```

The debug APK is written to:

`android/app/build/outputs/apk/debug/app-debug.apk`

GitHub Actions can build the same artifact using `.github/workflows/android.yml`.
