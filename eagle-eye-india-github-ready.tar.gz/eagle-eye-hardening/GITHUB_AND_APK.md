# Eagle Eye India — GitHub + APK

## Step 1 — GitHub
1. Create a new GitHub repository named `eagle-eye-india`.
2. Upload the contents of `eagle-eye-hardening/` to the repository root (do not upload the outer ZIP folder).
3. Open **Actions**.
4. Run the workflow **Build Android APK** from `.github/workflows/android.yml`.
5. After it completes, download the APK artifact from the workflow run.

## Step 2 — Android
1. Download the generated APK to the phone.
2. Open it and allow Android's one-time "Install unknown apps" permission for the browser/file manager when Android asks.
3. Install and open Eagle Eye India.
4. Configure the HTTPS/WSS Eagle Eye backend URL.
5. Configure Angel One SmartAPI credentials on the backend only. Never put them into the APK.

## Safety states
If the backend or provider is unavailable, the app must show DATA UNAVAILABLE/STALE and must not manufacture prices, indicators, news, or TRADE-READY setups.
